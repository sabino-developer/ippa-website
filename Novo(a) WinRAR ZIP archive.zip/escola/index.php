<?php
  $novaPagina = 'nsdbytes.com/template/setting/views/dashboard';
  header("Location: $novaPagina");
  exit;
?>
