<div id="rightsidebar" class="right_sidebar">
			<a href="javascript:void(0)" class="p-3 settingbar float-right">
				<i data-feather="x"></i>
			</a>
			<ul class="nav nav-tabs" role="tablist">
				<li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Settings" aria-expanded="true">Aparência do Sistema</a></li>
			</ul> 

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane vivify fadeIn active" id="Settings" aria-expanded="true">
					<div class="mb-4">
						<h6 class="font-14 font-weight-bold text-muted">Cor do Tema</h6>
						<ul class="choose-skin list-unstyled mb-0">

                            <?php
                            
                                $var=$row['statusDep'];
                                if ($var=="on") {
                            ?>
                                <span class="tag tag-success">
                                    Ativo
                                </span>
                             <?php
                                }else{
                             ?>
                                <span class="tag tag-danger">
                                    Inativo
                                </span>
                             <?php
                                }
                             ?>
							<li data-theme="azure"><div class="azure"></div></li>
							<li data-theme="indigo"><div class="indigo"></div></li>
							<li data-theme="purple"><div class="purple"></div></li>
							<li data-theme="orange"><div class="orange"></div></li>
							<li data-theme="green"><div class="green"></div></li>
							<li data-theme="cyan" class="active"><div class="cyan"></div></li>
							<li data-theme="blush"><div class="blush"></div></li>
							<li data-theme="white"><div class="bg-white"></div></li>
						</ul>
					</div>
					<div class="mb-4">
						<h6 class="font-14 font-weight-bold text-muted">Estilo da Fonte</h6>
						<div class="custom-controls-stacked font_setting">
							<label class="custom-control custom-radio custom-control-inline">
								<input type="radio" class="custom-control-input" name="font" value="font-muli" checked>
								<span class="custom-control-label">Muli Google Font</span>
								</label>
								<label class="custom-control custom-radio custom-control-inline">
								<input type="radio" class="custom-control-input" name="font" value="font-montserrat">
								<span class="custom-control-label">Montserrat Google Font</span>
								</label>
								<label class="custom-control custom-radio custom-control-inline">
								<input type="radio" class="custom-control-input" name="font" value="font-poppins">
								<span class="custom-control-label">Poppins Google Font</span>
							</label>
						</div>
					</div>
				<div>
				<h6 class="font-14 font-weight-bold mt-4 text-muted">Definições Gerais</h6>
				<ul class="setting-list list-unstyled mt-1 setting_switch">
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Modo Noturno</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-darkmode">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Fixar Barra de Navegação</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-fixnavbar">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Escurecer o Cabeçalho</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-pageheader">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Escurecer a Mini Barra Lateral</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-min_sidebar">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Escurecer a Barra Lateral</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-sidebar">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Cor Gradiente</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-gradient" checked>
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
					<li>
						<label class="custom-switch">
							<span class="custom-switch-description">Box Shadow</span>
							<input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input btn-boxshadow">
							<span class="custom-switch-indicator"></span>
						</label>
					</li>
				</ul>
			</div>
			<hr>
			<div class="form-group">
				<button type="button" class="btn btn-primary btn-block mt-3">Salvar alterações</button>
			</div>
		</div>
	</div>
</div>