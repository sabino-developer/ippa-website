<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="../assets/images/logo-icon.svg" width="48" height="48" alt="Icon"></div>
        <p>Por favor, aguarde...</p>
        <div class="loader-spinner"></div>
    </div>
</div>