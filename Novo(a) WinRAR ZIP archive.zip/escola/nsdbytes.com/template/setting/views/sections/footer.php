<div class="section-body">
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    ANHERC 2023 <a href="#!">INSTITUTO POLITÉCNICO PRIVADO ANHERC</a>.
                </div>
                <div class="col-md-6 col-sm-12 text-md-right">

                </div>
            </div>
    </footer>
</div>