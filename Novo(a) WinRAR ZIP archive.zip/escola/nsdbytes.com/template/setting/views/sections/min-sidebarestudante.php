<div id="header_top" class="header_top">
	<div class="container"> 
		<div class="hleft">
			<a class="header-brand" href="dashboardestudante">
				<i class="avatar" style="background-image: url(assets/image/imagem3.png)"></i>
			</a>
			<div class="dropdown">
				<a href="javascript:void(0)" class="nav-link icon menu_toggle">
					<i data-feather="align-center" data-toggle="tooltip" data-placement="right" title="Mostrar/Ocultar menu"></i>
				</a>
				<a href="page-search.html" class="nav-link icon">
					<i  data-feather="search" data-toggle="tooltip" data-placement="right" title="Pesquisar..."></i>
				</a>
				<a href="app-email.html" class="nav-link icon app_inbox">
					<i  data-feather="trash" data-toggle="tooltip" data-placement="right" title="Lixeira"></i>
				</a>
				<a href="app-filemanager.html" class="nav-link icon app_file xs-hide">
					<i data-feather="folder" data-toggle="tooltip" data-placement="right" title="Arquivos"></i>
				</a>
				<a href="javascript:void(0)" class="nav-link icon settingbar">
					<i data-feather="settings" data-toggle="tooltip" data-placement="right" title="Configurações"></i>
				</a>
			</div>
		</div>
		<div class="hright">
			<a class="nav-link icon">
				<i data-feather="power" data-placement="right" title="Terminar Sessão" role="button" data-toggle="modal" data-target="#ModalViews"></i>
			</a>
		</div>
	</div>
</div>
<?php
    if (file_exists('modais/logout.php')) {
        require_once "modais/logout.php";
     } else {
        echo "<span class='text-danger'>O arquivo modais/logout não foi encontrado!</span>";
     }
?>