<div class="theme_div">
    <div class="card">
        <div class="card-body">
            <ul class="list-group list-unstyled">
                <li class="list-group-item mb-2">
                    <p>Light Version</p>
                    <a href="index-2.html"><img src="../assets/images/themes/default.png" class="img-fluid" alt /></a>
                </li>
                <li class="list-group-item mb-2">
                    <p>Dark Version</p>
                    <a href="https://nsdbytes.com/template/ericssionss/university-dark/index.html"><img
                            src="../assets/images/themes/dark.png" class="img-fluid" alt /></a>
                </li>
                <li class="list-group-item mb-2">
                    <p>RTL Version</p>
                    <a href="https://nsdbytes.com/template/ericssionss/university-rtl/index.html"><img
                            src="../assets/images/themes/rtl.png" class="img-fluid" alt /></a>
                </li>
            </ul>
        </div>
    </div>
</div>