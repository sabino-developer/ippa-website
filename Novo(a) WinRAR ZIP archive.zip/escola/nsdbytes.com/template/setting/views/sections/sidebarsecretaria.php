<div id="left-sidebar" class="sidebar">
    <h5 class="brand-name">
        <?php
        $queryApp = "SELECT * FROM app LIMIT 1";
        $stmt = $conn->query($queryApp);

        if ($stmt !== false) {
            $dadosApp = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($dadosApp !== false) {
                $nomeApp = $dadosApp['nome'];
                echo $nomeApp;
            } else {
                echo "Nenhum registro encontrado na tabela.";
            }
        } else {
            echo "Erro na consulta: " . $conn->errorInfo()[2];
        }
        ?>
        <a href="javascript:void(0)" class="menu_option float-right">
            <i data-feather="grid"></i>
        </a>
    </h5>
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#menu-uni">Menu da Secretaria</a>
        </li>
    </ul>
    <div class="tab-content mt-3">
        <div class="tab-pane fade show active" id="menu-uni" role="tabpanel">
            <nav class="sidebar-nav">
                <ul class="metismenu">
                    <?php
                    if ($pagename == "dashboardscretaria") {
                    ?>
                        <li class="active">
                            <a href="dashboardscretaria">
                                <span>Menu Principal</span>
                            </a>
                        </li>
                            <li><a href="secretariasecre"><span>Secretária</span></a></li>
                        <li class="g_heading">Extra</li>
                        <li><a href="tesorariasecretaria"><span>Tesorária</span></a></li>

                        <li><a href="contactos"><span>Contactos</span></a></li>
                        <li><a href="responsaveis"><span>Responsáveis</span></a></li>
                   
                    <?php
                    } else if ($pagename == "Secretária") {
                    ?>
                        <li><a href="dashboardscretaria"><span>Menu Principal</span></a></li>

                        
                        <<li class="active" ><a href="secretariasecre"><span>Secretária</span></a></li>
                        <li class="g_heading">Extra</li>
                        <li><a href="tesorariasecretaria"><span>Tesorária</span></a></li>

                        <li><a href="contactos"><span>Contactos</span></a></li>
                        <li><a href="responsaveis"><span>Responsáveis</span></a></li>
                    
                    <?php
                    } else if ($pagename == "tesorariasecretaria") {
                    ?>
                        <li><a href="dashboardscretaria"><span>Menu Principal</span></a></li>

                        
                        <li><a href="secretariasecre"><span>Secretária</span></a></li>
                        <li class="g_heading">Extra</li>
                        <li class="active"><a href="tesoraria"><span>Tesorária</span></a></li>

                        <li><a href="contactos"><span>Contactos</span></a></li>
                        <li><a href="responsaveis"><span>Responsáveis</span></a></li>>
                   
                    
                    <?php
                    } else if ($pagename == "Contactos") {
                    ?>
                        <li><a href="dashboardscretaria"><span>Menu Principal</span></a></li>

                        
                        <li><a href="secretariasecre"><span>Secretária</span></a></li>
                        <li class="g_heading">Extra</li>
                        <li><a href="tesorariasecretaria"><span>Tesorária</span></a></li>

                        <li><a href="relatorios"><span>Relatório</span></a></li>
                        <li class="active"><a href="contactos"><span>Contactos</span></a></li>
                        <li><a href="responsaveis"><span>Responsáveis</span></a></li>
                    <?php
                    } else if ($pagename == "Responsáveis") {
                    ?>
                        <li><a href="dashboardscretaria"><span>Menu Principal</span></a></li>

                        
                        <li><a href="secretariasecre"><span>Secretária</span></a></li>
                        <li class="g_heading">Extra</li>
                        <li><a href="tesorariasecretaria"><span>Tesorária</span></a></li>

                        <li><a href="contactos"><span>Contactos</span></a></li>
                        <li class="active"><a href="responsaveis"><span>Responsáveis</span></a></li>
                    <?php
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </div>
</div>