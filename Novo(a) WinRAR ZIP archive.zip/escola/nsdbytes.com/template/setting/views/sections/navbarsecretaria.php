
<div class="section-body" id="page_top">
    <div class="container-fluid">
        <div class="page-header">
            <div class="left">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="O que você quer encontrar?">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button">Pesquisar</button>
                    </div>
                </div>
            </div>
            <div class="right">
                <div class="notification d-flex">
                    <div class="dropdown d-flex">
                        <a class="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-1" data-toggle="dropdown">
                            <i data-feather="mail"></i>
                            <span class="badge badge-success nav-unread"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <ul class="right_chat list-unstyled w350 p-0">
                                <li class="online">
                                    <a href="javascript:void(0);" class="media">
                                        <img class="media-object" src="../assets/images/xs/avatar4.jpg" alt>
                                        <div class="media-body">
                                            <span class="name">Dionisio Travasso</span>
                                            <div class="message">Estou aqui
                                            </div>
                                            <small>11 mins ago</small>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0)" class="dropdown-item text-center text-muted-dark readall">Marcar tudo como lido</a>
                        </div>
                    </div>
                    <div class="dropdown d-flex">
                        <a class="nav-link icon d-none d-md-flex btn btn-default btn-icon ml-1" data-toggle="dropdown"><i data-feather="bell"></i><span class="badge badge-primary nav-unread"></span></a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <ul class="list-unstyled feeds_widget">
                                <li>
                                    <div class="feeds-left">
                                        <span class="avatar avatar-blue"><i class="fa fa-check"></i></span>
                                    </div>
                                    <div class="feeds-body ml-3">
                                        <p class="text-muted mb-0">Campaign <strong class="text-blue font-weight-bold">Holiday</strong> is nearly reach budget limit.</p>
                                    </div>
                                </li>
                            </ul>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0)" class="dropdown-item text-center text-muted-dark readall">Marcar tudo como lido</a>
                        </div>
                    </div>
                    <div class="dropdown d-flex">
                        <a href="javascript:void(0)" class="chip ml-3" data-toggle="dropdown">
                            <span class="avatar" style="background-image: url(../assets/images/xs/avatar5.jpg)"></span>
                            <?php
                            $user = $username;
                            $usernameParts = explode(".", $user);

                            // Verifica se o array tem pelo menos dois elementos antes de acessar o índice 1
                            if (isset($usernameParts[1])) {
                                $firstName = ucfirst($usernameParts[0]);
                                $lastName = ucfirst($usernameParts[1]);
                                $usernameConverted = $firstName[0] . ". " . $lastName;
                                echo $usernameConverted;
                            } else {
                                // Redireciona para a página principal imediatamente
                                header("Location: dashboardscretaria.php"); // Substitua 'pagina_principal.php' pelo caminho correto para sua página principal
                                exit; // Certifique-se de sair do script após o redirecionamento
                            }
                            

                            ?>

                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="#">
                                <i data-feather="user"></i> Perfil
                            </a>
                            <a class="dropdown-item" href="app-setting.html">
                                <i data-feather="settings"></i> Configurações
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="javascript:void(0)">
                                <i data-feather="help-circle"></i> Precisa de Ajuda?
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>