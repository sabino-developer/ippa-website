<?php
    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

    $pagename = "Área Pedagógica";

    // check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }

    $id = htmlspecialchars($_SESSION["id"]);
    $username = htmlspecialchars($_SESSION["username"]);
    $profile = htmlspecialchars($_SESSION["profile"]);

    // Consulta SQL para realizar a contagem
    $query = "SELECT COUNT(id) AS Total FROM ano";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $Total = $dados['Total'];

    $query = "SELECT COUNT(id) AS totalcursos FROM curso";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalcursos = $dados['totalcursos'];

    $query = "SELECT COUNT(id) AS nsala FROM sala";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $nsala = $dados['nsala'];

    $query = "SELECT COUNT(id) AS totalclasse FROM classe";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalclasse = $dados['totalclasse'];

    $query = "SELECT COUNT(id) AS totaldisciplina FROM disciplina";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $totaldisciplina = $dados['totaldisciplina'];

    $query = "SELECT COUNT(id) AS totaltrimestre FROM trimestre";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $totaltrimestre = $dados['totaltrimestre'];
?>
<!doctype html>
<html lang="pt-BR" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Área Pedagógica</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.min.css" />
    <link rel="stylesheet" href="assets/css/all.min.css" />
    
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --accent-color: #e74c3c;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }
        
        .page-title {
            font-weight: 700;
            color: var(--dark-color);
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
            margin-bottom: 20px;
            background: white;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.1);
        }
        
        .card-body {
            padding: 25px;
            position: relative;
        }
        
        .ribbon-box {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        
        .ribbon-box.orange {
            background: linear-gradient(135deg, #f39c12, #e67e22);
        }
        
        .ribbon-box.green {
            background: linear-gradient(135deg, #2ecc71, #27ae60);
        }
        
        .card:hover .ribbon-box {
            transform: scale(1.1);
        }
        
        .my_sort_cut {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--dark-color);
            transition: all 0.3s ease;
        }
        
        .my_sort_cut i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .my_sort_cut span {
            font-size: 1rem;
            text-align: center;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .card:hover .my_sort_cut i {
            transform: scale(1.2);
            color: var(--secondary-color);
        }
        
        .card:hover .my_sort_cut span {
            color: var(--secondary-color);
        }
        
        /* Pulse animation for important cards */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(46, 204, 113, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(46, 204, 113, 0); }
            100% { box-shadow: 0 0 0 0 rgba(46, 204, 113, 0); }
        }
        
        .pulse-card {
            animation: pulse 2s infinite;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .card {
                margin-bottom: 15px;
            }
            
            .my_sort_cut i {
                font-size: 2rem;
            }
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--secondary-color);
        }
        
        /* Floating action button */
        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
            background: var(--secondary-color);
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }
    </style>
</head>

<body class="font-muli theme-cyan gradient">

    <?php
        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }
    ?>
    
    <div id="main_content">
        <?php
            if (file_exists('sections/min-sidebar.php')) {
                require_once "sections/min-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/right-sidebar.php')) {
                require_once "sections/right-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/sidebar.php')) {
                require_once "sections/sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
            }
        ?>

        <div class="page">
            <?php
                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }
            ?>
            
            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="header-action">
                            <h1 class="page-title animate__animated animate__fadeInDown">Área Pedagógica</h1>
                            <ol class="breadcrumb page-breadcrumb animate__animated animate__fadeIn">
                                <li class="breadcrumb-item"><a href="dashboard"><i class="fas fa-home mr-2"></i>Menu Principal</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-chalkboard-teacher mr-2"></i>Área Pedagógica</li>
                            </ol>
                        </div>
                        <div class="animate__animated animate__fadeIn">
                            <span class="badge badge-primary p-2"><i class="fas fa-user-circle mr-1"></i> <?= $profile ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section-body mt-4 animate__animated animate__fadeIn">
                <div class="container-fluid">
                    <div class="row clearfix row-deck">
                        <!-- Ano Letivo -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="50">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box orange" data-toggle="tooltip" title="Total dos Anos Letivos"><?= $Total ?></div>
                                    <a href="anolectivo" class="my_sort_cut text-muted">
                                        <i class="fas fa-calendar-alt"></i>
                                        <span>Ano Letivo</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Turmas e Salas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="100">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total de Níveis de Ensino"><?= $nsala ?></div>
                                    <a href="turmaSala" class="my_sort_cut text-muted">
                                        <i class="fas fa-door-open"></i>
                                        <span>Turmas e Salas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Cursos -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="150">
                            <div class="card pulse-card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total dos Cursos"><?= $totalcursos ?></div>
                                    <a href="cursos" class="my_sort_cut text-muted">
                                        <i class="fas fa-graduation-cap"></i>
                                        <span>Cursos</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Classes -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="200">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total das Classes"><?= $totalclasse ?></div>
                                    <a href="classes" class="my_sort_cut text-muted">
                                        <i class="fas fa-users-class"></i>
                                        <span>Classes</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Disciplinas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="250">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total das Disciplinas"><?= $totaldisciplina ?></div>
                                    <a href="addisciplina" class="my_sort_cut text-muted">
                                        <i class="fas fa-book-open"></i>
                                        <span>Disciplinas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Trimestres -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="300">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total dos Trimestres"><?= $totaltrimestre ?></div>
                                    <a href="addtrimestre" class="my_sort_cut text-muted">
                                        <i class="fas fa-calendar-check"></i>
                                        <span>Trimestres</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Atribuição de Disciplinas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="50">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total das Atribuições">0</div>
                                    <a href="atribuirDisCla" class="my_sort_cut text-muted">
                                        <i class="fas fa-tasks"></i>
                                        <span>Atribuir Disciplinas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Atribuir a Professores -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="100">
                            <div class="card pulse-card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total das Atribuições">0</div>
                                    <a href="atriburdisprof" class="my_sort_cut text-muted">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                        <span>Atribuir a Professores</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Mini Pautas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="150">
                            <div class="card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total das Mini Pautas">0</div>
                                    <a href="addmiipauta" class="my_sort_cut text-muted">
                                        <i class="fas fa-clipboard-list"></i>
                                        <span>Mini Pautas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Lançamento de Notas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="200">
                            <div class="card pulse-card">
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total de Lançamentos">0</div>
                                    <a href="PerfilProfessor" class="my_sort_cut text-muted">
                                        <i class="fas fa-edit"></i>
                                        <span>Lançamento de Notas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating Action Button -->
    <a href="#" class="floating-btn animate__animated animate__bounceInUp animate__delay-1s">
        <i class="fas fa-question"></i>
    </a>

    <!-- JavaScript Libraries -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js"></script>
    <script src="../assets/bundles/summernote.bundle.js"></script>
    <script src="../assets/js/core.js"></script>
    <script src="assets/js/form/dropify.js"></script>
    <script src="assets/js/page/summernote.js"></script>
    
    <!-- AOS Animation -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Initialize AOS animation
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Initialize tooltips
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        
        // Pulse animation for important cards
        setInterval(function() {
            $('.pulse-card').toggleClass('pulse-card');
            setTimeout(function() {
                $('.pulse-card').addClass('pulse-card');
            }, 100);
        }, 2000);
        
        // Floating button click event
        $('.floating-btn').click(function(e) {
            e.preventDefault();
            alert('Ajuda: Selecione uma das opções acima para gerenciar a área pedagógica.');
        });
    </script>
</body>
</html>