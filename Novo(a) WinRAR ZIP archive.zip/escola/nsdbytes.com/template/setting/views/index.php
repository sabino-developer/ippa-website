<?php
   $username = @$_COOKIE['username']; 
    $profile  = @$_COOKIE['profile'];
    $id =@$_COOKIE['User']; 
    if(empty($username) && empty($profile) && empty($id)){
        header('Location: login.php');
    }
    
?>
<?php
    $username = @$_COOKIE['username']; 
    $profile  = @$_COOKIE['profile'];
    $id =@$_COOKIE['id']; 
    
    if ($profile=='Diretor Geral') {
    	echo "Administrador";
        echo "&nbsp;<a href='../logout.php'> Logout</a>";
        header('Location: dashboard.php');
        
    }elseif ($profile=='cliente') {
    	//echo "Cliente";
        include 'home.php';
        //echo "&nbsp;<a href='../logout.php'> Logout</a>";
    }
    ?>