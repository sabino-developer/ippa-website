<?php

    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

    $id = $_POST['id'];
    $stmt = $conn->prepare("SELECT  classe.nclasse, sala.turno
        FROM sala
        INNER JOIN classe ON classe.idsala = sala.id WHERE classe.idCurso = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $options = '<option selected disabled value=""> -- Selecione -- </option>';
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $options .= "<option value='{$row['id']}'>{$row['nclasse']} - {$row['turno']}</option>";
    }
    echo $options;
?>
