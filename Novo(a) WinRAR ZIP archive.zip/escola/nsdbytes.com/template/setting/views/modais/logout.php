<!-- Modal View-->
		<div class="modal fade" id="ModalViews" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabels" aria-hidden="true">
		    <div class="modal-dialog" role="document">
		    <div class="modal-content">
		        <div class="modal-header">
		            <h5 class="modal-title">Terminar Sessão</h5>
		            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		            <span aria-hidden="true">&times;</span>
		            </button>
		        </div>
		        <div class="modal-body">
		        	<h5 class="text-center">Você tem certeza que quer terminar sessão?</h5>
		        </div>
		        <div class="modal-footer">
		            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancelar</button>
		            <a href="../controllers/config/logout" class="btn btn-danger">Confirmar</a>
		        </button>
		        </div>
		        </div>
		    </div>
		</div>