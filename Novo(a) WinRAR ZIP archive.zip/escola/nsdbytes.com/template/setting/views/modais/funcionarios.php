<!-- Modal View-->
<div class="modal fade" id="ModalView<?= $idUser ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <center>
                    <img class="avatar avatar-xxl" src="../controllers/uploads/<?= $foto; ?>" />
                    <h4><?= $nome; ?></h4>
                    <div class="text-muted"><?= $documento; ?></div>
                    <div class="text-muted"><?= $endereco; ?></div>
                    <div class="text-muted"><?= $provincia; ?></div>
                    <div class="text-muted"><?= $dataNasc; ?></div>
                    <div class="text-muted"><?= $genero; ?></div>
                    <div class="text-muted"><?= $telefone; ?></div>
                    <a href="#" class=><?= $email; ?></a>
                    <div class="text-muted"><?= $created; ?></div>
                </center>
            </div>
            <div class="modal-footer">
                <a href="users?id=<?= $idUser ?>" class="btn btn-icon btn-sm js-sweetalert">
                    <i data-feather="edit" class="text-orange"></i>
                </a>
                <button type="button" class="btn btn-icon btn-sm js-sweetalert" data-dismiss="modal" title="Delete" data-type="confirm" data-toggle="modal" data-target="#ModalDelete<?= $idUser ?>">
                    <i data-feather="trash" class="text-danger"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Delete-->
<div class="modal fade" id="ModalDelete<?= $idUser ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Eliminar Funcionário</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Tem certeza que quer realmente eliminar este funcionário?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <a class="btn btn-danger btn-sm" href="../controllers/delete/funcionarios?id=<?= $idUser ?>">Confirmar</a>
            </div>
        </div>
    </div>
</div>