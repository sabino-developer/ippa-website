<?php

    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

    $pagename = "Dashboard";

    // check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }


$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);


?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Dashboard | Turmas</title>

    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
    <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />

    <link rel="stylesheet" href="assets/css/style.min.css" />
    <link rel="stylesheet" href="assets/css/all.min.css" />
    <script src="https://unpkg.com/feather-icons"></script>
        <script src="assets/css/feather-icons.css"></script>
</head>

<body class="font-muli theme-cyan gradient">

    <?php

        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }

    ?>
    <div id="main_content">

        <?php

            if (file_exists('sections/min-sidebar.php')) {
                require_once "sections/min-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/right-sidebar.php')) {
                require_once "sections/right-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/sidebar.php')) {
                require_once "sections/sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
            }

        ?>

        <div class="page">

            <?php

                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }

            ?>
        <div class="section-body">
            <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center ">
                        <div class="header-action">
                            <h1 class="page-title">Turmas</h1>
                            <ol class="breadcrumb page-breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard">dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Turmas</li>
                            </ol>
                        </div>
                      
                    </div>
                </div>
            </div>
                <div class="section-body mt-4">
                    <div class="container-fluid">
                        <div class="row clearfix row-deck">
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body ribbon">
                                        <div class="ribbon-box orange" data-toggle="tooltip" title="Total das Disciplinas">0</div>
                                        <a href="Disciplina" class="my_sort_cut text-muted">
                                            <i data-feather="key"></i>
                                            <span>Disciplinas</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body ribbon">
                                        <div class="ribbon-box green" data-toggle="tooltip" title="Total das Sala">0</div>
                                        <a href="sala" class="my_sort_cut text-muted">
                                            <i data-feather="repeat"></i>
                                            <span>Salas</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body ribbon">
                                        <div class="ribbon-box orange" data-toggle="tooltip" title="Total das Classe">0</div>
                                        <a href="classe" class="my_sort_cut text-muted">
                                            <i data-feather="award"></i>
                                            <span>Classes</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body ribbon">
                                        <div class="ribbon-box green" data-toggle="tooltip" title="Total das Períodos">0</div>
                                        <a href="turno" class="my_sort_cut text-muted">
                                            <i data-feather="users"></i>
                                            <span>Períodos</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body ribbon">
                                        <div class="ribbon-box orange" data-toggle="tooltip" title="Total das Turmas">0</div>
                                        <a href="turma" class="my_sort_cut text-muted">
                                            <i data-feather="book"></i>
                                            <span>Turmas</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-xl-2">
                                <div class="card">
                                    <div class="card-body">
                                        <a href="department" class="my_sort_cut text-muted">
                                            <i data-feather="share-2"></i>
                                            <span>Relatorio</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>

           

            </div>
        </div>
  

    <script>
      feather.replace()
    </script>
    <script src="../assets/bundles/lib.vendor.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"
        type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/bundles/summernote.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/js/core.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/form/dropify.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/page/summernote.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js"
        data-cf-settings="84bad0df44a88b049b511662-|49" defer></script>
    <script>
    (function() {
        var js =
            "window['__CF$cv$params']={r:'7dd4b640d8bd4931',m:'ylhOZFbX0HS1c4DPak1Yq5UidcMrX0PisknfubBMMH4-1687774766-0-AUNBl0Ey9/ml/1dDGoabBYZ977e9URVHmQjn28JNXdC6'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
        var _0xh = document.createElement('iframe');
        _0xh.height = 1;
        _0xh.width = 1;
        _0xh.style.position = 'absolute';
        _0xh.style.top = 0;
        _0xh.style.left = 0;
        _0xh.style.border = 'none';
        _0xh.style.visibility = 'hidden';
        document.body.appendChild(_0xh);

        function handler() {
            var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
            if (_0xi) {
                var _0xj = _0xi.createElement('script');
                _0xj.nonce = '';
                _0xj.innerHTML = js;
                _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
            }
        }
        if (document.readyState !== 'loading') {
            handler();
        } else if (window.addEventListener) {
            document.addEventListener('DOMContentLoaded', handler);
        } else {
            var prev = document.onreadystatechange || function() {};
            document.onreadystatechange = function(e) {
                prev(e);
                if (document.readyState !== 'loading') {
                    document.onreadystatechange = prev;
                    handler();
                }
            };
        }
    })();
    </script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816"
        integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw=="
        data-cf-beacon='{"rayId":"7dd4b640d8bd4931","version":"2023.4.0","r":1,"b":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":100}'
        crossorigin="anonymous"></script>
</body>

<!-- Mirrored from nsdbytes.com/template/ericssionss/university/professors.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Jun 2023 10:20:01 GMT -->

</html>