<?php
session_start([
    'cookie_lifetime' => 86400,
    'cookie_secure' => true,
    'cookie_httponly' => true
]);

if (!isset($_SESSION["professor_loggedin"]) || $_SESSION["professor_loggedin"] !== true) {
    header("Location: login.php");
    exit;
}

require_once '../config/connection.php';

$professor_id = $_SESSION["professor_id"];
$professor_nome = htmlspecialchars($_SESSION["professor_nome"]);
$professor_email = htmlspecialchars($_SESSION["professor_email"] ?? '');

// Processar atualização de configurações
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_config'])) {
    $novo_nome = $_POST['nome'] ?? '';
    $nova_senha = $_POST['senha'] ?? '';
    
    if (!empty($novo_nome)) {
        $stmt = $conn->prepare("UPDATE professores SET nome = ? WHERE id = ?");
        $stmt->execute([$novo_nome, $professor_id]);
        $_SESSION["professor_nome"] = $novo_nome;
        $professor_nome = $novo_nome;
    }
    
    if (!empty($nova_senha)) {
        $hash_senha = password_hash($nova_senha, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE professores SET senha = ? WHERE id = ?");
        $stmt->execute([$hash_senha, $professor_id]);
    }
    
    $mensagem_sucesso = 'Configurações atualizadas com sucesso!';
}

// Obter turmas do professor
$turmas = [];
$stmt = $conn->prepare("SELECT t.id, t.nome AS turma, d.nome AS disciplina, p.nome AS periodo, 
                       COUNT(m.id) AS total_alunos
                       FROM turmas t
                       JOIN disciplinas d ON t.disciplina_id = d.id
                       JOIN periodos p ON t.periodo_id = p.id
                       LEFT JOIN matriculas m ON m.turma_id = t.id
                       WHERE t.professor_id = ?
                       GROUP BY t.id");
$stmt->execute([$professor_id]);
$turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter alunos de uma turma específica (se selecionada)
$alunos_turma = [];
$turma_selecionada = null;
if (isset($_GET['turma_id'])) {
    $turma_id = $_GET['turma_id'];
    // Verificar se o professor tem acesso a esta turma
    $stmt = $conn->prepare("SELECT id, nome FROM turmas WHERE id = ? AND professor_id = ?");
    $stmt->execute([$turma_id, $professor_id]);
    $turma_selecionada = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($turma_selecionada) {
        $stmt = $conn->prepare("SELECT m.id, a.id AS aluno_id, a.nome, a.codigo, 
                              n.mac, n.pp, n.pt, n.media, n.estado
                              FROM matriculas m
                              JOIN alunos a ON m.aluno_id = a.id
                              LEFT JOIN notas n ON n.matricula_id = m.id
                              WHERE m.turma_id = ?
                              ORDER BY a.nome");
        $stmt->execute([$turma_id]);
        $alunos_turma = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Professor - Sistema Escolar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --danger-color: #e74a3b;
            --warning-color: #f6c23e;
            --info-color: #36b9cc;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }

        body {
            font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: #f8f9fc;
        }

        .sidebar {
            min-width: 250px;
            max-width: 250px;
            background: var(--primary-color);
            color: white;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
        }

        .sidebar .sidebar-header {
            padding: 20px;
            background: rgba(0, 0, 0, 0.1);
        }

        .sidebar ul.components {
            padding: 20px 0;
        }

        .sidebar ul li a {
            padding: 10px 20px;
            font-size: 1.1em;
            display: block;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }

        .sidebar ul li a:hover {
            background: rgba(0, 0, 0, 0.2);
            color: white;
        }

        .sidebar ul li.active > a {
            background: rgba(0, 0, 0, 0.2);
        }

        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            transition: all 0.3s;
        }

        .navbar {
            padding: 15px 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }

        .card-header {
            border-bottom: 1px solid rgba(0,0,0,.125);
        }

        .avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .nota {
            max-width: 80px;
            text-align: center;
            font-weight: bold;
        }

        .media {
            max-width: 80px;
            text-align: center;
            font-weight: bold;
            background-color: #f8f9fa;
        }

        .aprovado {
            background-color: rgba(28, 200, 138, 0.1);
            color: var(--success-color);
        }

        .reprovado {
            background-color: rgba(231, 74, 59, 0.1);
            color: var(--danger-color);
        }

        .recurso {
            background-color: rgba(246, 194, 62, 0.1);
            color: var(--warning-color);
        }

        .badge.estado {
            padding: 0.5em 0.8em;
            font-size: 0.9em;
            font-weight: 600;
            width: 100px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid var(--primary-color);
        }

        .tab-content {
            padding: 20px 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            .sidebar.active {
                margin-left: 0;
            }
            .main-content {
                width: 100%;
                margin-left: 0;
            }
            .main-content.active {
                margin-left: 250px;
                width: calc(100% - 250px);
            }
        }
    </style>
</head>
<body>
    <div class="wrapper d-flex">
        <!-- Sidebar -->
        <nav class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h3>Painel do Professor</h3>
                <strong>PP</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#turmas-tab" data-bs-toggle="tab">
                        <i class="bi bi-house-door"></i> Minhas Turmas
                    </a>
                </li>
                <li>
                    <a href="#notas-tab" data-bs-toggle="tab" class="<?= !$turma_selecionada ? 'disabled' : '' ?>">
                        <i class="bi bi-journal-bookmark"></i> Lançar Notas
                    </a>
                </li>
                <li>
                    <a href="#config-tab" data-bs-toggle="tab">
                        <i class="bi bi-gear"></i> Configurações
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div class="main-content" id="content">
            <!-- Top Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarToggle" class="btn btn-outline-secondary">
                        <i class="bi bi-list"></i>
                    </button>
                    
                    <div class="ms-auto">
                        <span class="navbar-text me-3">
                            Olá, <strong><?= $professor_nome ?></strong>
                        </span>
                        <a href="logout.php" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-box-arrow-right"></i> Sair
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Tab Content -->
            <div class="container-fluid mt-4">
                <div class="tab-content">
                    <!-- Turmas Tab -->
                    <div class="tab-pane fade show active" id="turmas-tab">
                        <div class="card shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h4 class="mb-0"><i class="bi bi-house-door me-2"></i>Minhas Turmas</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover" id="tabelaTurmas">
                                        <thead>
                                            <tr>
                                                <th>Turma</th>
                                                <th>Disciplina</th>
                                                <th>Período</th>
                                                <th>Alunos</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($turmas as $turma): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($turma['turma']) ?></td>
                                                    <td><?= htmlspecialchars($turma['disciplina']) ?></td>
                                                    <td><?= htmlspecialchars($turma['periodo']) ?></td>
                                                    <td><?= $turma['total_alunos'] ?></td>
                                                    <td>
                                                        <a href="?turma_id=<?= $turma['id'] ?>#notas-tab" class="btn btn-sm btn-primary">
                                                            <i class="bi bi-journal-bookmark"></i> Lançar Notas
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Notas Tab -->
                    <div class="tab-pane fade" id="notas-tab">
                        <?php if ($turma_selecionada): ?>
                            <div class="card shadow-sm">
                                <div class="card-header bg-primary text-white">
                                    <h4 class="mb-0">
                                        <i class="bi bi-journal-bookmark me-2"></i>
                                        Lançamento de Notas - <?= htmlspecialchars($turma_selecionada['nome']) ?>
                                    </h4>
                                </div>
                                <div class="card-body">
                                    <div class="mb-4">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                                                    <input type="text" id="filtroAluno" class="form-control" placeholder="Pesquisar aluno...">
                                                </div>
                                            </div>
                                            <div class="col-md-6 text-end">
                                                <button id="btnSalvarTudo" class="btn btn-success">
                                                    <i class="bi bi-save"></i> Salvar Todas as Notas
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <table class="table table-hover" id="tabelaNotas">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Aluno</th>
                                                    <th class="text-center">MAC</th>
                                                    <th class="text-center">PP</th>
                                                    <th class="text-center">PT</th>
                                                    <th class="text-center">Média</th>
                                                    <th class="text-center">Estado</th>
                                                    <th class="text-center">Ações</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($alunos_turma as $aluno): 
                                                    $estado_class = strtolower($aluno['estado'] ?? '');
                                                    $iniciais = substr($aluno['nome'], 0, 1) . substr($aluno['nome'], strrpos($aluno['nome'], ' ') + 1, 1);
                                                ?>
                                                    <tr data-id="<?= $aluno['id'] ?>">
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="avatar me-2"><?= strtoupper($iniciais) ?></div>
                                                                <div>
                                                                    <div class="fw-bold"><?= htmlspecialchars($aluno['nome']) ?></div>
                                                                    <small class="text-muted"><?= htmlspecialchars($aluno['codigo']) ?></small>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="text-center">
                                                            <input type="number" class="form-control nota mac" 
                                                                   value="<?= $aluno['mac'] ?? '' ?>" min="0" max="20" step="0.1">
                                                        </td>
                                                        <td class="text-center">
                                                            <input type="number" class="form-control nota pp" 
                                                                   value="<?= $aluno['pp'] ?? '' ?>" min="0" max="20" step="0.1">
                                                        </td>
                                                        <td class="text-center">
                                                            <input type="number" class="form-control nota pt" 
                                                                   value="<?= $aluno['pt'] ?? '' ?>" min="0" max="20" step="0.1">
                                                        </td>
                                                        <td class="text-center">
                                                            <input type="text" class="form-control media <?= $estado_class ?>" 
                                                                   value="<?= $aluno['media'] ?? '' ?>" readonly>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge estado <?= $estado_class ?>">
                                                                <?= $aluno['estado'] ?? '' ?>
                                                            </span>
                                                        </td>
                                                        <td class="text-center">
                                                            <button class="btn btn-sm btn-primary btn-salvar">
                                                                <i class="bi bi-save"></i> Salvar
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle me-2"></i> Selecione uma turma na aba "Minhas Turmas" para lançar notas.
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Configurações Tab -->
                    <div class="tab-pane fade" id="config-tab">
                        <div class="row">
                            <div class="col-lg-8 mx-auto">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        <h4 class="mb-0"><i class="bi bi-gear me-2"></i>Minhas Configurações</h4>
                                    </div>
                                    <div class="card-body">
                                        <?php if (isset($mensagem_sucesso)): ?>
                                            <div class="alert alert-success">
                                                <?= $mensagem_sucesso ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <form method="POST">
                                            <input type="hidden" name="atualizar_config" value="1">
                                            <div class="mb-3">
                                                <label for="nome" class="form-label">Nome Completo</label>
                                                <input type="text" class="form-control" id="nome" name="nome" 
                                                       value="<?= $professor_nome ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="email" class="form-label">Email</label>
                                                <input type="email" class="form-control" id="email" 
                                                       value="<?= $professor_email ?>" disabled>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="senha" class="form-label">Nova Senha</label>
                                                <input type="password" class="form-control" id="senha" name="senha" 
                                                       placeholder="Deixe em branco para manter a atual">
                                                <div class="form-text">Mínimo de 8 caracteres</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="confirmar_senha" class="form-label">Confirmar Nova Senha</label>
                                                <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha">
                                            </div>
                                            
                                            <div class="d-grid gap-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="bi bi-save me-1"></i> Salvar Alterações
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação -->
    <div class="modal fade" id="confirmModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-warning me-2"></i>Confirmação</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza que deseja salvar todas as notas desta turma?</p>
                    <div class="alert alert-info mt-3">
                        <i class="bi bi-info-circle me-2"></i>Esta ação não pode ser desfeita.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="confirmSave">Salvar Tudo</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle Sidebar
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('content').classList.toggle('active');
        });

        // Ativar tab conforme URL
        if (window.location.hash) {
            const tabTrigger = new bootstrap.Tab(document.querySelector(`a[href="${window.location.hash}"]`));
            tabTrigger.show();
        }

        // Função para calcular média e estado
        function calcularMediaEstado(input) {
            const tr = input.closest('tr');
            const mac = parseFloat(tr.querySelector('.mac').value) || 0;
            const pp = parseFloat(tr.querySelector('.pp').value) || 0;
            const pt = parseFloat(tr.querySelector('.pt').value) || 0;
            
            const media = ((mac + pp + pt) / 3).toFixed(1);
            let estado = '';

            if (mac > 0 && pp > 0 && pt > 0) {
                if (media >= 9.5) {
                    estado = 'Aprovado';
                } else if (media >= 7.5) {
                    estado = 'Recurso';
                } else {
                    estado = 'Reprovado';
                }
            }

            const mediaField = tr.querySelector('.media');
            const estadoBadge = tr.querySelector('.estado');
            
            mediaField.value = media;
            estadoBadge.textContent = estado;
            
            // Atualizar classes
            mediaField.className = 'form-control media';
            estadoBadge.className = 'badge estado';
            
            if (estado) {
                mediaField.classList.add(estado.toLowerCase());
                estadoBadge.classList.add(estado.toLowerCase());
            }
        }

        // Evento para cálculo automático
        document.querySelectorAll('.nota').forEach(input => {
            input.addEventListener('input', function() {
                // Limitar valor entre 0 e 20
                if (this.value > 20) this.value = 20;
                if (this.value < 0) this.value = 0;
                
                calcularMediaEstado(this);
            });
        });

        // Salvar notas individuais
        document.querySelectorAll('.btn-salvar').forEach(btn => {
            btn.addEventListener('click', function() {
                const tr = this.closest('tr');
                const matriculaId = tr.dataset.id;
                const mac = tr.querySelector('.mac').value;
                const pp = tr.querySelector('.pp').value;
                const pt = tr.querySelector('.pt').value;
                const media = tr.querySelector('.media').value;
                const estado = tr.querySelector('.estado').textContent;
                
                // Validação
                if (!mac || !pp || !pt) {
                    alert('Preencha todas as notas antes de salvar');
                    return;
                }
                
                this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Salvando...';
                this.disabled = true;
                
                // Simular requisição AJAX
                setTimeout(() => {
                    this.innerHTML = '<i class="bi bi-save"></i> Salvar';
                    this.disabled = false;
                    
                    // Mostrar feedback
                    showToast('success', 'Notas salvas com sucesso!');
                }, 1000);
            });
        });

        // Salvar todas as notas
        document.getElementById('btnSalvarTudo')?.addEventListener('click', function() {
            const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
            modal.show();
        });

        document.getElementById('confirmSave')?.addEventListener('click', function() {
            const modal = bootstrap.Modal.getInstance(document.getElementById('confirmModal'));
            modal.hide();
            
            const btn = document.getElementById('btnSalvarTudo');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Salvando...';
            btn.disabled = true;
            
            // Simular requisição AJAX para salvar tudo
            setTimeout(() => {
                btn.innerHTML = '<i class="bi bi-save"></i> Salvar Todas as Notas';
                btn.disabled = false;
                
                // Mostrar feedback
                showToast('success', 'Todas as notas foram salvas com sucesso!');
            }, 2000);
        });

        // Filtro de alunos
        document.getElementById('filtroAluno')?.addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tabelaNotas tbody tr');
            
            rows.forEach(row => {
                const nome = row.querySelector('td:first-child').textContent.toLowerCase();
                row.style.display = nome.includes(filter) ? '' : 'none';
            });
        });

        // Validação do formulário de configurações
        document.querySelector('form')?.addEventListener('submit', function(e) {
            const senha = document.getElementById('senha').value;
            const confirmarSenha = document.getElementById('confirmar_senha').value;
            
            if (senha !== '' && senha.length < 8) {
                alert('A senha deve ter no mínimo 8 caracteres');
                e.preventDefault();
                return;
            }
            
            if (senha !== confirmarSenha) {
                alert('As senhas não coincidem');
                e.preventDefault();
            }
        });

        // Função para mostrar toast de feedback
        function showToast(type, message) {
            const toast = document.createElement('div');
            toast.className = 'position-fixed bottom-0 end-0 p-3';
            toast.innerHTML = `
                <div class="toast show" role="alert">
                    <div class="toast-header bg-${type} text-white">
                        <strong class="me-auto">${type === 'success' ? 'Sucesso' : 'Erro'}</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            `;
            document.body.appendChild(toast);
            
            // Remover toast após 3 segundos
            setTimeout(() => {
                toast.remove();
            }, 3000);
        }
    });
    </script>
</body>
</html>