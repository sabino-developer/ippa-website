    <?php

    // initialize the session
    session_start();
    require_once "../controllers/config/connection.php";

    $pagename = "Tesorária";

    // check if the user is logged in, if not then redirect him to login page
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }


$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);


// Obtém o ID da matrícula da URL
$idmatri = isset($_GET["id"]) ? $_GET["id"] : null;

if ($idmatri !== null) {
    // Consulta SQL para realizar a pesquisa avançada
    $query = "SELECT ano.id as idano, matricula.id AS idmatri, inscricao.codigo, inscricao.nome, classe.nome AS Classe, turma.nturma AS Turma, 
        turma.sala AS Sala, classe.turno AS Periodo, cursos.nome AS Curso, valorpropina.valorpro AS valorUnita  
        FROM inscricao 
        INNER JOIN ano on inscricao.idano=ano.id
        INNER JOIN classe ON inscricao.idclasse = classe.id 
        INNER JOIN matricula ON inscricao.id = matricula.idInscr
        INNER JOIN turma ON turma.id = classe.idturma
        INNER JOIN valorpropina ON classe.id = valorpropina.idclasse
        INNER JOIN cursos ON matricula.idCurso = cursos.id 
        WHERE matricula.id = ?";

    try {
        // Prepara e executa a consulta
        $stmt = $conn->prepare($query);
        $stmt->execute([$idmatri]);
        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica se a consulta retornou algum resultado
        if ($dados) {
            $idano = $dados['idano'];
            $idmatri = $dados['idmatri'];
            $codigo = $dados['codigo'];
            $nome = $dados['nome'];
            $Classe = $dados['Classe'];
            $Turma = $dados['Turma'];
            $Sala = $dados['Sala'];
            $Periodo = $dados['Periodo'];
            $Curso = $dados['Curso'];
            $valorUnita = $dados['valorUnita'];
        } else {
            // Exibe uma mensagem caso não haja resultados
            echo "<span class='text-danger'>Nenhum resultado encontrado para o ID de matrícula fornecido.</span>";
        }
    } catch (PDOException $e) {
        // Exibe uma mensagem de erro caso ocorra algum problema na consulta
        echo "<span class='text-danger'>Erro ao executar a consulta: " . $e->getMessage() . "</span>";
    }
} else {
    // Exibe uma mensagem se o ID de matrícula não foi fornecido
    echo "<span class='text-danger'>ID de matrícula não fornecido na URL.</span>";
}
?>

    <!doctype html>
    <html lang="en" dir="ltr">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="icon" href="favicon.ico" type="image/x-icon" />
        <title><?= $pagename; ?> </title>

        <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />

        <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />

        <link rel="stylesheet" href="assets/css/style.min.css" />
        <link rel="stylesheet" href="assets/css/all.min.css" />
        <script src="https://unpkg.com/feather-icons"></script>
        <script src="assets/css/feather-icons.css"></script>
        <script src="../assets/js/jquery-3.6.0.min.js"></script>
    </head>

    <body class="font-muli theme-cyan gradient">

        <?php

        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }

        ?>

        <div id="main_content">
            <?php

            if (file_exists('sections/min-sidebar.php')) {
                require_once "sections/min-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
            }

            ?>

            <?php

            if (file_exists('sections/right-sidebar.php')) {
                require_once "sections/right-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
            }

            ?>

            <?php

            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }

            ?>

            <?php

            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }

            ?>

            <?php

            if (file_exists('sections/sidebar.php')) {
                require_once "sections/sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
            }

            ?>


            <div class="page">

                <?php

                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }

                ?>

                <div class="section-body">
                    <div class="container-fluid">
                        <div class="d-flex justify-content-between align-items-center ">
                            <div class="header-action">
                                <h1 class="page-title"><?= $pagename ?></h1>
                                <ol class="breadcrumb page-breadcrumb">
                                    <li class="breadcrumb-item"><a href="tesoraria">Tesoraria</a></li>
                                    <li class="breadcrumb-item"><a href="propina">Área de Estudante</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Pagamento de Propina</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>

            <?php
                // Verifica se a variável $nome está definida
                if (!isset($nome)) {
                    $nome = ''; // Define um valor padrão para $nome se não estiver definido
                }

                // Verifica se a variável $codigo está definida
                if (!isset($codigo)) {
                    $codigo = ''; // Define um valor padrão para $codigo se não estiver definido
                }

                // Verifica se a variável $Curso está definida
                if (!isset($Curso)) {
                    $Curso = ''; // Define um valor padrão para $Curso se não estiver definido
                }

                // Verifica se a variável $Classe está definida
                if (!isset($Classe)) {
                    $Classe = ''; // Define um valor padrão para $Classe se não estiver definido
                }

                // Verifica se a variável $Sala está definida
                if (!isset($Sala)) {
                    $Sala = ''; // Define um valor padrão para $Sala se não estiver definido
                }

                // Verifica se a variável $Turma está definida
                if (!isset($Turma)) {
                    $Turma = ''; // Define um valor padrão para $Turma se não estiver definido
                }

                // Verifica se a variável $Periodo está definida
                if (!isset($Periodo)) {
                    $Periodo = ''; // Define um valor padrão para $Periodo se não estiver definido
                }?>

                   
        <?php
            
            // Array com os meses
            $meses = array("SET", "OUT", "NOV", "DEZ", "JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL");

            // Definir todos os meses como não pagos por padrão
            $pagamentos_meses = array_fill_keys($meses, 'btn-danger');

            // Verifica se a conexão está disponível
            if (isset($pdo)) {
                // Consulta SQL para buscar os meses pagos na tabela propinas
                $sql = "SELECT mes FROM propinas WHERE mes IN ('" . implode("','", $meses) . "')";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $pagamentos = $stmt->fetchAll(PDO::FETCH_COLUMN);

                // Define o estado de pagamento de cada mês
                foreach ($pagamentos as $mes_pago) {
                    $pagamentos_meses[$mes_pago] = 'btn-success';
                }
            }
            ?>

            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($meses as $mes): ?>
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <!-- Adiciona a classe btn-success se o mês estiver pago e btn-danger se não estiver pago -->
                                        <input type="text" class="form-control btn <?= $pagamentos_meses[$mes]; ?>" id="total<?= $mes; ?>" name="total[]" readonly value="<?= $mes; ?>">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>


                

                <div class="section-body mt-4">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-4 col-lg-5 col-md-12">
                                <div class="card">
                                    <div class="card-body d-flex flex-column">
                                        <h5><a href="#"><?= $nome; ?></a></h5>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-vcenter mb-0">
                                            <tbody>
                                                <tr>
                                                    <td class="w20">
                                                        <i data-feather="hash"></i>
                                                    </td>
                                                    <td class="tx-medium">Código</td>
                                                    <td class="text-right"><?= $codigo; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="w20">
                                                        <i data-feather="layers"></i>
                                                    </td>
                                                    <td class="tx-medium">Nível</td>
                                                    <td class="text-right"><?= $Curso; ?></td>
                                                </tr>
                                                <tr>
                                                    <td><i data-feather="repeat"></i></td>
                                                    <td class="tx-medium">Classe</td>
                                                    <td class="text-right"><?= $Classe; ?></td>
                                                </tr>
                                                <tr>
                                                    <td><i data-feather="book"></i></td>
                                                    <td class="tx-medium">Sala</td>
                                                    <td class="text-right"><?= $Sala; ?></td>
                                                </tr>
                                                <tr>
                                                    <td><i data-feather="users"></i></td>
                                                    <td class="tx-medium">Turma</td>
                                                    <td class="text-right"><?= $Turma; ?></td>
                                                </tr>
                                                <tr>
                                                    <td><i data-feather="calendar"></i></td>
                                                    <td class="tx-medium">Período</td>
                                                    <td class="text-right"><?= $Periodo; ?></td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8 col-lg-7 col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="mt-4">Informações sobre o Pagamento</h5>
                                        <form action="../controllers/create/inserirPropinas1.php" method="POST" enctype="multipart/form-data">
                                            <input type="hidden" name="idmatri" value="<?= $idmatri ?? ''; ?>">
                                            <input type="hidden" name="idano" value="<?= $idano ?? ''; ?>">

                                            <div class="row clearfix">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="valorpro">Valor da Propina</label>
                                                        <input type="text" class="form-control" id="valorpro" name="valorUnita" value="<?= $valorUnita ?? ''; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="qtd">Quantidade</label>
                                                        <input type="number" class="form-control" id="qtd" name="qtd" onchange="calcularTotal()">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="valorpago">Valor Pago</label>
                                                        <input type="number" class="form-control" id="valorpago" name="valorpago" value="" onchange="calcularTotal()">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="troco">Troco</label>
                                                        <input type="number" class="form-control" id="troco" name="troco" value="" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="total">Total a Pagar</label>
                                                        <input type="number" class="form-control" id="total" name="total" value="" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="datapagemento">Data do Pagamento</label>
                                                        <input type="date" class="form-control" id="datapagemento" name="datapagemento">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="metodoPag">Método de Pagamento</label>
                                                        <select class="form-control show-tick" required name="metodoPag">
                                                            <option value="" selected disabled>-- Selecione --</option>
                                                            <option value="Dinheiro">Dinheiro</option>
                                                            <option value="Transferência">Transferência</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="mes">Mês</label>
                                                        <select class="form-control show-tick" required name="mes">
                                                            <option value="" selected disabled>-- Selecione --</option>
                                                            <?php foreach ($meses as $mes): ?>
                                                                <option value="<?= $mes; ?>"><?= $mes; ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                // Variável para controlar se a mensagem já foi exibida
                                var mensagemExibida = false;

                                // Função para calcular o total e verificar se o valor pago é inferior
                                function calcularTotal() {
                                    var valorpro = parseFloat(document.getElementById('valorpro').value);
                                    var qtd = parseInt(document.getElementById('qtd').value);
                                    var valorpago = parseFloat(document.getElementById('valorpago').value);

                                    var total = valorpro * qtd;
                                    var troco = valorpago - total;

                                    // Atualiza o campo de total a pagar
                                    document.getElementById('total').value = total;

                                    // Verifica se o valor pago é inferior ao total e exibe uma mensagem se necessário
                                    if (valorpago && valorpago < total && !mensagemExibida) {
                                        alert("O valor pago é inferior ao total a pagar!");
                                        mensagemExibida = true; // Atualiza o estado da mensagem
                                    }

                                    // Atualiza o campo de troco
                                    document.getElementById('troco').value = (valorpago >= total) ? troco : 0;
                                }

                                // Função para redefinir o estado da mensagem ao focar outro campo
                                function resetarMensagem() {
                                    mensagemExibida = false;
                                }

                                // Adiciona o evento de foco aos campos de quantidade e valor pago
                                document.getElementById('qtd').addEventListener('focus', resetarMensagem);
                                document.getElementById('valorpago').addEventListener('focus', resetarMensagem);
                            </script>

                        </div>
                    </div>
                </div>


              
                <?php

                if (file_exists('sections/footer.php')) {
                    require_once "sections/footer.php";
                } else {
                    echo "<span class='text-danger'>O arquivo footer foi encontrado!</span>";
                }

                ?>

            </div>
        </div>

        <script src="../assets/bundles/lib.vendor.bundle.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script type="text/javascript" src="assets/js/icons.js"></script>

        <script src="../assets/bundles/counterup.bundle.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script src="../assets/bundles/apexcharts.bundle.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script src="../assets/bundles/summernote.bundle.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>

        <script src="../assets/js/core.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script src="assets/js/page/index.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script src="assets/js/page/summernote.js" type="a212ea8ab2b812aea27dc828-text/javascript"></script>
        <script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="a212ea8ab2b812aea27dc828-|49" defer></script>
        <script>
            (function() {
                var js =
                    "window['__CF$cv$params']={r:'7dd4b60b89b24931',m:'.cXqaoYizFYIM2ITNxA9eEVmDv4Vz3fYsgXfUCOHeLU-1687774758-0-AaNNKYA1O0cJUoTaei9YUkbG1v2uoZ6/MbBj6UCkMC5L'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
                var _0xh = document.createElement('iframe');
                _0xh.height = 1;
                _0xh.width = 1;
                _0xh.style.position = 'absolute';
                _0xh.style.top = 0;
                _0xh.style.left = 0;
                _0xh.style.border = 'none';
                _0xh.style.visibility = 'hidden';
                document.body.appendChild(_0xh);

                function handler() {
                    var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
                    if (_0xi) {
                        var _0xj = _0xi.createElement('script');
                        _0xj.nonce = '';
                        _0xj.innerHTML = js;
                        _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
                    }
                }
                if (document.readyState !== 'loading') {
                    handler();
                } else if (window.addEventListener) {
                    document.addEventListener('DOMContentLoaded', handler);
                } else {
                    var prev = document.onreadystatechange || function() {};
                    document.onreadystatechange = function(e) {
                        prev(e);
                        if (document.readyState !== 'loading') {
                            document.onreadystatechange = prev;
                            handler();
                        }
                    };
                }
            })();
        </script>
        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816" integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw==" data-cf-beacon='{"rayId":"7dd4b60b89b24931","version":"2023.4.0","r":1,"b":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":100}' crossorigin="anonymous"></script>
        <script>
            feather.replace()
        </script>
    </body>

    </html>
