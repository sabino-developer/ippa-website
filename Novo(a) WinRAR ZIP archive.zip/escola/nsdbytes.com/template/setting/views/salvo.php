<?php
// Inicia a sessão
session_start();

// Requer o arquivo de conexão ao banco de dados
require_once "../controllers/config/connection.php";

// Verifica se o parâmetro "id" foi passado via GET na URL
if (isset($_GET["id"])) {
    // Obtém o ID do departamento da URL
    $idDepartamento = $_GET["id"];

    try {
        // Consulta SQL para buscar os nomes dos funcionários de um departamento específico
        $query = "SELECT funcionarios.nome FROM funcao INNER JOIN departamentos ON funcao.idDep = departamentos.id INNER JOIN funcionarios ON departamentos.idFunc = funcionarios.id WHERE departamentos.id = :idDepartamento";
        $stmt = $conn->prepare($query);
        // Associa o valor do parâmetro :idDepartamento ao valor obtido da URL
        $stmt->bindParam(":idDepartamento", $idDepartamento, PDO::PARAM_INT);
        // Executa a consulta
        $stmt->execute();

        // Obtém os resultados da consulta como um array associativo
        $funcionarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Verifica se há funcionários encontrados para o departamento
        if ($funcionarios) {
            // Loop para exibir informações sobre cada funcionário
            foreach ($funcionarios as $funcionario) {
                echo "Nome: " . htmlspecialchars($funcionario['nome']) . "<br>";
                // Outras informações relevantes podem ser exibidas aqui
            }
        } else {
            echo "Nenhum funcionário encontrado para este departamento.";
        }
    } catch (PDOException $e) {
        echo "Erro na consulta: " . $e->getMessage();
    }
} else {
    echo "ID do departamento não fornecido na URL.";
}
?>