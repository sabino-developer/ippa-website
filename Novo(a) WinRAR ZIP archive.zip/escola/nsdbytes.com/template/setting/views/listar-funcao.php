<?php

    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

    $idDep = $_POST['id'];
    $stmt = $conn->prepare("SELECT * FROM funcao WHERE funcao.idDep = :id");
    $stmt->bindParam(':id', $idDep);
    $stmt->execute();
    $options = '<option selected disabled value=""> -- Selecione -- </option>';
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $options .= "<option value='{$row['id']}'>{$row['nome']}</option>";
    }
    echo $options;
?>
