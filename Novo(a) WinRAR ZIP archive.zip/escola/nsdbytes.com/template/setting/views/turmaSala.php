<?php
session_start();

if (file_exists('../controllers/config/connection.php')) {
    require_once "../controllers/config/connection.php";
} else {
    echo "<div class='alert alert-danger'>O arquivo connection não foi encontrado!</div>";
    exit;
}

$pagename = "Gestão de Salas/Turmas";

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login");
    exit;
}

$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);
?>
<!doctype html>
<html lang="pt" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title><?= $pagename ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/plugins/animate.css/animate.min.css">
    <link rel="stylesheet" href="../assets/plugins/sweetalert/sweetalert.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.min.css" />
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --morning-color: #f39c12;
            --afternoon-color: #9b59b6;
        }
        
        .morning-bg {
            background-color: rgba(243, 156, 18, 0.1);
            border-left: 4px solid var(--morning-color);
        }
        
        .afternoon-bg {
            background-color: rgba(155, 89, 182, 0.1);
            border-left: 4px solid var(--afternoon-color);
        }
        
        .tag-morning {
            background-color: rgba(243, 156, 18, 0.2);
            color: var(--morning-color);
        }
        
        .tag-afternoon {
            background-color: rgba(155, 89, 182, 0.2);
            color: var(--afternoon-color);
        }
        
        .shift-icon {
            font-size: 1.2rem;
            margin-right: 5px;
        }
    </style>
</head>

<body class="font-muli theme-cyan gradient">

    <?php if (isset($_GET['success']) && $_GET['success'] === 'true'): ?>
    <script>
        $(document).ready(function() {
            Swal.fire({
                title: 'Sucesso!',
                text: 'Operação realizada com sucesso.',
                icon: 'success',
                confirmButtonColor: '#3498db',
                timer: 3000,
                timerProgressBar: true
            });
        });
    </script>
    <?php endif; ?>

    <?php
    if (file_exists('sections/loader.php')) {
        require_once "sections/loader.php";
    }
    ?>

    <div id="main_content">
        <?php
        if (file_exists('sections/min-sidebar.php')) {
            require_once "sections/min-sidebar.php";
        }
        
        if (file_exists('sections/right-sidebar.php')) {
            require_once "sections/right-sidebar.php";
        }
        
        if (file_exists('sections/theme.php')) {
            require_once "sections/theme.php";
        }
        
        if (file_exists('sections/statistic-sidebar.php')) {
            require_once "sections/statistic-sidebar.php";
        }
        
        if (file_exists('sections/sidebar.php')) {
            require_once "sections/sidebar.php";
        }
        ?>

        <div class="page">
            <?php
            if (file_exists('sections/navbar.php')) {
                require_once "sections/navbar.php";
            }
            ?>

            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="header-action">
                            <h1 class="page-title">
                                <i class="fas fa-door-open mr-2"></i><?= $pagename ?>
                            </h1>
                            <ol class="breadcrumb page-breadcrumb">
                                <li class="breadcrumb-item"><a href="areaPedagogica"><i class="fas fa-home mr-2"></i>Área Pedagógica</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?= $pagename ?></li>
                            </ol>
                        </div>
                        <button class="btn btn-primary" data-toggle="modal" data-target="#addRoomModal">
                            <i class="fas fa-plus-circle mr-2"></i>Nova Sala/Turma
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card animated fadeIn">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-list mr-2"></i>Salas e Turmas</h3>
                                    <div class="card-options">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-outline-primary active" data-shift="all">Todos</button>
                                            <button type="button" class="btn btn-sm btn-outline-warning" data-shift="Manhã">Manhã</button>
                                            <button type="button" class="btn btn-sm btn-outline-info" data-shift="Tarde">Tarde</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="roomsTable" class="table table-hover table-vcenter table_custom text-nowrap spacing5 border-style mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Sala</th>
                                                    <th>Turma</th> 
                                                    <th>Turno</th>
                                                    <th>Estado</th>  
                                                    <th>Ações</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sql = "SELECT * FROM sala ORDER BY 
                                                        CASE WHEN turno = 'Manhã' THEN 1 ELSE 2 END, 
                                                        sala ASC";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->execute();
                                                
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    $shiftClass = $row['turno'] == 'Manhã' ? 'morning-bg' : 'afternoon-bg';
                                                    $tagClass = $row['turno'] == 'Manhã' ? 'tag-morning' : 'tag-afternoon';
                                                    $statusClass = $row['estado'] == 'Ativo' ? 'tag-success' : 'tag-danger';
                                                    $shiftIcon = $row['turno'] == 'Manhã' ? 'sun' : 'moon';
                                                ?>
                                                <tr class="<?= $shiftClass ?>" data-shift="<?= $row['turno'] ?>">
                                                    <td>
                                                        <strong><?= $row['sala'] ?></strong>
                                                    </td>
                                                    <td>
                                                        <?= $row['nturma'] ?>
                                                    </td>
                                                    <td>
                                                        <span class="tag <?= $tagClass ?>">
                                                            <i data-feather="<?= $shiftIcon ?>" class="shift-icon"></i>
                                                            <?= $row['turno'] ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="tag <?= $statusClass ?>">
                                                            <?= $row['estado'] ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-icon btn-sm btn-outline-primary edit-room" 
                                                                data-id="<?= $row['id'] ?>" 
                                                                data-sala="<?= $row['sala'] ?>"
                                                                data-turma="<?= $row['nturma'] ?>"
                                                                data-turno="<?= $row['turno'] ?>"
                                                                data-estado="<?= $row['estado'] ?>"
                                                                title="Editar">
                                                            <i data-feather="edit"></i>
                                                        </button>
                                                        <button class="btn btn-icon btn-sm btn-outline-danger delete-room" 
                                                                data-id="<?= $row['id'] ?>" 
                                                                title="Eliminar">
                                                            <i data-feather="trash-2"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card animated fadeIn">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-info-circle mr-2"></i>Informações</h3>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        Aqui você pode gerenciar as salas e turmas da instituição. 
                                        Cada sala deve ter um identificador único e pode ser associada a diferentes turnos.
                                    </div>
                                    <div class="mb-4">
                                        <h6><i class="fas fa-sun text-warning mr-2"></i>Turno da Manhã</h6>
                                        <p class="text-muted">Turmas que funcionam no período matutino.</p>
                                    </div>
                                    <div class="mb-4">
                                        <h6><i class="fas fa-moon text-info mr-2"></i>Turno da Tarde</h6>
                                        <p class="text-muted">Turmas que funcionam no período vespertino.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Room Modal -->
    <div class="modal fade" id="addRoomModal" tabindex="-1" role="dialog" aria-labelledby="addRoomModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addRoomModalLabel"><i class="fas fa-plus-circle mr-2"></i>Nova Sala/Turma</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="roomForm" action="../controllers/create/turmaSala.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="idano" value="<?= $id ?>">
                        <div class="form-group">
                            <label><i class="fas fa-door-open mr-2"></i>Sala</label>
                            <input type="text" name="sala" class="form-control" required placeholder="Ex: Sala 1">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-users mr-2"></i>Turma</label>
                            <input type="text" name="nturma" class="form-control" required placeholder="Ex: M01 ou T02">
                            <small class="text-muted">Use M para manhã e T para tarde seguido do número</small>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-clock mr-2"></i>Turno</label>
                            <select class="form-control" name="turno" required>
                                <option value="" selected disabled>-- Selecione --</option>
                                <option value="Manhã">Manhã</option>
                                <option value="Tarde">Tarde</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Room Modal -->
    <div class="modal fade" id="editRoomModal" tabindex="-1" role="dialog" aria-labelledby="editRoomModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editRoomModalLabel"><i class="fas fa-edit mr-2"></i>Editar Sala/Turma</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="editRoomForm" action="../controllers/update/turmaSala.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="id" id="editId">
                        <input type="hidden" name="idano" value="<?= $id ?>">
                        <div class="form-group">
                            <label><i class="fas fa-door-open mr-2"></i>Sala</label>
                            <input type="text" name="sala" id="editSala" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-users mr-2"></i>Turma</label>
                            <input type="text" name="nturma" id="editTurma" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-clock mr-2"></i>Turno</label>
                            <select class="form-control" name="turno" id="editTurno" required>
                                <option value="Manhã">Manhã</option>
                                <option value="Tarde">Tarde</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-check-circle mr-2"></i>Estado</label>
                            <select class="form-control" name="estado" id="editEstado" required>
                                <option value="Ativo">Ativo</option>
                                <option value="Inativo">Inativo</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Atualizar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/bundles/dataTables.bundle.js"></script>
    <script src="../assets/plugins/sweetalert/sweetalert.min.js"></script>
    
    <script src="../assets/js/core.js"></script>
    <script src="assets/js/table/datatable.js"></script>
    
    <script>
        feather.replace();
        
        $(document).ready(function() {
            // Initialize DataTable
            $('#roomsTable').DataTable({
                responsive: true,
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/pt-PT.json'
                }
            });
            
            // Filter by shift
            $('[data-shift]').click(function() {
                const shift = $(this).data('shift');
                $('.btn-group button').removeClass('active');
                $(this).addClass('active');
                
                if (shift === 'all') {
                    $('tr[data-shift]').show();
                } else {
                    $('tr[data-shift]').hide();
                    $(`tr[data-shift="${shift}"]`).show();
                }
            });
            
            // Edit room
            $('.edit-room').click(function() {
                const id = $(this).data('id');
                const sala = $(this).data('sala');
                const turma = $(this).data('turma');
                const turno = $(this).data('turno');
                const estado = $(this).data('estado');
                
                $('#editId').val(id);
                $('#editSala').val(sala);
                $('#editTurma').val(turma);
                $('#editTurno').val(turno);
                $('#editEstado').val(estado);
                
                $('#editRoomModal').modal('show');
            });
            
            // Delete room
            $('.delete-room').click(function() {
                const roomId = $(this).data('id');
                
                Swal.fire({
                    title: 'Tem certeza?',
                    text: "Você não poderá reverter isso!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sim, deletar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `../controllers/delete/turmaSala.php?id=${roomId}`;
                    }
                });
            });
            
            // Form validation
            $('#roomForm').on('submit', function(e) {
                const turma = $('input[name="nturma"]').val().toUpperCase();
                const turno = $('select[name="turno"]').val();
                
                // Validate turma format
                if ((turno === 'Manhã' && !turma.startsWith('M')) || 
                    (turno === 'Tarde' && !turma.startsWith('T'))) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Formato inválido',
                        text: `Para o turno ${turno}, a turma deve começar com ${turno === 'Manhã' ? 'M' : 'T'}`,
                        icon: 'error',
                        confirmButtonColor: '#3498db'
                    });
                }
            });
        });
    </script>
</body>
</html>