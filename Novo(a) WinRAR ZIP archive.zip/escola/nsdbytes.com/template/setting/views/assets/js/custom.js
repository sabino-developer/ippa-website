// Função para mostrar/ocultar senha
function mostrarSenha() {
    var passwordInput = document.getElementById("password");
    var showPasswordIcon = document.getElementById("showPasswordIcon");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        showPasswordIcon.classList.remove("fa-eye");
        showPasswordIcon.classList.add("fa-eye-slash");
    } else {
        passwordInput.type = "password";
        showPasswordIcon.classList.remove("fa-eye-slash");
        showPasswordIcon.classList.add("fa-eye");
    }
}

// Evento para mostrar/ocultar senha ao clicar no ícone
document.getElementById("showPasswordIcon").addEventListener("click", mostrarSenha);
