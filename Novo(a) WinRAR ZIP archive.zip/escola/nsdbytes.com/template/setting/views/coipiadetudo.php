                            <form action="../controllers/create/atribuirDisCla.php" method="POST" id="formulario">
                            <div class="row clearfix">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Classe</label>
                                        <select class="form-control show-tick" id="cursos" required name="idclasse">
                                            <option value="" selected disabled>-- Selecione --</option>
                                            <?php
                                            // Realiza a consulta no banco de dados para obter as classes
                                            $stmt_classe = $conn->query("SELECT * FROM classe");

                                            // Itera sobre os resultados e adiciona as opções ao select
                                            while ($row_classe = $stmt_classe->fetch(PDO::FETCH_ASSOC)) {
                                                echo "<option value='{$row_classe['id']}'>{$row_classe['nome']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Quantidade de Disciplinas</label>
                                        <input type="number" id="quantidade" name="qtd" class="form-control" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row clearfix" id="disciplinas">
                                <!-- Este espaço é reservado para os campos de disciplinas adicionados dinamicamente -->
                            </div>
                            <div class="row clearfix">
                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </form>

                        <script>
                            document.getElementById('quantidade').addEventListener('input', function() {
                                var quantidade = parseInt(this.value);
                                var disciplinasDiv = document.getElementById('disciplinas');
                                disciplinasDiv.innerHTML = '';

                                for (var i = 0; i < quantidade; i++) {
                                    var div = document.createElement('div');
                                    div.classList.add('col-md-12', 'col-sm-12');

                                    var formGroup = document.createElement('div');
                                    formGroup.classList.add('form-group');

                                    var label = document.createElement('label');
                                    label.textContent = 'Disciplina ' + (i + 1);

                                    var select = document.createElement('select');
                                    select.classList.add('form-control', 'show-tick');
                                    select.setAttribute('name', 'iddisciplina[]');
                                    select.setAttribute('required', 'required');

                                    var defaultOption = document.createElement('option');
                                    defaultOption.value = '';
                                    defaultOption.textContent = '-- Selecione --';
                                    defaultOption.setAttribute('selected', 'selected');
                                    defaultOption.setAttribute('disabled', 'disabled');

                                    select.appendChild(defaultOption);

                                    <?php
                                    // Realiza a consulta no banco de dados para obter as disciplinas
                                    $stmt_disciplina = $conn->query("SELECT * FROM disciplinas");

                                    // Itera sobre os resultados e adiciona as opções ao select
                                    while ($row_disciplina = $stmt_disciplina->fetch(PDO::FETCH_ASSOC)) {
                                        echo "var option = document.createElement('option');";
                                        echo "option.value = '{$row_disciplina['id']}';";
                                        echo "option.textContent = '{$row_disciplina['ndisciplina']}';";
                                        echo "select.appendChild(option);";
                                    }
                                    ?>

                                    formGroup.appendChild(label);
                                    formGroup.appendChild(select);
                                    div.appendChild(formGroup);
                                    disciplinasDiv.appendChild(div);
                                }
                            });
                        </script>



                        <?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit; // Termina a execução do script se o arquivo de conexão não for encontrado
}

// Verifica se o método de requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Verifica se os dados foram recebidos corretamente
        if (isset($_POST['idclasse']) && isset($_POST['qtd']) && isset($_POST['iddisciplina'])) {
            // Conexão com o banco de dados (substitua pelos seus detalhes de conexão)
            $conn = new PDO("mysql:host=seu_host;dbname=seu_banco_de_dados", "seu_usuario", "sua_senha");
            // Define o modo de erro do PDO como exceção
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Inicia a transação
            $conn->beginTransaction();

            // Prepara a instrução SQL para inserir na tabela atribuirDisCla
            $stmt = $conn->prepare("INSERT INTO atribuirDisCla (idclasse, iddisciplina, quantidade) VALUES (:idclasse, :iddisciplina, :quantidade)");

            // Obtém os valores do formulário
            $idclasse = $_POST['idclasse'];
            $iddisciplinas = $_POST['iddisciplina']; // Como é um array, obtemos todos os valores
            $quantidade = $_POST['qtd'];

            // Executa a inserção para cada disciplina selecionada
            foreach ($iddisciplinas as $iddisciplina) {
                // Atribui os valores aos parâmetros da instrução preparada e executa
                $stmt->execute(array(':idclasse' => $idclasse, ':iddisciplina' => $iddisciplina, ':quantidade' => $quantidade));
            }

            // Confirma a transação
            $conn->commit();

            // Exibe um alerta após a inserção
            echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/atribuirDisCla';</script>";
            exit();
        } else {
            // Exibe um alerta se os campos do formulário não foram enviados
            echo "<script>alert('Oops, campos obrigatórios não preenchidos!'); window.location.href = '../../views/atribuirDisCla';</script>";
        }
    } catch (PDOException $e) {
        // Se ocorrer um erro, cancela a transação
      
        
        // Exibe mensagem de erro
        echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/atribuirDisCla';</script>";
    }
} else {
    // Se o método não for POST, redireciona para a página de erro
    echo "<script>alert('Oops, Método inválido!'); window.location.href = '../../views/atribuirDisCla';</script>";
    exit();
}
?>




<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {
    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Obtém os dados do formulário
        $idano = $_POST["idano"];
        $idDep = $_POST["id"];
        $idFuncao = $_POST["idFuncao"];
        $nome = $_POST["nome"];
        $dataNasc = $_POST["dataNasc"];
        $genero = $_POST["genero"];
        $documento = $_POST["documento"];
        $endereco = $_POST["endereco"];
        $provincia = $_POST["provincia"];
        $telefone = $_POST["telefone"];
        $email = $_POST["email"];
        $avatar = ""; // Inicializa a variável avatar

        // Verifica se um arquivo de imagem foi enviado
        if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] === 0) {
            // Define o caminho de destino para o upload do arquivo
            $targetDir = "../uploads/";
            $fileName = $_FILES["avatar"]["name"];
            $targetFile = $targetDir . $fileName;

            // Move o arquivo temporário para o diretório de destino
            if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $targetFile)) {
                $avatar = $fileName; // Define o nome do arquivo como avatar
            } else {
                throw new Exception("Falha ao mover o arquivo para o diretório de destino.");
            }
        }

        // Prepara a instrução de inserção para funcionarios
        $query = "INSERT INTO funcionarios (idano, idDep, idFuncao, nome, dataNasc, genero, documento, endereco, provincia, telefone, email, avatar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$idano, $idDep, $idFuncao, $nome, $dataNasc, $genero, $documento, $endereco, $provincia, $telefone, $email, $avatar]);

        // Obtém o último ID inserido
        $lastInsertId = $conn->lastInsertId();

        // Prepara a instrução de inserção para usuários
        $query2 = "INSERT INTO users (idFuncionario, username, password, perfil) VALUES (?, ?, ?, ?)";
        $stmt2 = $conn->prepare($query2);

        // Define o nome de usuário e senha
        $username = $_POST["username"];
        $password = password_hash($_POST["codigo"], PASSWORD_DEFAULT);
        $perfil = $_POST["perfil"];

        // Executa a inserção dos dados do usuário
        $stmt2->execute([$lastInsertId, $username, $password, $perfil]);

        // Exibe um alerta após a inserção
        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/funcionarios';</script>";
    }
} catch (Exception $e) {
    // Exibe uma mensagem de erro caso ocorra uma exceção
    echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/funcionarios';</script>";
}
?>
<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {
    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Obtém os dados do formulário
        $idano = $_POST["idano"];
        $idDep = $_POST["id"];
        $idFuncao = $_POST["idFuncao"];
        $nome = $_POST["nome"];
        $dataNasc = $_POST["dataNasc"];
        $genero = $_POST["genero"];
        $documento = $_POST["documento"];
        $endereco = $_POST["endereco"];
        $provincia = $_POST["provincia"];
        $telefone = $_POST["telefone"];
        $email = $_POST["email"];
        $avatar = ""; // Inicializa a variável avatar

        // Verifica se um arquivo de imagem foi enviado
        if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] === 0) {
            // Define o caminho de destino para o upload do arquivo
            $targetDir = "../uploads/";
            $fileName = $_FILES["avatar"]["name"];
            $targetFile = $targetDir . $fileName;

            // Move o arquivo temporário para o diretório de destino
            if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $targetFile)) {
                $avatar = $fileName; // Define o nome do arquivo como avatar
            } else {
                throw new Exception("Falha ao mover o arquivo para o diretório de destino.");
            }
        }

        // Prepara a instrução de inserção para funcionarios
        $query = "INSERT INTO funcionarios (idano, idDep, idFuncao, nome, dataNasc, genero, documento, endereco, provincia, telefone, email, avatar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$idano, $idDep, $idFuncao, $nome, $dataNasc, $genero, $documento, $endereco, $provincia, $telefone, $email, $avatar]);

        // Obtém o último ID inserido
        $lastInsertId = $conn->lastInsertId();

        // Define o nome de usuário e senha
        $username = $_POST["username"];
        $password = password_hash($_POST["codigo"], PASSWORD_DEFAULT);
        $perfil = $_POST["perfil"];

        // Prepara a instrução de inserção para usuários
        $query2 = "INSERT INTO users (idFuncionario, username, password, perfil) VALUES (?, ?, ?, ?)";
        $stmt2 = $conn->prepare($query2);
        $stmt2->execute([$lastInsertId, $username, $password, $perfil]);

        // Exibe um alerta após a inserção
        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/funcionarios';</script>";
    }
} catch (Exception $e) {
    // Exibe uma mensagem de erro caso ocorra uma exceção
    echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/funcionarios';</script>";
}
?>
