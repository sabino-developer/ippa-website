<?php
    // Inicializa a sessão
    session_start();

    // Verifica se o arquivo de conexão existe
    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
        exit; // Encerra o script caso o arquivo não seja encontrado
    }

    // Verifica se o ID foi passado através do POST
    if(isset($_POST['id'])) {
        $id = $_POST['id'];

        // Prepara a consulta SQL utilizando prepared statements para evitar injeção de SQL
        $stmt = $conn->prepare("SELECT * FROM disciplinasprof WHERE disciplinasprof.idFuncionario = :id");
        $stmt->bindParam(':id', $id); // Vincula o parâmetro :id ao valor da variável $id
        $stmt->execute(); // Executa a consulta

        // Inicializa a variável $options com uma opção padrão
        $options = '<option selected disabled value=""> -- Selecione -- </option>';

        // Loop através dos resultados da consulta e constrói as opções para o select
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $options .= "<option value='{$row['id']}'>{$row['nome']}</option>";
        }

        echo $options; // Imprime as opções para o select
    } else {
        echo "<span class='text-danger'>ID não foi fornecido!</span>";
    }
?>
