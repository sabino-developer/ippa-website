<div class="col-sm-12">
    <div class="form-group">
        <label>Responsável</label>
        <select class="form-control show-tick" name="idFunc" required>
            <option value="" selected disabled>
                -- Selecione --
            </option>
            <?php
            // Consulta SQL para buscar os dados da tabela "classe"
            $sql = "SELECT id, nome FROM funcionarios";
            $stmt = $conn->prepare($sql);
            $stmt->execute();

            // Preenche as opções do select com os dados da consulta
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <option value="<?= $row['id']; ?>">
                    <?= $row['nome']; ?>
                </option>
            <?php
            }
            ?>
        </select>
    </div>
</div>