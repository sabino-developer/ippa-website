<?php
    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

    $pagename = "Secretária";

    // check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }

    $id = htmlspecialchars($_SESSION["id"]);
    $username = htmlspecialchars($_SESSION["username"]);
    $profile = htmlspecialchars($_SESSION["profile"]);
?>
<!doctype html>
<html lang="pt-BR" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Secretaria Geral</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.min.css" />
    
    <style>
        :root {
            --primary-color: #00CED1;
            --secondary-color: #000080;
            --accent-color: #e91e63;
            --dark-color: #2c3e50;
            --light-color: #f5f7fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: #333;
        }
        
        .page-title {
            font-weight: 700;
            color: var(--secondary-color);
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
            position: relative;
            display: inline-block;
        }
        
        .page-title:after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--accent-color);
            border-radius: 3px;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .breadcrumb-item a {
            color: var(--primary-color);
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
            margin-bottom: 20px;
            background: white;
            position: relative;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.1);
        }
        
        .card-body {
            padding: 25px;
            position: relative;
            z-index: 1;
        }
        
        .ribbon-box {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            z-index: 2;
        }
        
        .ribbon-box.orange {
            background: linear-gradient(135deg, #ff9800, #f57c00);
        }
        
        .ribbon-box.green {
            background: linear-gradient(135deg, #4caf50, #388e3c);
        }
        
        .ribbon-box.pink {
            background: linear-gradient(135deg, #e91e63, #c2185b);
        }
        
        .ribbon-box.purple {
            background: linear-gradient(135deg, #00CED1, #000080);
        }
        
        .card:hover .ribbon-box {
            transform: scale(1.1);
        }
        
        .my_sort_cut {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--dark-color);
            transition: all 0.3s ease;
            height: 100%;
            justify-content: center;
        }
        
        .my_sort_cut i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .my_sort_cut span {
            font-size: 1rem;
            text-align: center;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .card:hover .my_sort_cut i {
            transform: scale(1.2);
            color: var(--secondary-color);
        }
        
        .card:hover .my_sort_cut span {
            color: var(--secondary-color);
        }
        
        /* Pulse animation for important cards */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(156, 39, 176, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(156, 39, 176, 0); }
            100% { box-shadow: 0 0 0 0 rgba(156, 39, 176, 0); }
        }
        
        .pulse-card {
            animation: pulse 2s infinite;
        }
        
        /* Card backgrounds */
        .card-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0.1;
            z-index: 0;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .card {
                margin-bottom: 15px;
            }
            
            .my_sort_cut i {
                font-size: 2rem;
            }
        }
        
        /* Secretaria badge */
        .secretaria-badge {
            background: linear-gradient(135deg, #00CED1, #000080);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        /* Floating action button */
        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
            background: var(--secondary-color);
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }
        
        /* Quick stats panel */
        .quick-stats {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }
        
        .stat-item {
            text-align: center;
            padding: 10px;
        }
        
        .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #666;
        }
    </style>
</head>

<body class="font-muli theme-cyan gradient">

    <?php
        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }
    ?>
    
    <div id="main_content">
        <?php
            if (file_exists('sections/min-sidebar.php')) {
                require_once "sections/min-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/right-sidebar.php')) {
                require_once "sections/right-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }
        ?>

        <?php
            if (file_exists('sections/sidebar.php')) {
                require_once "sections/sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
            }
        ?>

        <div class="page">
            <?php
                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }
            ?>
                 <?php       
                $id = htmlspecialchars($_SESSION["id"]);
                $username = htmlspecialchars($_SESSION["username"]);
                $profile = htmlspecialchars($_SESSION["profile"]);

                // Consulta SQL para realizar a contagem
                $query = "SELECT COUNT(id) AS Totalinscricao FROM inscricao";
                $stmt = $conn->query($query);
                $dados = $stmt->fetch(PDO::FETCH_ASSOC);
                $Totalinscricao = $dados['Totalinscricao'];

                 $query = "SELECT COUNT(id) AS Totalmatricula FROM matricula";
                $stmt = $conn->query($query);
                $dados = $stmt->fetch(PDO::FETCH_ASSOC);
                $Totalmatricula = $dados['Totalmatricula'];

                 $query = "SELECT COUNT(id) AS Totalconfirmacao FROM confirmacao";
                $stmt = $conn->query($query);
                $dados = $stmt->fetch(PDO::FETCH_ASSOC);
                $Totalconfirmacao = $dados['Totalconfirmacao'];

                $query = "SELECT COUNT(id) AS Totalsala FROM sala";
                $stmt = $conn->query($query);
                $dados = $stmt->fetch(PDO::FETCH_ASSOC);
                $Totalsala = $dados['Totalsala'];


                $query = "SELECT COUNT(id) Estudante FROM matricula where estado = 'Activo' ";
                $stmt = $conn->query($query);
                $dados = $stmt->fetch(PDO::FETCH_ASSOC);
                $Estudante = $dados['Estudante'];



            ?>
            
            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="header-action">
                            <h1 class="page-title animate__animated animate__fadeInDown">Secretaria Geral</h1>
                            <ol class="breadcrumb page-breadcrumb animate__animated animate__fadeIn">
                                <li class="breadcrumb-item"><a href="dashboard"><i class="fas fa-home mr-2"></i>Menu Principal</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-user-secret mr-2"></i>Secretaria</li>
                            </ol>
                        </div>
                        <div class="animate__animated animate__fadeIn">
                            <span class="secretaria-badge"><i class="fas fa-user-tie mr-1"></i> <?= $profile ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Stats Panel -->
            <div class="section-body mt-3 animate__animated animate__fadeIn">
                <div class="container-fluid">
                    <div class="quick-stats">
                        <div class="row text-center">
                            <div class="col-6 col-md-3 stat-item">
                                <div class="stat-number"><?= $Totalinscricao ?></div>
                                <div class="stat-label">Inscritos</div>
                            </div>
                            <div class="col-6 col-md-3 stat-item">
                                <div class="stat-number"><?= $Totalmatricula ?></div>
                                <div class="stat-label">Matriculados</div>
                            </div>
                            <div class="col-6 col-md-3 stat-item">
                                <div class="stat-number"><?= $Totalconfirmacao ?></div>
                                <div class="stat-label">Confirmados</div>
                            </div>
                            <div class="col-6 col-md-3 stat-item">
                                <div class="stat-number"><?= $Totalsala ?></div>
                                <div class="stat-label">Salas</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section-body mt-2 animate__animated animate__fadeIn">
                <div class="container-fluid">
                    <div class="row clearfix row-deck">
                        <!-- Inscrição -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="50">
                            <div class="card">
                                <div class="card-bg" style="background-color: #ff9800;"></div>
                                <div class="card-body ribbon">
                                    <div class="ribbon-box orange" data-toggle="tooltip" title="Total de Inscritos"><?= $Totalinscricao ?></div>
                                    <a href="inscricao" class="my_sort_cut text-muted">
                                        <i class="fas fa-user-plus"></i>
                                        <span>Inscrição</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Matrícula -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="100">
                            <div class="card pulse-card">
                                <div class="card-bg" style="background-color: #4caf50;"></div>
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total de Matriculados"><?= $Totalmatricula ?></div>
                                    <a href="matriculas.php" class="my_sort_cut text-muted">
                                        <i class="fas fa-user-graduate"></i>
                                        <span>Matrícula</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Confirmação -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="150">
                            <div class="card">
                                <div class="card-bg" style="background-color: #e91e63;"></div>
                                <div class="card-body ribbon">
                                    <div class="ribbon-box pink" data-toggle="tooltip" title="Total de Alunos Confirmados"><?= $Totalconfirmacao ?></div>
                                    <a href="confirmacao" class="my_sort_cut text-muted">
                                        <i class="fas fa-check-double"></i>
                                        <span>Confirmação</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Estudante -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="200">
                            <div class="card">
                                <div class="card-bg" style="background-color: #00CED1;"></div>
                                <div class="card-body ribbon">
                                    <div class="ribbon-box purple" data-toggle="tooltip" title="Total de Estudantes"><?= $Estudante ?></div>
                                    <a href="estudante" class="my_sort_cut text-muted">
                                        <i class="fas fa-users"></i>
                                        <span>Estudante</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Ver Salas -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="250">
                            <div class="card">
                                <div class="card-bg" style="background-color: #2196f3;"></div>
                                <div class="card-body ribbon">
                                    <div class="ribbon-box green" data-toggle="tooltip" title="Total de Salas"><?= $Totalsala ?></div>
                                    <a href="#" class="my_sort_cut text-muted">
                                        <i class="fas fa-door-open"></i>
                                        <span>Ver Salas</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Relatório -->
                        <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="300">
                            <div class="card pulse-card">
                                <div class="card-bg" style="background-color: #607d8b;"></div>
                                <div class="card-body">
                                    <a href="relatorio" class="my_sort_cut text-muted">
                                        <i class="fas fa-file-alt"></i>
                                        <span>Relatório</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating Action Button -->
    <a href="#" class="floating-btn animate__animated animate__bounceInUp animate__delay-1s">
        <i class="fas fa-question"></i>
    </a>

    <!-- JavaScript Libraries -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js"></script>
    <script src="../assets/bundles/summernote.bundle.js"></script>
    <script src="../assets/js/core.js"></script>
    
    <!-- AOS Animation -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Initialize AOS animation
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Initialize tooltips
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        
        // Pulse animation for important cards
        setInterval(function() {
            $('.pulse-card').toggleClass('pulse-card');
            setTimeout(function() {
                $('.pulse-card').addClass('pulse-card');
            }, 100);
        }, 2000);
        
        // Floating button click event
        $('.floating-btn').click(function(e) {
            e.preventDefault();
            alert('Central de Ajuda da Secretaria:\n\nSelecione uma das opções acima para gerenciar os processos acadêmicos.');
        });
    </script>
</body>
</html>