<?php

// initialize the session
session_start();

if (file_exists('../controllers/config/connection.php')) {
require_once "../controllers/config/connection.php";
} else {
echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

$pagename = "Secretária";

// check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
header("location: login");
exit;
}


$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);


?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<title></title>

<link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
<link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />
<link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">

<link rel="stylesheet" href="assets/css/style.min.css" />
<link rel="stylesheet" href="assets/css/all.min.css" />
<script src="https://unpkg.com/feather-icons"></script>
<script src="assets/css/feather-icons.css"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />

<link rel="stylesheet" href="../assets/css/style.min.css" />

<script src="../assets/js/jquery-3.6.0.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
$('#cursos').change(function() {
    var id = $(this).val();
    $.ajax({
        url: 'listar-classe.php',
        type: 'POST',
        data: {
            id: id
        },
        success: function(response) {
            $('#idClasse').html(response);
            $('#div-Classe').show();
        },
        error: function(xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
});
});
</script>

</head>

<body class="font-muli theme-cyan gradient">

<!-- Inclua o JavaScript para mostrar o modal se a variável de sucesso estiver definida -->
<?php

if (isset($_GET['success']) && $_GET['success'] === 'true') {
?>
<script>
$(document).ready(function() {
    $('#successModal').modal('show');
});
</script>

<?php
}
?>

<?php


?>

<div id="main_content">

<?php

if (file_exists('sections/min-sidebar.php')) {
require_once "sections/min-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/right-sidebar.php')) {
require_once "sections/right-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/theme.php')) {
require_once "sections/theme.php";
} else {
echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/sidebar.php')) {
require_once "sections/sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
}

?>

<div class="page">

<?php

if (file_exists('sections/navbar.php')) {
    require_once "sections/navbar.php";
} else {
    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
}

?>

<div class="section-body">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center ">
            <div class="header-action">
                <h1 class="page-title"><?= $pagename ?></h1>
                <ol class="breadcrumb page-breadcrumb">
                    <li class="breadcrumb-item"><a href="secretaria">Secretaria Geral</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= $pagename ?></li>
                </ol>
            </div>
            <ul class="nav nav-tabs page-header-tab">

                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#pro-add">Novo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " data-toggle="tab" href="#pro-all">Lista</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="section-body mt-4">
    <div class="container-fluid">
        <div class="tab-content">
            <div class="tab-pane " id="pro-all">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover js-basic-example dataTable table-striped table_custom border-style spacing5">
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Nome</th>
                                        <th>Genero</th>
                                        <th>BI/Cedula</th>
                                        <th>Telefone</th>
                                        <th>Inscrição</th>
                                        <th>Status</th>
                                        <th>Ação</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Consulta SQL para realizar a pesquisa avançada
                                    $query = "SELECT * FROM inscricao WHERE status = 'on'";
                                    $stmt = $conn->query($query);

                                    // Verifica se foram encontrados resultados
                                    if ($stmt->rowCount()) {
                                        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            $idIns = $dados['id'];
                                            $codigo = $dados['codigo'];
                                            $nome = $dados['nome'];
                                            $genero = $dados['genero'];
                                            $documento = $dados['documento'];
                                            $telefone = $dados['telefone'];
                                            $status = $dados['status'];
                                            $created = $dados['created'];
                                    ?>
                                            <tr>
                                                <td><?= $codigo; ?></td>
                                                <td><?= $nome; ?></td>
                                                <td><?= $genero; ?></td>
                                                <td><?= $documento; ?></td>
                                                <td><?= $telefone; ?></td>
                                                <td><?= $created; ?></td>
                                                <td>
                                                    <?php
                                                    $var = $status;
                                                    if ($var == "on") {
                                                    ?>
                                                        <span class="badge badge-success badge-pill">
                                                            Ativo
                                                        </span>
                                                    <?php
                                                    } else {
                                                    ?>
                                                        <span class="badge badge-danger badge-pill">
                                                            Inativo
                                                        </span>
                                                    <?php
                                                    }
                                                    ?>
                                                </td>

                                                <td >
                                                    <a href="" type="button" class="btn btn-icon btn-sm text-orange" title="View">
                                                        <i data-feather="edit" data-toggle="tooltip" data-placement="left" title="Editar"></i>
                                                    </a>
                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    </div>
            <?php
             // Consulta SQL para buscar os dados da tabela "ano"
                $sql = "SELECT ano.id FROM ano WHERE estado='Ativo' ORDER BY anoTermino ASC";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
            ?> 
            <div class="tab-pane active" id="pro-add">
                <div class="row clearfix">
                    <div class="col-lg-10 col-md-12 col-sm-12" style="left:100px">
                        <div class="card">
                            <form action="../controllers/create/inscricao.php" method="POST">
                                <div class="card-body">
                                    <div class="row clearfix">

                                        <input type="hidden" class="form-control" name="idano" required value="<?= $id ?>">
                                        
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Nome Completo</label>
                                                <input type="text" class="form-control" autocomplete="on" name="nome" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Nome do Pai (Opcional)</label>
                                                <input type="text" class="form-control" autocomplete="on" name="nomePai">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Nome da Mãe (Opcional)</label>
                                                <input type="text" class="form-control" autocomplete="on" name="nomeMae">
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12">
                                            <div class="form-group">
                                                <label>Data de Nasc.</label>
                                                <input data-provide="datepicker" data-date-autoclose="true" class="form-control" autocomplete="on" name="dataNasc" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12">
                                            <label>Genêro</label>
                                            <select class="form-control show-tick" required name="genero">
                                                <option selected disabled value=""> -- Selecione -- </option>
                                                <option value="Masculino">Masculino</option>
                                                <option value="Feminino">Feminino</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>BI/Passaporte ou Cédula</label>
                                                <input type="text" class="form-control" autocomplete="on" name="documento" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12">
                                            <div class="form-group">
                                                <label>Telefone (Opcional)</label>
                                                <input type="number" class="form-control" autocomplete="on" name="telefone">
                                            </div> 
                                        </div>
                                        <div class="col-md-5 col-sm-12">
                                            <div class="form-group">
                                                <label>E-mail (Opcional)</label>
                                                <input type="text" class="form-control" autocomplete="on" name="email">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>Nome Responsável (Opcional)</label>
                                                <input type="text" class="form-control" name="nomeResp">
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12">
                                            <div class="form-group">
                                                <label>Tel. Resp. (Opcional)</label>
                                                <input type="number" class="form-control" name="telResp">
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-sm-12">
                                            <div class="form-group">
                                                <label>E-mail Responsável (Opcional)</label>
                                                <input type="text" class="form-control" name="emailResp">
                                            </div>
                                        </div>
                                        <div class="col-md-7 col-sm-12" id="div-curso">
                                            <div class="form-group">
                                                <label>Curso</label>
                                                <select class="form-control show-tick" id="cursos" required name="idCurso">
                                                    <option value="" selected disabled>
                                                        -- Selecione --
                                                    </option>
                                                    <?php

                                                    // Realiza a consulta no banco de dados
                                                    $stmt = $conn->query("SELECT * FROM curso");

                                                    // Itera sobre os resultados e adiciona as opções ao select
                                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                        echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                                                    }

                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-5 col-sm-12" id="div-Classe">
                                            <div class="form-group">
                                                <label>Classe</label>
                                                <select class="form-control show-tick" id="idClasse" required name="idClasse">
                                                    <option value="" selected disabled>
                                                        -- Selecione --
                                                    </option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>Metodo Pag.</label>
                                                <select class="form-control show-tick" required name="metodoPag">
                                                    <option value="" selected disabled>
                                                        -- Selecione --
                                                    </option>
                                                    <option value="Dinheiro">Dinheiro</option>
                                                    <option value="Transferência">Transferência</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Taxa Incrição</label>
                                                <?php
                                                $queryApp = "SELECT vinsmat.taxaInscr FROM vinsmat LIMIT 1";
                                                $stmt = $conn->query($queryApp);

                                                if ($stmt !== false) {
                                                    $dadosApp = $stmt->fetch(PDO::FETCH_ASSOC);

                                                    if ($dadosApp !== false) {
                                                        $taxaInscr = $dadosApp['taxaInscr'];
                                                        echo "<input type='text' class='form-control' value='$taxaInscr' name='taxaInscr' required readonly>";
                                                    } else {
                                                        echo "Nenhum registro encontrado na tabela.";
                                                    }
                                                } else {
                                                    echo "Erro na consulta: " . $conn->errorInfo()[2];
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Valor Pag.</label>
                                                <input type='number' class='form-control' name='valorPago' required>
                                            </div>
                                        </div>
                                        <?php
                                        // Função para gerar um número aleatório de 7 dígitos
                                        function generateRandomCode()
                                        {
                                            return rand(1000000, 9999999);
                                        }

                                        // Gera um novo código até encontrar um que não exista na tabela
                                        $codeExists = true;
                                        $generatedCode = 0;

                                        while ($codeExists) {
                                            $generatedCode = generateRandomCode();

                                            $query = "SELECT COUNT(*) as count FROM inscricao WHERE codigo = :generatedCode";
                                            $stmt = $conn->prepare($query);
                                            $stmt->bindParam(":generatedCode", $generatedCode, PDO::PARAM_INT);
                                            $stmt->execute();

                                            $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                            $codeExists = ($result['count'] > 0);
                                        }

                                        ?>
                                        <div class="col-md-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Cód. Inscr.</label>
                                                <input class="form-control" name="codigo" value="<?= $generatedCode ?>" required readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-primary">Submeter</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
</div>
</div>
</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script>
feather.replace()
</script>
<script src="../assets/bundles/lib.vendor.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

<script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
<script src="../assets/plugins/dropify/js/dropify.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
<script src="../assets/bundles/summernote.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

<script src="../assets/js/core.js" type="84bad0df44a88b049b511662-text/javascript"></script>
<script src="assets/js/form/dropify.js" type="84bad0df44a88b049b511662-text/javascript"></script>
<script src="assets/js/page/summernote.js" type="84bad0df44a88b049b511662-text/javascript"></script>
<script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="84bad0df44a88b049b511662-|49" defer></script>
<script>
(function() {
var js =
    "window['__CF$cv$params']={r:'7dd4b640d8bd4931',m:'ylhOZFbX0HS1c4DPak1Yq5UidcMrX0PisknfubBMMH4-1687774766-0-AUNBl0Ey9/ml/1dDGoabBYZ977e9URVHmQjn28JNXdC6'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
var _0xh = document.createElement('iframe');
_0xh.height = 1;
_0xh.width = 1;
_0xh.style.position = 'absolute';
_0xh.style.top = 0;
_0xh.style.left = 0;
_0xh.style.border = 'none';
_0xh.style.visibility = 'hidden';
document.body.appendChild(_0xh);

function handler() {
    var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
    if (_0xi) {
        var _0xj = _0xi.createElement('script');
        _0xj.nonce = '';
        _0xj.innerHTML = js;
        _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
    }
}
if (document.readyState !== 'loading') {
    handler();
} else if (window.addEventListener) {
    document.addEventListener('DOMContentLoaded', handler);
} else {
    var prev = document.onreadystatechange || function() {};
    document.onreadystatechange = function(e) {
        prev(e);
        if (document.readyState !== 'loading') {
            document.onreadystatechange = prev;
            handler();
        }
    };
}
})();
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816" integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw==" data-cf-beacon='{"rayId":"7dd4b640d8bd4931","version":"2023.4.0","r":1,"b":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":100}' crossorigin="anonymous"></script>


<script src="../assets/bundles/lib.vendor.bundle.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

<script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
<script src="../assets/bundles/dataTables.bundle.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
<script src="../assets/plugins/sweetalert/sweetalert.min.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

<script src="assets/js/page/dialogs.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
<script src="assets/js/table/datatable.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

<script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="b578d4dcee898492da2efecc-|49" defer></script>

<script>
(function() {
var js = "window['__CF$cv$params']={r:'7dd4b64cac993eac',m:'qLuHZDzBGLpMAQbWuuHAEWXrckFk4MZt_QL9o6qNdxA-1687774768-0-Af+2uIh/6NA706uiBlR/LMhXs8zYj4ZB2Bc4OmwH9qyu'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
var _0xh = document.createElement('iframe');
_0xh.height = 1;
_0xh.width = 1;
_0xh.style.position = 'absolute';
_0xh.style.top = 0;
_0xh.style.left = 0;
_0xh.style.border = 'none';
_0xh.style.visibility = 'hidden';
document.body.appendChild(_0xh);

function handler() {
    var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
    if (_0xi) {
        var _0xj = _0xi.createElement('script');
        _0xj.nonce = '';
        _0xj.innerHTML = js;
        _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
    }
}
if (document.readyState !== 'loading') {
    handler();
} else if (window.addEventListener) {
    document.addEventListener('DOMContentLoaded', handler);
} else {
    var prev = document.onreadystatechange || function() {};
    document.onreadystatechange = function(e) {
        prev(e);
        if (document.readyState !== 'loading') {
            document.onreadystatechange = prev;
            handler();
        }
    };
}
})();
</script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816" integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw==" data-cf-beacon='{"rayId":"7dd4b64cac993eac","version":"2023.4.0","r":1,"b":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":100}' crossorigin="anonymous"></script>
</body>

</html>