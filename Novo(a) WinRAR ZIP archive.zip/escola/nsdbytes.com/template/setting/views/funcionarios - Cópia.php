<?php

    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

    $pagename = "Funcionários";

    // check if the user is logged in, if not then redirect him to login page
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }

    $id = htmlspecialchars($_SESSION["id"]);
    $username = htmlspecialchars($_SESSION["username"]);

?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title><?= $pagename ?></title>

    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
    <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/all.min.css" />
    <script src="assets/css/feather-icons.css"></script>

    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />

    <link rel="stylesheet" href="../assets/css/style.min.css" />

    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#departamentos').change(function() {
              var id = $(this).val();
              $.ajax({
                url: 'listar-funcao.php',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    $('#idFuncao').html(response);
                    $('#div-funcao').show();
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
              });
            });
        });
    </script>
</head>

<body class="font-muli theme-cyan gradient">

    <?php

        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }

    ?>
    <div id="main_content">

        <?php

            if (file_exists('sections/min-sidebar.php')) {
                require_once "sections/min-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/right-sidebar.php')) {
                require_once "sections/right-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/sidebar.php')) {
                require_once "sections/sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
            }

        ?>

        <div class="page">

            <?php

                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }

            ?>

            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center ">
                        <div class="header-action">
                            <h1 class="page-title"><?= $pagename ?></h1>
                            <ol class="breadcrumb page-breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard">dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?= $pagename ?></li>
                            </ol>
                        </div>
                        <ul class="nav nav-tabs page-header-tab">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#pro-all">Lista</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#pro-add">Novo</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="section-body mt-4">
                <div class="container-fluid">
                    <div class="tab-content">
                        <div class="tab-pane active" id="pro-all">
                            <div class="card">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover js-basic-example dataTable table-striped table_custom border-style spacing5">
                                            <thead>
                                                <tr>
                                                    <th>Avatar</th>
                                                    <th>Nome</th>
                                                    <th>Departamento</th>
                                                    <th>Função</th>
                                                    <th>Código</th>
                                                    <th>Status</th>
                                                    <th>#</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    // Consulta SQL para realizar a pesquisa avançada
                                                    $query = "SELECT funcionarios.id, funcionarios.foto AS 'avatar', funcionarios.nome 'funcionario', departamentos.nome AS 'departamento', funcao.nome AS 'funcao', funcionarios.codigo AS 'codigo', funcionarios.status FROM funcionarios INNER JOIN funcao ON funcionarios.idFuncao=funcao.id INNER JOIN departamentos ON funcao.idDep=departamentos.id";
                                                    $stmt = $conn->query($query);

                                                    // Verifica se foram encontrados resultados
                                                    if ($stmt->rowCount()) {
                                                        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                            $id = $dados['id'];
                                                            $foto = $dados['avatar'];
                                                            $nome = $dados['funcionario'];
                                                            $nomeDep = $dados['departamento'];
                                                            $funcao = $dados['funcao'];
                                                            $codigo = $dados['codigo'];
                                                            $status = $dados['status'];

                                                            $partesNome = explode(" ", $nome);
                                                            $primeiroNome = $partesNome[0];
                                                            $ultimoNome = end($partesNome);

                                                            $nomeCompleto = $primeiroNome . " " . $ultimoNome;

                                                            // Obtém as iniciais
                                                            $initials = "";
                                                            $words = explode(" ", $nome);
                                                            foreach ($words as $word) {
                                                                $initials .= strtoupper($word[0]);
                                                            }
                                                    ?>
                                                    <tr>
                                                        <?php
                                                            $img = $foto;
                                                            if ($img == "") {
                                                        ?>
                                                            <td class="w60">
                                                                <div class="avatar avatar-pink" data-toggle="tooltip" data-placement="top" title data-original-title="Avatar Name">
                                                                    <span><?= $initials; ?></span>
                                                                </div>
                                                            </td>
                                                        <?php
                                                            } else {
                                                        ?>
                                                            <td class="w60">
                                                                <img class="avatar avatar-md" src="../controllers/uploads/<?= $foto; ?>" alt="img not found">
                                                            </td>
                                                        <?php
                                                            }
                                                        ?>
                                                        <td><?= $nome; ?></td>
                                                        <td><?= $nomeDep; ?></td>
                                                        <td><?= $funcao; ?></td>
                                                        <td><?= $codigo; ?></td>
                                                        <td>
                                                            <?php
                                                                $var = $status;
                                                                if ($var == "on") {
                                                            ?>
                                                                <span class="badge badge-success badge-pill">
                                                                    Ativo
                                                                </span>
                                                            <?php
                                                                } else {
                                                            ?>
                                                                <span class="badge badge-danger badge-pill">
                                                                    Inativo
                                                                </span>
                                                            <?php
                                                                }
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <a href="perfil-funcionarios?id=<?= $id ?>" class="btn btn-outline-primary btn-sm">
                                                                <i data-feather="eye"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="pro-add">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-1 col-sm-12">
                                    <div class="card">
                                        <form action="../controllers/create/funcionarios.php" method="POST" enctype="multipart/form-data">
                                            <div class="card-body">
                                                <div class="row clearfix">
                                                    <div class="col-md-6 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Nome Completo</label>
                                                            <input type="text" class="form-control" name="nome" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Data Nascimento</label>
                                                            <input data-provide="datepicker" data-date-autoclose="true" class="form-control" placeholder="Date of Birth" name="dataNasc" required autocomplete="off">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12">
                                                        <label>Genêro</label>
                                                        <select class="form-control show-tick" name="genero" required>
                                                            <option value="Maculino" selected disabled>-- Selecione --</option>
                                                            <option value="Maculino">Maculino</option>
                                                            <option value="Feminino">Feminino</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12">
                                                        <div class="form-group">
                                                            <label>BI/Passaporte</label>
                                                            <input type="text" class="form-control" name="documento" required autocomplete="off">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-5 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Endereço</label>
                                                            <input type="text" class="form-control" name="endereco" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 col-sm-12">
                                                        <label>Província</label>
                                                        <select class="form-control show-tick" name="provincia" required>
                                                            <option selected disabled value="">-- Selecione --</option>
                                                            <option value="Luanda">Luanda</option>
                                                            <option value="Bengo">Bengo</option>
                                                            <option value="Benguela">Benguela</option>
                                                            <option value="Bié">Bié</option>
                                                            <option value="Cabinda">Cabinda</option>
                                                            <option value="Cuando Cubango">Cuando Cubango</option>
                                                            <option value="Cuanza Norte">Cuanza Norte</option>
                                                            <option value="Cuanza Sul">Cuanza Sul</option>
                                                            <option value="Cunene">Cunene</option>
                                                            <option value="Huambo">Huambo</option>
                                                            <option value="Huíla">Huíla</option>
                                                            <option value="Lunda Norte">Lunda Norte</option>
                                                            <option value="Lunda Sul">Lunda Sul</option>
                                                            <option value="Malanje">Malanje</option>
                                                            <option value="Moxico">Moxico</option>
                                                            <option value="Namibe">Namibe</option>
                                                            <option value="Uíge">Uíge</option>
                                                            <option value="Zaire">Zaire</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-2 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Telefone</label>
                                                            <input type="number" class="form-control" name="telefone" requirede>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-12">
                                                        <div class="form-group">
                                                            <label>E-mail (Opcional)</label>
                                                            <input type="email" class="form-control" name="email">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-5 col-sm-12" id="div-departamentos" >
                                                        <div class="form-group">
                                                            <label>Departamentos</label>
                                                            <select class="form-control show-tick" id="departamentos" required name="id">
                                                                <option value="" selected disabled>
                                                                    -- Selecione --
                                                                </option>
                                                                <?php
                      
                                                                    // Realiza a consulta no banco de dados
                                                                    $stmt = $conn->query("SELECT * FROM departamentos");

                                                                    // Itera sobre os resultados e adiciona as opções ao select
                                                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                                        echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                                                                    }
                                                                    
                                                                  ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-5 col-sm-12" id="div-funcao">
                                                        <div class="form-group">
                                                            <label>Funcão</label>
                                                            <select class="form-control show-tick" id="idFuncao" required name="idFuncao">
                                                                <option value="" selected disabled>
                                                                    -- Selecione --
                                                                </option>
                                                            </select>
                                                        </div>  
                                                    </div>
                                                    <?php
                                                        // Função para gerar um número aleatório de 7 dígitos
                                                        function generateRandomCode() {
                                                            return rand(1000000, 9999999);
                                                        }

                                                        // Gera um novo código até encontrar um que não exista na tabela
                                                        $codeExists = true;
                                                        $generatedCode = 0;

                                                        while ($codeExists) {
                                                            $generatedCode = generateRandomCode();
                                                            
                                                            $query = "SELECT COUNT(*) as count FROM funcionarios WHERE codigo = :generatedCode";
                                                            $stmt = $conn->prepare($query);
                                                            $stmt->bindParam(":generatedCode", $generatedCode, PDO::PARAM_INT);
                                                            $stmt->execute();
                                                            
                                                            $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                                            $codeExists = ($result['count'] > 0);
                                                        }

                                                    ?>
                                                    <div class="col-md-2 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Cód. Inscr.</label>
                                                            <input class="form-control" name="codigo" value="<?= $generatedCode ?>" required readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Foto de perfil</label>
                                                            <input type="file" class="dropify" name="avatar" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        feather.replace()
    </script>
    <script src="../assets/bundles/lib.vendor.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/bundles/summernote.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/js/core.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/form/dropify.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/page/summernote.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="84bad0df44a88b049b511662-|49" defer></script>
    <script>
        (function() {
            var js =
                "window['__CF$cv$params']={r:'7dd4b640d8bd4931',m:'ylhOZFbX0HS1c4DPak1Yq5UidcMrX0PisknfubBMMH4-1687774766-0-AUNBl0Ey9/ml/1dDGoabBYZ977e9URVHmQjn28JNXdC6'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
            var _0xh = document.createElement('iframe');
            _0xh.height = 1;
            _0xh.width = 1;
            _0xh.style.position = 'absolute';
            _0xh.style.top = 0;
            _0xh.style.left = 0;
            _0xh.style.border = 'none';
            _0xh.style.visibility = 'hidden';
            document.body.appendChild(_0xh);

            function handler() {
                var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
                if (_0xi) {
                    var _0xj = _0xi.createElement('script');
                    _0xj.nonce = '';
                    _0xj.innerHTML = js;
                    _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
                }
            }
            if (document.readyState !== 'loading') {
                handler();
            } else if (window.addEventListener) {
                document.addEventListener('DOMContentLoaded', handler);
            } else {
                var prev = document.onreadystatechange || function() {};
                document.onreadystatechange = function(e) {
                    prev(e);
                    if (document.readyState !== 'loading') {
                        document.onreadystatechange = prev;
                        handler();
                    }
                };
            }
        })();
    </script>


    <script src="../assets/bundles/lib.vendor.bundle.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
    <script src="../assets/bundles/dataTables.bundle.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
    <script src="../assets/plugins/sweetalert/sweetalert.min.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

    <script src="assets/js/page/dialogs.js" type="b578d4dcee898492da2efecc-text/javascript"></script>
    <script src="assets/js/table/datatable.js" type="b578d4dcee898492da2efecc-text/javascript"></script>

    <script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="b578d4dcee898492da2efecc-|49" defer></script>

    <script>
        (function() {
            var js = "window['__CF$cv$params']={r:'7dd4b64cac993eac',m:'qLuHZDzBGLpMAQbWuuHAEWXrckFk4MZt_QL9o6qNdxA-1687774768-0-Af+2uIh/6NA706uiBlR/LMhXs8zYj4ZB2Bc4OmwH9qyu'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
            var _0xh = document.createElement('iframe');
            _0xh.height = 1;
            _0xh.width = 1;
            _0xh.style.position = 'absolute';
            _0xh.style.top = 0;
            _0xh.style.left = 0;
            _0xh.style.border = 'none';
            _0xh.style.visibility = 'hidden';
            document.body.appendChild(_0xh);

            function handler() {
                var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
                if (_0xi) {
                    var _0xj = _0xi.createElement('script');
                    _0xj.nonce = '';
                    _0xj.innerHTML = js;
                    _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
                }
            }
            if (document.readyState !== 'loading') {
                handler();
            } else if (window.addEventListener) {
                document.addEventListener('DOMContentLoaded', handler);
            } else {
                var prev = document.onreadystatechange || function() {};
                document.onreadystatechange = function(e) {
                    prev(e);
                    if (document.readyState !== 'loading') {
                        document.onreadystatechange = prev;
                        handler();
                    }
                };
            }
        })();
    </script>
</body>

</html>