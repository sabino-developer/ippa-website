<?php
// Inicializa a sessão
session_start();
require_once "../controllers/config/connection.php";

$pagename = "Dashboard";

// Verifica se o usuário está logado
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login");
    exit;
}

$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $pagename; ?></title>

    <!-- Ícone do site -->
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <!-- Estilos -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />
    <link rel="stylesheet" href="assets/css/style.min.css" />
    <link rel="stylesheet" href="assets/css/all.min.css" />

    <!-- Scripts -->
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="../assets/js/jquery-3.6.0.min.js"></script>
</head>

<body class="font-muli theme-cyan gradient">
    
    <?php include 'sections/loader.php'; ?>

    <div id="main_content">
<div id="main_content">

<?php

if (file_exists('sections/min-sidebar.php')) {
require_once "sections/min-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/right-sidebar.php')) {
require_once "sections/right-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/theme.php')) {
require_once "sections/theme.php";
} else {
echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/sidebar.php')) {
require_once "sections/sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
}

?>

<div class="page">

<?php

if (file_exists('sections/navbar.php')) {
    require_once "sections/navbar.php";
} else {
    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
}

?>

            <div class="section-body mt-4">
                <div class="container-fluid text-center">
                    <h4 class="text-primary">
                        👋 Olá, 
                        <?php
                            $user = $username;
                            $usernameParts = explode(".", $user);
                            $firstName = ucfirst($usernameParts[0]);
                            $lastName = isset($usernameParts[1]) ? $usernameParts[1] : "";
                            echo "<span class='font-weight-bold'>$firstName $lastName</span>";
                        ?>
                    </h4>

                    <?php
                        // Busca o gênero do usuário
                        $stmt = $conn->prepare("SELECT genero FROM funcionarios WHERE estado='usuario' LIMIT 1");
                        $stmt->execute();
                        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                        $genero = $resultado['genero'] ?? '';

                        // Mensagem personalizada
                        if (strtolower($genero) == "masculino") {
                            echo "<p class='text-muted'>Seja bem-vindo ao seu Painel, <strong>Senhor Administrador</strong>! 🚀</p>";
                        } else {
                            echo "<p class='text-muted'>Seja bem-vinda ao seu Painel, <strong>Senhora Administradora</strong>! 💼</p>";
                        }
                    ?>

                </div>
            </div>

            <?php include 'sections/footer.php'; ?>

        </div>
            
    </div>

    <!-- Scripts -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="assets/js/icons.js"></script>
    <script src="../assets/js/core.js"></script>
    <script>
        feather.replace();
    </script>

</body>
</html>
