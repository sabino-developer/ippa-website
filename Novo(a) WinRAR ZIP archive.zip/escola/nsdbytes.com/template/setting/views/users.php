<?php

    // initialize the session
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

    $pagename = "Dashboard | Usuários";

    // check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }


$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);


?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Dashboard | Usuários</title>

    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
    <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />

    <link rel="stylesheet" href="assets/css/style.min.css" />
    <link rel="stylesheet" href="assets/css/all.min.css" />
    <script src="https://unpkg.com/feather-icons"></script>
        <script src="assets/css/feather-icons.css"></script>
</head>

<body class="font-muli theme-cyan gradient">

    <?php

        if (file_exists('sections/loader.php')) {
            require_once "sections/loader.php";
        } else {
            echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
        }

    ?>
    <div id="main_content">

        <?php

			if (file_exists('sections/min-sidebar.php')) {
				require_once "sections/min-sidebar.php";
			} else {
				echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
			}

		?>

        <?php

			if (file_exists('sections/right-sidebar.php')) {
				require_once "sections/right-sidebar.php";
			} else {
				echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
			}

		?>

        <?php

            if (file_exists('sections/theme.php')) {
                require_once "sections/theme.php";
            } else {
                echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
            }

        ?>

        <?php

            if (file_exists('sections/statistic-sidebar.php')) {
                require_once "sections/statistic-sidebar.php";
            } else {
                echo "<span class='text-danger'>O arquivo statistic-sidebar foi encontrado!</span>";
            }

        ?>

        <?php

			if (file_exists('sections/sidebar.php')) {
				require_once "sections/sidebar.php";
			} else {
				echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
			}

		?>

        <div class="page">

            <?php

                if (file_exists('sections/navbar.php')) {
                    require_once "sections/navbar.php";
                } else {
                    echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
                }

            ?>

            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center ">
                        <div class="header-action">
                            <h1 class="page-title">Usuários</h1>
                            <ol class="breadcrumb page-breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Usuários</li>
                            </ol>
                        </div>
                        <ul class="nav nav-tabs page-header-tab">
                            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#pro-all">Lista</a></li>
                            <!--<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#pro-grid">Grelha</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#pro-add">Novo</a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
            <div class="section-body mt-4">
                <div class="container-fluid">
                    <div class="tab-content">
                        <div class="tab-pane" id="pro-grid">
                            <div class="row">
                                <?php
                                    // Consulta SQL para realizar a pesquisa avançada
                                    $query = "SELECT * FROM users";
                                    $stmt = $conn->query($query);
                                    
                                    // Verifica se foram encontrados resultados
                                    if ($stmt->rowCount()) {
                                        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            $idUser = $dados['id'];
                                            $username = $dados['username'];
                                            $profile = $dados['profile'];
                                            $status = $dados['status'];
                                            $created = $dados['created'];
                                          

                                            $nome = $username;

                                            $partesNome = explode(" ", $nome);
                                            $primeiroNome = $partesNome[0];
                                            $ultimoNome = end($partesNome);

                                            $nomeCompleto = $primeiroNome . " " . $ultimoNome;

                                            $name = $username;

                                            // Obtém as iniciais
                                            $initials = "";
                                            $words = explode(" ", $name);
                                            foreach ($words as $word) {
                                                $initials .= strtoupper($word[0]);
                                            } 
                                ?>
                                <div class="col-xl-3 col-lg-4 col-md-6">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <img class="card-profile-img" src="../controllers/uploads/; ?>" alt="Img" style="height:100px">
                                            <h6 class="mb-0"><?= $name; ?></h6>
                                            <br>
                                            <span>
                                                 <?php
                                                            $var=$profile;
                                                            if ($var=="da") {
                                                                echo "Administrador";
                                                            }elseif ($var=="rh") {
                                                                echo "Recursos Humanos";
                                                            }elseif ($var=="das") {
                                                                echo "Secretaria";
                                                            }elseif ($var=="daf") {
                                                                echo "Finanças";
                                                            }elseif ($var=="dca") {
                                                                echo "Acadêmico";
                                                            }elseif ($var=="dti") {
                                                                echo "Informática";
                                                            }
                                                        ?>

                                           </span>
                                            <div class="text-muted">
                                                <?php
                                                    $vars=$status;
                                                    if ($vars=="on") {
                                                        echo "Ativo";
                                                    }else{
                                                        echo "Inativo";
                                                    }
                                                ?>
                                            </div>
                                            <p class="mb-4 mt-3"><?= $created; ?> </p>
                                            <button class="btn btn-primary btn-sm">Ver perfil</button>
                                        </div>
                                    </div>
                                </div>
                                <?php 
                                        }
                                    } else {
                                ?>
                                <center><a href="#!" class="text-center" style="text-align: center; font-family: L4">Nenhum resultado encontrado.</a></center>
                                <?php 
                                    }
                                ?>
                            </div>
                        </div>

                        <?php
                            if (isset($_GET["id"])) {
                                $idEmployees = $_GET["id"];

                                $query = "SELECT *, funcao.id AS 'idFuncao', funcao.nome AS 'funcao' FROM employees INNER JOIN funcao ON employees.idFuncao=funcao.id WHERE employees.id='$idEmployees'";
                                $stmt = $conn->query($query);

                                $dadosA = $stmt->fetch(PDO::FETCH_ASSOC);
                                $fullname=$dadosA['fullname'];
                                $document=$dadosA['document'];
                                $residence=$dadosA['residence'];
                                $neighborhood=$dadosA['neighborhood'];
                                $province=$dadosA['province'];
                                $birth=$dadosA['birth'];
                                $gender=$dadosA['gender'];
                                $idFuncao=$dadosA['idFuncao'];
                                $funcao=$dadosA['funcao'];
                                $email=$dadosA['email'];
                                $phone=$dadosA['phone'];
                                $avatar=$dadosA['avatar'];
                                $status=$dadosA['status'];
                                $created=$dadosA['created'];
                        ?>
                        <div class="tab-pane active" id="pro-add">
                            <div class="row clearfix">
                                <div class="col-lg-8 col-md-12 col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Informações básicas</h3>
                                            <div class="card-options ">
                                                <a href="#" class="card-options-collapse" data-toggle="card-collapse">
                                                    <i data-feather="chevron-up"></i>
                                                </a>
                                                <a href="#" class="card-options-remove" data-toggle="card-remove">
                                                <i data-feather="x"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <form action="../controllers/update/employees.php" method="POST" enctype="multipart/form-data">
                                            <input type="hidden" name="id" value="id">
                                            <div class="card-body">
                                                <div class="row clearfix">
                                                    <div class="col-md-8 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Nome Completo</label>
                                                            <input type="text" class="form-control" name="fullname" value="<?= $fullname ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12">
                                                        <div class="form-group">
                                                            <label>BI/Passaporte</label>
                                                            <input type="text" class="form-control" name="document" value="<?= $document ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Residência: (Opcional)</label>
                                                            <input type="text" class="form-control" name="residence" value="<?= $residence ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Bairro: (Opcional)</label>
                                                            <input type="text" class="form-control" name="neighborhood" value="<?= $neighborhood ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-12">
                                                        <label>Província</label>
                                                        <select class="form-control show-tick" name="province" required>
                                                            <option value="<?= $province ?>"><?= $province?></option>
                                                            <option value="Luanda">Luanda</option>
                                                            <option value="Bengo">Bengo</option>
                                                            <option value="Benguela">Benguela</option>
                                                            <option value="Bié">Bié</option>
                                                            <option value="Cabinda">Cabinda</option>
                                                            <option value="Cuando Cubango">Cuando Cubango</option>
                                                            <option value="Cuanza Norte">Cuanza Norte</option>
                                                            <option value="Cuanza Sul">Cuanza Sul</option>
                                                            <option value="Cunene">Cunene</option>
                                                            <option value="Huambo">Huambo</option>
                                                            <option value="Huíla">Huíla</option>
                                                            <option value="Lunda Norte">Lunda Norte</option>
                                                            <option value="Lunda Sul">Lunda Sul</option>
                                                            <option value="Malanje">Malanje</option>
                                                            <option value="Moxico">Moxico</option>
                                                            <option value="Namibe">Namibe</option>
                                                            <option value="Uíge">Uíge</option>
                                                            <option value="Zaire">Zaire</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Data de Nasc.</label>
                                                            <input data-provide="datepicker" data-date-autoclose="true" class="form-control" placeholder="Date of Birth" name="birth" required value="<?= $birth ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 col-sm-12">
                                                        <label>Sexo</label>
                                                        <select class="form-control show-tick" name="gender" value="<?= $gender ?>">
                                                            <option value="<?= $gender ?>"><?= $gender ?></option>
                                                            <option value="Maculino">Maculino</option>
                                                            <option value="Femenino">Femenino</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-5 col-sm-12">
                                                        <label>Função</label>
                                                        <select class="form-control show-tick" name="idFuncao">
                                                            <option disabled selected o value="<?= $idFuncao ?>"><?= $funcao ?></option>
                                                            <?php
                                                                $query = "SELECT * FROM funcao";
                                                                $stmt = $conn->query($query);
                                                                while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                            ?>
                                                            <option value="<?= $result['id']; ?>"><?= $result['nome']; ?></option>
                                                            <?php
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-5 col-sm-12">
                                                        <label>Status</label>
                                                        <select class="form-control show-tick" name="status" value="<?= $status ?>">
                                                            <option value="<?= $status ?>">
                                                                <?php
                                                                    $vars2=$status;
                                                                    if ($vars2=="on") {
                                                                        echo "Ativo";
                                                                    }else{
                                                                        echo "Inativo";
                                                                    }
                                                                ?>
                                                            </option>
                                                            <?php
                                                                $vars2=$status;
                                                                if ($vars2=="on") {
                                                            ?>
                                                                <option value="off">Inativo</option>
                                                            <?php
                                                                }else{
                                                            ?>
                                                                <option value="on">Ativo</option>
                                                            <?php
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-8 col-sm-12">
                                                        <div class="form-group">
                                                            <label>E-mail</label>
                                                            <input type="email" class="form-control" name="email" required value="<?= $email ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12">
                                                        <div class="form-group">
                                                            <label>Telefone</label>
                                                            <input type="number" class="form-control" name="phone" requirede value="<?= $phone ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <div class="form-group mt-2 mb-3">
                                                            <input type="file" class="dropify" name="avatar" value="ava">
                                                            <small id="fileHelp" class="form-text text-muted">This is some
                                                                placeholder block-level help text for the above input. It's
                                                                a bit lighter and easily wraps to a new line.</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <button type="submit" class="btn btn-primary">Submeter</button>
                                                        <button type="submit" class="btn btn-outline-secondary">Cancelar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Novo usuário</h3>
                                            <div class="card-options ">
                                                <a href="#" class="card-options-collapse" data-toggle="card-collapse">
                                                    <i data-feather="chevron-up"></i>
                                                </a>
                                                <a href="#" class="card-options-remove" data-toggle="card-remove">
                                                <i data-feather="x"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <form action="../controllers/create/users" method="POST" name="formuser">
                                            <input type="hidden" name="idEmployees" value="<?= $idEmployees ?>">
                                            <div class="card-body">
                                            <div class="row clearfix">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label>Usuário</label>
                                                        <input type="text" class="form-control" name="username" required autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label>Perfil</label>
                                                    <select class="form-control show-tick" name="profile" required>
                                                        <option value="da">Admin</option>
                                                        <option value="Luanda">Luanda</option>
                                                        <option value="Bengo">Bengo</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="form-group">
                                                        <label>Senha</label>
                                                        <input type="password" class="form-control" name="password" required autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-12">
                                                    <div class="form-group">
                                                        <label>Confirmar Senha</label>
                                                        <input type="password" id="password2" class="form-control" name="confirm_password" required autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-primary" onclick="return validar()">Submeter</button>
                                                </div>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php }else{ ?>
                        <div class="tab-pane active" id="pro-all">
                            <div class="table-responsive">
                                <table class="table table-hover table-vcenter table_custom text-nowrap spacing5 border-style mb-0">
                                    <tbody>
                                    <?php
                                        // Consulta SQL para realizar a pesquisa avançada
                                        $query = "SELECT * FROM users";
                                        $stmt = $conn->query($query);
                                        
                                        // Verifica se foram encontrados resultados
                                        if ($stmt->rowCount()) {
                                            while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                $idUser = $dados['id'];
                                                $username = $dados['username'];
                                                $profile = $dados['profile'];
                                                $status = $dados['status'];
                                                $created = $dados['created'];
                                    ?>
                                        <tr>
                                            <td>
                                                <div class="font-15" id="data">CB-0<?= $idUser; ?></div>
                                            </td>
                                            <td>
                                                <div class="font-15"><?= $username; ?></div>
                                            </td>
                                            <td>
                                                <span>
                                                    <?php
                                                        $varTable=$profile;
                                                        if ($varTable=="da") {
                                                            echo "Administração";
                                                        }elseif ($varTable=="rh") {
                                                            echo "Recursos Humanos";
                                                        }elseif ($varTable=="das") {
                                                            echo "Secretaria";
                                                        }elseif ($varTable=="daf") {
                                                            echo "Finanças";
                                                        }elseif ($varTable=="dac") {
                                                            echo "Acadêmico";
                                                        }elseif ($varTable=="dti") {
                                                            echo "Informática";
                                                        }
                                                    ?>
                                                </span>
                                            </td>
                                            <td><span class="text-muted">
                                                    <?php
                                                        $vars=$status;
                                                        if ($vars=="on") {
                                                            echo "Ativo";
                                                        }else{
                                                            echo "Inativo";
                                                        }
                                                    ?>
                                                </span>
                                            </td>
                                            <td><span class="tag tag-success"></span><?= $created; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-icon btn-sm" title="View" data-toggle="modal" data-target="#ModalView<?= $idUser ?>">
                                                    <i data-feather="eye"></i>
                                                </button>
                                                <button type="button" class="btn btn-icon btn-sm" title="Edit" data-toggle="modal" data-target="#ModalEdit<?= $idUser ?>">
                                                    <i data-feather="edit" class="text-orange"></i>
                                                </button>
                                                <button type="button" class="btn btn-icon btn-sm js-sweetalert" title="Delete" data-type="confirm" data-toggle="modal" data-target="#ModalDelete<?= $idUser ?>">
                                                    <i data-feather="trash" class="text-danger"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php 
                                            }
                                        } else {
                                    ?>
                                    <center><a href="#!" class="text-center" style="text-align: center; font-family: L4">Nenhum resultado encontrado.</a></center>
                                    <?php 
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php } ?>

                    </div>
                </div>
            </div>

            <div class="section-body">
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                Copyright © 2019 <a
                                    href="https://themeforest.net/user/puffintheme/portfolio">PuffinTheme</a>.
                            </div>
                            <div class="col-md-6 col-sm-12 text-md-right">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item"><a
                                            href="https://nsdbytes.com/template/ericssionss/doc/index.html">Documentation</a>
                                    </li>
                                    <li class="list-inline-item"><a href="javascript:void(0)">FAQ</a></li>
                                    <li class="list-inline-item"><a href="javascript:void(0)"
                                            class="btn btn-outline-primary btn-sm">Buy Now</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>

    <script>
      feather.replace()
    </script>
    <script src="../assets/bundles/lib.vendor.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"
        type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../assets/bundles/summernote.bundle.js" type="84bad0df44a88b049b511662-text/javascript"></script>

    <script src="../assets/js/core.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/form/dropify.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="assets/js/page/summernote.js" type="84bad0df44a88b049b511662-text/javascript"></script>
    <script src="../../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js"
        data-cf-settings="84bad0df44a88b049b511662-|49" defer></script>
    <script>
    (function() {
        var js =
            "window['__CF$cv$params']={r:'7dd4b640d8bd4931',m:'ylhOZFbX0HS1c4DPak1Yq5UidcMrX0PisknfubBMMH4-1687774766-0-AUNBl0Ey9/ml/1dDGoabBYZ977e9URVHmQjn28JNXdC6'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";
        var _0xh = document.createElement('iframe');
        _0xh.height = 1;
        _0xh.width = 1;
        _0xh.style.position = 'absolute';
        _0xh.style.top = 0;
        _0xh.style.left = 0;
        _0xh.style.border = 'none';
        _0xh.style.visibility = 'hidden';
        document.body.appendChild(_0xh);

        function handler() {
            var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;
            if (_0xi) {
                var _0xj = _0xi.createElement('script');
                _0xj.nonce = '';
                _0xj.innerHTML = js;
                _0xi.getElementsByTagName('head')[0].appendChild(_0xj);
            }
        }
        if (document.readyState !== 'loading') {
            handler();
        } else if (window.addEventListener) {
            document.addEventListener('DOMContentLoaded', handler);
        } else {
            var prev = document.onreadystatechange || function() {};
            document.onreadystatechange = function(e) {
                prev(e);
                if (document.readyState !== 'loading') {
                    document.onreadystatechange = prev;
                    handler();
                }
            };
        }
    })();
    </script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816"
        integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw=="
        data-cf-beacon='{"rayId":"7dd4b640d8bd4931","version":"2023.4.0","r":1,"b":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":100}'
        crossorigin="anonymous"></script>
        <script>
      // Obtém a data atual
      var data = new Date();

      // Obtém as partes da data (dia, mês e ano)
      var dia = data.getDate().toString().padStart(2, '0');
      var mes = (data.getMonth() + 1).toString().padStart(2, '0');
      var ano = data.getFullYear();

      // Atualiza o valor do input com a data atual
      document.getElementById("data").value = dia + "/" + mes + "/" + ano;
      </script>

      <script type="text/javascript">
        function validar(){
            var password = formuser.password.value;
            var confirm_password = formuser.confirm_password.value;
            
            if (password != confirm_password) {
                alert('Palavras-passe Diferentes');
                formuser.password.focus();
                return false;
            }
        }
    </script>
</body>

<!-- Mirrored from nsdbytes.com/template/ericssionss/university/professors.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Jun 2023 10:20:01 GMT -->

</html>