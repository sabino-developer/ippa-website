<?php
session_start();

if (file_exists('../controllers/config/connection.php')) {
    require_once "../controllers/config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

$pagename = "Área Pedagógica";

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login");
    exit;
}

$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);

// Verifica se há um parâmetro de busca
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
?>

<!doctype html>
<html lang="pt" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title><?= $pagename ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
    <link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />
    <link rel="stylesheet" href="../assets/plugins/datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/plugins/animate.css/animate.min.css">
    <link rel="stylesheet" href="../assets/plugins/sweetalert/sweetalert.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.min.css" />
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        
        .table_custom {
            border-radius: 8px;
            overflow: hidden;
        }
        
        .table_custom th {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .table_custom tr:hover {
            background-color: rgba(52, 152, 219, 0.1);
        }
        
        .tag {
            font-weight: 600;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .tag-success {
            background-color: rgba(46, 204, 113, 0.2);
            color: #2ecc71;
        }
        
        .tag-danger {
            background-color: rgba(231, 76, 60, 0.2);
            color: #e74c3c;
        }
        
        .page-title {
            color: var(--secondary-color);
            font-weight: 700;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 10px 15px;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary-color);
            font-weight: 600;
            border-bottom: 3px solid var(--primary-color);
        }
        
        .animated-fast {
            animation-duration: 0.5s;
        }
        
        .search-container {
            position: relative;
            margin-bottom: 20px;
        }
        
        .search-container .form-control {
            padding-left: 40px;
            border-radius: 20px;
        }
        
        .search-container i {
            position: absolute;
            left: 15px;
            top: 12px;
            color: #6c757d;
        }
        
        .action-buttons a, .action-buttons button {
            margin: 0 5px;
            transition: all 0.3s;
        }
        
        .action-buttons a:hover, .action-buttons button:hover {
            transform: scale(1.1);
        }
        
        .status-toggle {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .status-toggle input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .status-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
        }
        
        .status-slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .status-slider {
            background-color: #2ecc71;
        }
        
        input:checked + .status-slider:before {
            transform: translateX(26px);
        }
    </style>
</head>

<body class="font-muli theme-cyan gradient">

    <?php if (isset($_GET['success']) && $_GET['success'] === 'true'): ?>
    <script>
        $(document).ready(function() {
            Swal.fire({
                title: 'Sucesso!',
                text: 'Operação realizada com sucesso.',
                icon: 'success',
                confirmButtonColor: '#3498db',
                timer: 3000,
                timerProgressBar: true
            });
        });
    </script>
    <?php endif; ?>

    <?php
    if (file_exists('sections/loader.php')) {
        require_once "sections/loader.php";
    } else {
        echo "<span class='text-danger'>O arquivo loader não foi encontrado!</span>";
    }
    ?>

    <div id="main_content">

        <?php
        if (file_exists('sections/min-sidebar.php')) {
            require_once "sections/min-sidebar.php";
        }
        
        if (file_exists('sections/right-sidebar.php')) {
            require_once "sections/right-sidebar.php";
        }
        
        if (file_exists('sections/theme.php')) {
            require_once "sections/theme.php";
        }
        
        if (file_exists('sections/sidebar.php')) {
            require_once "sections/sidebar.php";
        }
        ?>

        <div class="page">

            <?php
            if (file_exists('sections/navbar.php')) {
                require_once "sections/navbar.php";
            }
            ?>

            <div class="section-body">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="header-action">
                            <h1 class="page-title"><?= $pagename ?></h1>
                            <ol class="breadcrumb page-breadcrumb">
                                <li class="breadcrumb-item"><a href="areaPedagogica"><i class="fas fa-home mr-2"></i>Área Pedagógica</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?= $pagename ?></li>
                            </ol>
                        </div>
                        <button class="btn btn-primary" data-toggle="modal" data-target="#addCourseModal">
                            <i class="fas fa-plus mr-2"></i>Novo Curso
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card animated fadeIn">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-graduation-cap mr-2"></i>Cursos do Sistema</h3>
                                    <div class="card-options">
                                        <form method="GET" action="">
                                            <div class="search-container">
                                                <i class="fas fa-search"></i>
                                                <input type="text" class="form-control" name="search" placeholder="Pesquisar cursos..." value="<?= htmlspecialchars($search) ?>">
                                            </div>
                                        </form>
                                    </div>
            </div>
            <div class="card-body">
            <div class="table-responsive">
            <table class="table table-hover table-vcenter table_custom text-nowrap spacing5 border-style mb-0">
                <thead>
                    <tr>
                        <th style="text-align: center">Cursos</th>
                        <th style="text-align: center">Vagas</th>
                        <th style="text-align: center">Coordenador</th>
                        <th style="text-align: center">Estado</th>
                        <th style="text-align: center">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta SQL para buscar os dados da tabela "curso" com filtro de busca
                    $sql = "SELECT curso.id, funcionarios.nome AS 'resp', curso.nome AS 'nomeCurso', 
                    curso.vagas AS 'vagasCurso', curso.status AS 'statusCurso' FROM curso 
                    INNER JOIN funcionarios ON curso.idFunc = funcionarios.id";
                    
                    // Adiciona filtro de busca se existir
                    if (!empty($search)) {
                        $sql .= " WHERE curso.nome LIKE :search OR funcionarios.nome LIKE :search";
                    }
                    
                    $sql .= " ORDER BY curso.nome ASC";
                    
                    $stmt = $conn->prepare($sql);
                    
                    if (!empty($search)) {
                        $searchParam = "%$search%";
                        $stmt->bindParam(':search', $searchParam);
                    }
                    
                    $stmt->execute();
                    
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    ?>
                        <tr class="animated-fast fadeIn">
                            <td style="text-align: center"><?= htmlspecialchars($row['nomeCurso']); ?></td>
                            <td style="text-align: center">
                                <strong><?= htmlspecialchars($row['vagasCurso']); ?></strong>
                            </td>
                            <td style="text-align: center">
                                <strong><?= htmlspecialchars($row['resp']); ?></strong>
                            </td>
                            <td style="text-align: center">
                                <?php
                                $var = $row['statusCurso'];
                                if ($var == "on") {
                                ?>
                                    <span class="tag tag-success">
                                        Ativo
                                    </span>
                                <?php
                                } else {
                                ?>
                                    <span class="tag tag-danger">
                                        Inativo
                                    </span>
                                <?php
                                }
                                ?>
                            </td>
                            <td style="text-align: center" class="action-buttons">
                                <button class="btn btn-icon btn-sm btn-primary edit-course" 
                                        data-id="<?= $row['id'] ?>" 
                                        data-nome="<?= htmlspecialchars($row['nomeCurso']) ?>" 
                                        data-vagas="<?= htmlspecialchars($row['vagasCurso']) ?>" 
                                        data-idfunc="<?= $row['id'] ?>"
                                        data-status="<?= $row['statusCurso'] ?>"
                                        title="Editar">
                                    <i data-feather="edit"></i>
                                </button>
                                <button class="btn btn-icon btn-sm btn-danger delete-course" 
                                        data-id="<?= $row['id'] ?>" 
                                        title="Eliminar">
                                    <i data-feather="trash-2"></i>
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card animated fadeIn">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-info-circle mr-2"></i>Informações</h3>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        Aqui você pode gerenciar os cursos do sistema. 
                                        Um novo curso será disponibilizado para cadastro de novas turmas e salas.
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="icon-circle bg-primary mr-3">
                                            <i class="fas fa-user text-white"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Bem-vindo, <?= $username ?></h6>
                                            <small class="text-muted"><?= $profile ?></small>
                                        </div>
                                    </div>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle mr-2"></i>
                                        Ao desativar um curso, ele não estará mais disponível para novas matrículas.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
     // Consulta SQL para buscar os dados da tabela "ano"
       // Consulta SQL para buscar o ano letivo ativo
        $sql = "SELECT id FROM ano WHERE estado='Ativo' ORDER BY anoTermino ASC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $anoAtivo = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <!-- Add Course Modal -->
    <div class="modal fade" id="addCourseModal" tabindex="-1" role="dialog" aria-labelledby="addCourseModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCourseModalLabel"><i class="fas fa-plus-circle mr-2"></i>Adicionar Novo Curso</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="courseForm" action="../controllers/create/cursos.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" class="form-control" name="idano" required value="<?= $anoAtivo['id'] ?>">

                        <div class="form-group">
                            <label for="nome"><i class="fas fa-book mr-2"></i>Nome do Curso</label>
                            <input type="text" id="nome" name="nome" class="form-control" autocomplete="off" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-user-tie mr-2"></i>Coordenador</label>
                            <select class="form-control select2" name="idFunc" id="idFunc" required>
                                <option value="" selected disabled>-- Selecione --</option>
                                <?php
                                $sql = "SELECT funcionarios.id, funcionarios.nome FROM 
                                funcionarios INNER JOIN funcao ON funcionarios.idFuncao = funcao.id
                                WHERE funcao.nome = 'professor'";
                                $stmt = $conn->prepare($sql);
                                $stmt->execute();

                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                    <option value="<?= $row['id']; ?>">
                                        <?= $row['nome']; ?>
                                    </option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="vagas"><i class="fas fa-users mr-2"></i>Número de Vagas</label>
                            <input type="number" id="vagas" name="vagas" class="form-control" min="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar Curso</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/plugins/dropify/js/dropify.min.js"></script>
    <script src="../assets/plugins/summernote/dist/summernote.js"></script>
    <script src="../assets/bundles/dataTables.bundle.js"></script>
    <script src="../assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script src="../assets/js/core.js"></script>
    <script src="assets/js/form/dropify.js"></script>
    <script src="assets/js/page/summernote.js"></script>
    <script src="assets/js/table/datatable.js"></script>
    
    <script>
        feather.replace();
        
        $(document).ready(function() {
            // Inicializa Select2
            $('.select2').select2({
                placeholder: "Selecione um coordenador",
                width: '100%'
            });
            
            // Tooltip
            $('[data-toggle="tooltip"]').tooltip();
            
            // Status toggle
            $('#statusCurso').change(function() {
                if($(this).is(':checked')) {
                    $('#statusText').text('Ativo');
                } else {
                    $('#statusText').text('Inativo');
                }
            });
            
            // Abrir modal para edição
            $('.edit-course').on('click', function() {
                const courseId = $(this).data('id');
                const nomeCurso = $(this).data('nome');
                const vagasCurso = $(this).data('vagas');
                const idFunc = $(this).data('idfunc');
                const status = $(this).data('status');
                
                $('#courseId').val(courseId);
                $('#nomeCurso').val(nomeCurso);
                $('#vagasCurso').val(vagasCurso);
                $('#idFunc').val(idFunc).trigger('change');
                
                if(status === 'on') {
                    $('#statusCurso').prop('checked', true);
                    $('#statusText').text('Ativo');
                } else {
                    $('#statusCurso').prop('checked', false);
                    $('#statusText').text('Inativo');
                }
                
                $('#addCourseModalLabel').html('<i class="fas fa-edit mr-2"></i>Editar Curso');
                $('#courseForm').attr('action', '../controllers/update/cursos.php');
                $('#addCourseModal').modal('show');
            });
            
            // Abrir modal para novo curso
            $('[data-target="#addCourseModal"]').on('click', function() {
                $('#courseId').val('');
                $('#courseForm')[0].reset();
                $('#idFunc').val('').trigger('change');
                $('#statusCurso').prop('checked', true);
                $('#statusText').text('Ativo');
                $('#addCourseModalLabel').html('<i class="fas fa-plus-circle mr-2"></i>Adicionar Novo Curso');
                $('#courseForm').attr('action', '../controllers/create/cursos.php');
            });
            
            // Confirmar exclusão
            $('.delete-course').on('click', function() {
                const courseId = $(this).data('id');
                
                Swal.fire({
                    title: 'Tem certeza?',
                    text: "Você não poderá reverter esta ação!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sim, excluir!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `../controllers/delete/cursos.php?id=${courseId}`;
                    }
                });
            });
            
            // Validação do formulário
            $('#courseForm').on('submit', function(e) {
                const nomeCurso = $('#nomeCurso').val().trim();
                const vagas = parseInt($('#vagasCurso').val());
                
                if(nomeCurso === '') {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Erro!',
                        text: 'Por favor, informe o nome do curso.',
                        icon: 'error',
                        confirmButtonColor: '#3498db'
                    });
                    return;
                }
                
                if(isNaN(vagas) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Erro!',
                        text: 'Por favor, informe um número válido para as vagas.',
                        icon: 'error',
                        confirmButtonColor: '#3498db'
                    });
                    return;
                }
                
                if(vagas <= 0) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Erro!',
                        text: 'O número de vagas deve ser maior que zero.',
                        icon: 'error',
                        confirmButtonColor: '#3498db'
                    });
                    return;
                }
            });
            
            // Fechar modal após submit
            $('#courseForm').on('submit', function() {
                setTimeout(function() {
                    $('#addCourseModal').modal('hide');
                }, 1000);
            });
        });
    </script>
</body>
</html>