<?php
    if (file_exists('../controllers/config/config-login.php')) {
        require_once "../controllers/config/config-login.php";
    } else {
        echo "<span class='text-danger'>O arquivo config-login não foi encontrado!</span>";
    }
?>
<!doctype html>
<html lang="pt-BR" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Login - ANHERC-IPPA</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.min.css" />
    <link rel="stylesheet" href="assets/css/custom.css" />
    
    <!-- Animate.css para efeitos suaves -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px;
        }
        
        .login-container {
            max-width: 1000px;
            width: 100%;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            animation: fadeIn 0.5s ease-in-out;
        }
        
        .login-form {
            padding: 40px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-image {
            flex: 1;
            background: url('assets/image/ANHERC.png') center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .login-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(41, 128, 185, 0.8);
        }
        
        .login-image-content {
            position: relative;
            z-index: 1;
            color: white;
            text-align: center;
            padding: 20px;
        }
        
        .logo {
            width: 100px;
            height: auto;
            margin-bottom: 20px;
        }
        
        .form-control {
            border-radius: 8px;
            padding: 12px 15px;
            border: 1px solid #ddd;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-login {
            background-color: var(--primary-color);
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        .btn-login:active {
            transform: translateY(0);
        }
        
        .form-footer {
            margin-top: 20px;
            text-align: center;
        }
        
        .form-footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .form-footer a:hover {
            text-decoration: underline;
        }
        
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }
        
        .input-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #777;
        }
        
        .input-with-icon {
            padding-left: 40px;
        }
        
        .show-password {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
        }
        
        .show-password:hover {
            color: var(--primary-color);
        }
        
        .welcome-message {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .welcome-sub {
            color: #777;
            margin-bottom: 30px;
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            
            .login-image {
                display: none;
            }
        }
        
        /* Animação para campos com erro */
        .has-error .form-control {
            animation: shake 0.5s;
            border-color: var(--accent-color);
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .help-block {
            color: var(--accent-color);
            font-size: 0.85rem;
            margin-top: 5px;
            display: block;
        }
    </style>
</head>

<body>
    <div class="login-container animate__animated animate__fadeIn">
        <div class="login-form">
            <div class="text-center mb-4">
                <img src="assets/image/ANHERC.png" alt="Logo ANHERC" class="logo">
                <h1 class="welcome-message">Bem-vindo ao ANHERC-IPPA</h1>
                <p class="welcome-sub">Por favor, faça login para continuar</p>
            </div>
            
            <form method="POST" action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                <div class="form-group <?= (!empty($username_err)) ? 'has-error' : ''; ?>">
                    <div class="input-group">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" class="form-control input-with-icon" name="username" id="username" 
                               value="<?= $username; ?>" placeholder="Nome de Usuário" autocomplete="username" required>
                    </div>
                    <span class="help-block"><?= $username_err; ?></span>
                </div>
                
                <div class="form-group <?= (!empty($password_err)) ? 'has-error' : ''; ?>">
                    <div class="input-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" class="form-control input-with-icon" name="password" id="password" 
                               placeholder="Senha" autocomplete="current-password" required>
                        <i class="fas fa-eye show-password" id="togglePassword"></i>
                    </div>
                    <span class="help-block"><?= $password_err; ?></span>
                </div>
                
                <div class="form-group form-check mb-4">
                    <input type="checkbox" class="form-check-input" id="rememberMe" name="remember" value="1">
                    <label class="form-check-label" for="rememberMe">Lembrar de mim</label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block btn-login mb-3">
                    <i class="fas fa-sign-in-alt mr-2"></i> Entrar
                </button>
                
                <div class="form-footer">
                    <a href="#" class="d-block mb-2">Esqueceu sua senha?</a>
                    <span>Não tem uma conta? <a href="#">Registre-se</a></span>
                </div>
            </form>
        </div>
        
        <div class="login-image">
            <div class="login-image-content">
                <h2 class="animate__animated animate__fadeInDown">Sistema ANHERC-IPPA</h2>
                <p class="animate__animated animate__fadeInUp animate__delay-1s">Gestão integrada de processos administrativos</p>
            </div>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="../assets/bundles/lib.vendor.bundle.js"></script>
    <script src="../assets/js/core.js"></script>
    <script src="assets/js/icons.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
    <script>
        // Mostrar/ocultar senha
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');
        
        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
        
        // Validação do formulário
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                const forms = document.getElementsByClassName('needs-validation');
                const validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
        
        // Efeito de hover nos botões
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                button.style.transform = 'translateY(-2px)';
            });
            button.addEventListener('mouseleave', () => {
                button.style.transform = 'translateY(0)';
            });
        });
        
        // Foco no campo de usuário ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            const usernameField = document.getElementById('username');
            if (usernameField) {
                usernameField.focus();
            }
        });
    </script>
</body>
</html>