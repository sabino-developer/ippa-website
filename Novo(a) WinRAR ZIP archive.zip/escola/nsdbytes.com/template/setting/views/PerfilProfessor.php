<?php
    session_start();

    if (file_exists('../controllers/config/connection.php')) {
        require_once "../controllers/config/connection.php";
    } else {
        echo "<span class='text-danger'>Arquivo de conexão não encontrado!</span>";
    }

    $pagename = "Portal do Professor";

    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: login");
        exit;
    }

    $id = htmlspecialchars($_SESSION["id"]);
    $username = htmlspecialchars($_SESSION["username"]);
    $profile = htmlspecialchars($_SESSION["profile"]);
    
    // Buscar dados do professor
    $stmt = $conn->prepare("SELECT * FROM professores WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $professor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Estatísticas
    $turmas = $conn->query("SELECT COUNT(*) FROM turmas WHERE professor_id = $id")->fetchColumn();
    $disciplinas = $conn->query("SELECT COUNT(DISTINCT disciplina_id) FROM turmas WHERE professor_id = $id")->fetchColumn();
    $alunos = $conn->query("SELECT COUNT(*) FROM matriculas WHERE turma_id IN (SELECT id FROM turmas WHERE professor_id = $id)")->fetchColumn();
    $aulas_hoje = $conn->query("SELECT COUNT(*) FROM aulas WHERE professor_id = $id AND data = CURDATE()")->fetchColumn();
?>
<!doctype html>
<html lang="pt-BR" dir="ltr">
<head>
    <!-- Meta tags e CSS permanecem iguais -->
    <style>
        /* Ajustes de cores */
        :root {
            --primary-color: #3f51b5;
            --secondary-color: #303f9f;
            --accent-color: #ff5722;
        }
        
        .card-urgente {
            border-left: 4px solid var(--accent-color);
        }
    </style>
</head>

<body class="font-muli theme-cyan gradient">

    <!-- Seções permanecem iguais até a área de conteúdo -->

    <div class="section-body">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div class="header-action">
                    <h1 class="page-title animate__animated animate__fadeInDown">Bem-vindo, Prof. <?= $professor['nome'] ?></h1>
                    <ol class="breadcrumb page-breadcrumb animate__animated animate__fadeIn">
                        <li class="breadcrumb-item"><a href="dashboard"><i class="fas fa-chalkboard-teacher mr-2"></i>Painel</a></li>
                        <li class="breadcrumb-item active"><i class="fas fa-book-open mr-2"></i>Disciplinas</li>
                    </ol>
                </div>
                <div class="animate__animated animate__fadeIn">
                    <span class="secretaria-badge"><i class="fas fa-chalkboard-teacher mr-1"></i> <?= $profile ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Estatísticas Rápidas -->
    <div class="section-body mt-3 animate__animated animate__fadeIn">
        <div class="container-fluid">
            <div class="quick-stats">
                <div class="row text-center">
                    <div class="col-6 col-md-3 stat-item">
                        <div class="stat-number"><?= $turmas ?></div>
                        <div class="stat-label">Turmas</div>
                    </div>
                    <div class="col-6 col-md-3 stat-item">
                        <div class="stat-number"><?= $disciplinas ?></div>
                        <div class="stat-label">Disciplinas</div>
                    </div>
                    <div class="col-6 col-md-3 stat-item">
                        <div class="stat-number"><?= $alunos ?></div>
                        <div class="stat-label">Alunos</div>
                    </div>
                    <div class="col-6 col-md-3 stat-item">
                        <div class="stat-number"><?= $aulas_hoje ?></div>
                        <div class="stat-label">Aulas Hoje</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-body mt-2 animate__animated animate__fadeIn">
        <div class="container-fluid">
            <div class="row clearfix row-deck">
                <!-- Minhas Turmas -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="50">
                    <div class="card">
                        <div class="card-body ribbon">
                            <div class="ribbon-box purple"><?= $turmas ?></div>
                            <a href="turmas" class="my_sort_cut text-muted">
                                <i class="fas fa-users-class"></i>
                                <span>Minhas Turmas</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Disciplinas -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="100">
                    <div class="card pulse-card">
                        <div class="card-body ribbon">
                            <div class="ribbon-box green"><?= $disciplinas ?></div>
                            <a href="disciplinas" class="my_sort_cut text-muted">
                                <i class="fas fa-book-open"></i>
                                <span>Disciplinas</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Lançar Notas -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="150">
                    <div class="card card-urgente">
                        <div class="card-body">
                            <a href="lancar_notas" class="my_sort_cut text-muted">
                                <i class="fas fa-clipboard-check"></i>
                                <span>Lançar Notas</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Horário -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="200">
                    <div class="card">
                        <div class="card-body">
                            <a href="horario" class="my_sort_cut text-muted">
                                <i class="fas fa-calendar-alt"></i>
                                <span>Meu Horário</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Aulas de Hoje -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="250">
                    <div class="card">
                        <div class="card-body ribbon">
                            <div class="ribbon-box orange"><?= $aulas_hoje ?></div>
                            <a href="aulas_hoje" class="my_sort_cut text-muted">
                                <i class="fas fa-chalkboard"></i>
                                <span>Aulas Hoje</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Relatórios -->
                <div class="col-6 col-md-4 col-xl-2" data-aos="fade-up" data-aos-delay="300">
                    <div class="card">
                        <div class="card-body">
                            <a href="relatorios" class="my_sort_cut text-muted">
                                <i class="fas fa-file-alt"></i>
                                <span>Relatórios</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Seção de Avisos -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="fas fa-bell mr-2"></i>Avisos Importantes</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <?php
                                    $avisos = $conn->query("SELECT * FROM avisos WHERE destinatario = 'professores' ORDER BY data DESC LIMIT 3");
                                    while($aviso = $avisos->fetch(PDO::FETCH_ASSOC)):
                                ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div><?= $aviso['mensagem'] ?></div>
                                        <small class="text-muted"><?= date('d/m/Y', strtotime($aviso['data'])) ?></small>
                                    </div>
                                </li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Botão Flutuante para Ajuda -->
    <a href="#" class="floating-btn animate__animated animate__bounceInUp animate__delay-1s">
        <i class="fas fa-question"></i>
    </a>

    <!-- Scripts permanecem iguais -->
    <script>
        // Ajuste no tooltip do botão flutuante
        $('.floating-btn').click(function(e) {
            e.preventDefault();
            alert('Suporte Professor:\n\n1. Minhas Turmas: Visualize suas turmas\n2. Disciplinas: Suas disciplinas lecionadas\n3. Lançar Notas: Sistema de avaliação\n4. Horário: Sua agenda semanal');
        });
    </script>
</body>
</html>