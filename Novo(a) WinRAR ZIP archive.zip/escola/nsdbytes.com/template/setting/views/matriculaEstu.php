<?php

// initialize the session
session_start();

if (file_exists('../controllers/config/connection.php')) {
require_once "../controllers/config/connection.php";
} else {
echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

$pagename = "Secretária";

// check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
header("location: login");
exit;
}


$id = htmlspecialchars($_SESSION["id"]);
$username = htmlspecialchars($_SESSION["username"]);
$profile = htmlspecialchars($_SESSION["profile"]);


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<title><?= $pagename ?></title>

<link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="../assets/plugins/dropify/css/dropify.min.css">
<link rel="stylesheet" href="../assets/plugins/summernote/dist/summernote.css" />
<link rel="stylesheet" href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
<link rel="stylesheet" href="../assets/plugins/datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">

<link rel="stylesheet" href="assets/css/style.min.css" />
<link rel="stylesheet" href="assets/css/all.min.css" />
<script src="https://unpkg.com/feather-icons"></script>
<script src="assets/css/feather-icons.css"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css" />

<link rel="stylesheet" href="../assets/css/style.min.css" />

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#cursos').change(function() {
var id = $(this).val();
$.ajax({
    url: 'listar-classe.php',
    type: 'POST',
    data: {
        id: id
    },
    success: function(response) {
        $('#idClasse').html(response);
        $('#div-Classe').show();
    },
    error: function(xhr, status, error) {
        console.log(xhr.responseText);
    }
});
});
});
</script>
</head>
<body  class="font-muli theme-cyan gradient">
    <?php

if (isset($_GET['success']) && $_GET['success'] === 'true') {
?>
<script>
$(document).ready(function() {
$('#successModal').modal('show');
});
</script>

<?php
}
?>

<?php

?><?php

if (file_exists('sections/min-sidebar.php')) {
require_once "sections/min-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo min-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/right-sidebar.php')) {
require_once "sections/right-sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo right-sidebar não foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/theme.php')) {
require_once "sections/theme.php";
} else {
echo "<span class='text-danger'>O arquivo theme foi encontrado!</span>";
}

?>

<?php

if (file_exists('sections/sidebar.php')) {
require_once "sections/sidebar.php";
} else {
echo "<span class='text-danger'>O arquivo sidebar foi encontrado!</span>";
}

?>

<div class="page">

<?php

if (file_exists('sections/navbar.php')) {
require_once "sections/navbar.php";
} else {
echo "<span class='text-danger'>O arquivo navbar foi encontrado!</span>";
}

?> 
<div class="section-body">
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center ">
        <div class="header-action">
            <h1 class="page-title"><?= $pagename ?></h1>
            <ol class="breadcrumb page-breadcrumb">
                <li class="breadcrumb-item"><a href="secretaria">Secretaria Geral</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $pagename ?></li>
            </ol>
        </div>
    </div>
</div>
</div> 

              
     <div class="tab-pane active" id="pro-add">
            <div class="row clearfix">
                <div class="col-lg-10 col-md-12 col-sm-12" style="left:100px">
                    <div class="card">
                        <!DOCTYPE html>
<html lang="pt">
<head>

            <body><div class="tab-pane " id="pro-all">
            
                                <?php

                                  // Obtém o ID da Instricao da URL
                                    $idInscr = $_GET["id"];

                                // Consulta SQL para realizar a pesquisa avançada
                                    $query = "SELECT curso.id as idCurso, classe.id as idClasse,ano.id,inscricao.id as idInscr, inscricao.codigo,inscricao.nome as nomeEs ,inscricao.metodoPag,inscricao.valorPago,inscricao.taxaInscr,
                                    sala.turno,classe.nclasse,(valorPago-taxaInscr) AS troco,curso.nome as curso FROM inscricao
                                    inner JOIN classe on inscricao.idClasse=classe.id
                                    INNER JOIN curso ON inscricao.idCurso=curso.id
                                    INNER JOIN sala on classe.idsala=sala.id
                                    INNER JOIN ano ON inscricao.idano=ano.id WHERE  
                                    inscricao.id = '$idInscr'";

                                $stmt = $conn->query($query);

                                // Verifica se foram encontrados resultados
                                if ($stmt->rowCount()) {
                                    while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        $id = $dados['id'];
                                        $codigo = $dados['codigo'];
                                        $nomeEs = $dados['nomeEs'];
                                        $curso = $dados['curso'];
                                        $nclasse = $dados['nclasse'];
                                     
                                        $metodoPag = $dados['metodoPag'];
                                        $valorPago = $dados['valorPago'];
                                        $taxaInscr = $dados['taxaInscr'];
                                        $troco = $dados['troco'];
                                        $idInscr = $dados['idInscr'];
                                        
                                        $turno = $dados['turno'];
                                        $idClasse = $dados['idClasse'];
                                        $idCurso = $dados['idCurso'];
                                        ?>
                                <?php
                                    }
                                }
                                ?>

              
                   <?php
             // Consulta SQL para buscar os dados da tabela "ano"
                $sql = "SELECT ano.id FROM ano WHERE estado='Ativo' ORDER BY anoTermino ASC";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
            ?> 

                    <div class="container mt-5">
                        <form action="../controllers/create/matriculaEstu.php" method="POST" class="form-container">
                            <h4 class="mb-4 text-primary">
                                <i class="fas fa-user-graduate"></i> Ficha de Matrícula do Estudante
                            </h4>

                            <!-- Campos escondidos -->
                            <input type="hidden" name="idano" value="<?= $id ?>">
                            <input type="hidden" name="idInscr">
                            <input type="hidden" name="idturma">
                            <input type="hidden" name="idClasse">
                            <input type="hidden" name="idCurso">

                            <!-- Campos visíveis -->
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Código do Estudante</label>
                                    <input type="text" class="form-control" name="codigo" readonly placeholder="Código gerado" value="<?= $codigo ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Nome do Estudante</label>
                                    <input type="text" class="form-control" name="nomeEs" readonly required  value="<?= $nomeEs ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Curso</label>
                                    <input type="text" class="form-control" name="curso" readonly value="<?= $curso ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Classe</label>
                                    <input type="text" class="form-control" name="classe" readonly value="<?= $nclasse ?>">
                                </div>
                                

                                <div class="col-md-3">
                                    <label class="form-label">Turno</label>
                                    <input type="text" class="form-control" name="valorPago" readonly placeholder="Ex: 15000" value="<?= $turno ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Sala</label>
                                    <div class="input-group">
                                        <select class="form-control" name="idsala" required>
                                            <option value="" disabled selected>--  Sala --</option>
                                            <?php
                                            $stmt = $conn->query("SELECT * FROM sala");
                                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                echo "<option value='{$row['id']}'>{$row['sala']} - {$row['turno']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label">Método de Pagamento</label>
                                    <input type="text" class="form-control" name="metoPag" readonly placeholder="Ex: Multicaixa" value="<?= $metodoPag ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Taxa de Matrícula</label>
                                    <input type="text" class="form-control" name="taxaInscr" readonly placeholder="Ex: 12000" value="<?= $taxaInscr ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Valor Pago</label>
                                    <input type="number" class="form-control" name="valorPago" readonly placeholder="Ex: 15000" value="<?= $valorPago?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Troco</label>
                                    <input type="number" class="form-control" name="troco" readonly placeholder="Ex: 3000" value="<?= $troco ?>">
                                </div>
                            </div>
                    <!-- Botões -->
                    <div class="d-flex justify-content-end mt-4" style="gap: 17px;">
                        <button type="submit" onclick="print()" class="btn btn-success px-4">
                            Salvar
                        </button>
                        <a href="#" class="btn btn-outline-primary px-4">
                            Editar
                        </a>
                    </div>

                        </form>
                    </div>

                    </body>
                    </html>

        </div>
    </div>
</form>

                    </div>
                </div>
            </div>
        </div>
</body>
</html>