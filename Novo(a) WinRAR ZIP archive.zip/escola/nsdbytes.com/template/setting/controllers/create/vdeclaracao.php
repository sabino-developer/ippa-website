<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

try {

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $idano = $_POST["idano"];
      $tipodeclaraco = $_POST["tipodeclaraco"];
      $valordeclaracao = $_POST["valordeclaracao"];
      

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO valordeclaracao (idano,tipodeclaraco, valordeclaracao) VALUES (:idano,:tipodeclaraco, :valordeclaracao)");

      // Vincula os parâmetros
      $stmt->bindParam(':idano', $idano);
      $stmt->bindParam(':tipodeclaraco', $tipodeclaraco);
      $stmt->bindParam(':valordeclaracao', $valordeclaracao);
      

      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/vdeclaracao';</script>";
      
    }
  } catch(PDOException $e) {
    
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/vdeclaracao';</script>";
      
  }
?>
