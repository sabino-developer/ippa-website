<?php

    session_start();
    require_once "../connection.php";

        if(isset($_POST['idEmployees'])):

            $idEmployees = filter_input(INPUT_POST, 'idEmployees', FILTER_SANITIZE_STRING);
            $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
            $profile = filter_input(INPUT_POST, 'profile', FILTER_SANITIZE_STRING);
            $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            $id = mysqli_escape_string($conn, $_POST['idEmployees']);

            $sql = "INSERT INTO users (idEmployees, username, profile, password) VALUES ('$idEmployees','$username','$profile','$password_hash')";

            if(mysqli_query($conn, $sql)):
                // Exibe um alerta após a inserção
                echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/users?id=$id';</script>";
            else:
                // Exibe um alerta após a inserção
                echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/users?id=$id';</script>" . $e->getMessage();
            endif;
        endif;
?>