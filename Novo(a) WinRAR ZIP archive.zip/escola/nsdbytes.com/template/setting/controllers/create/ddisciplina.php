<?php

// initialize the session
session_start();

if (file_exists('../config/connection.php')) {
  require_once "../config/connection.php";
} else {
  echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {

  // Configura o PDO para lançar exceções em caso de erros
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Captura os dados do formulário
  
  $ndisciplina = $_POST['ndisciplina'];
 

  // Query de ano lectivo usando prepared statement
  $sql = "INSERT INTO disciplina (ndisciplina) VALUES (?)";
  $stmt = $conn->prepare($sql);

  // Executa a ddisciplina
  $stmt->execute([$ndisciplina]);

  // Exibe um alerta após a ser adicionado uma disciplina
  echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/addisciplina';</script>";
} catch (PDOException $e) {

  //echo "Erro na inserção: " . $e->getMessage();

  //  Exibe um alerta após aprentar o erro na insercao da  disciplina
  echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/addisciplina';</script>";
}
