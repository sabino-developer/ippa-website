<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

try {

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $idcurso = $_POST["idcurso"];
      $idsala = $_POST["idsala"];
      $nclasse = $_POST["nclasse"];
      $nvagas = $_POST["nvagas"];
      $idano = $_POST["idano"];

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO classe  (idcurso,idsala, nclasse, nvagas, idano) VALUES (:idcurso,:idsala, :nclasse, :nvagas, :idano)");

      // Vincula os parâmetros
      $stmt->bindParam(':idcurso', $idcurso);
      $stmt->bindParam(':idsala', $idsala);
      $stmt->bindParam(':nclasse', $nclasse);
      $stmt->bindParam(':nvagas', $nvagas);
      $stmt->bindParam(':idano', $idano);

      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/classes';</script>";
      
    }
  } catch(PDOException $e) {
    
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/classes';</script>";
      
  }
?>
