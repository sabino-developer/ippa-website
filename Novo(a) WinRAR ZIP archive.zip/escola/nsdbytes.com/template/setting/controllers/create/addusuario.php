<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";

    try {
        // Verifica se a conexão com o banco de dados foi estabelecida corretamente
        if (!$conn) {
            throw new PDOException("Erro ao conectar ao banco de dados.");
        }

        // Verifica se o formulário foi submetido e se todos os campos necessários estão presentes
        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["username"], $_POST["profile"], $_POST["password"])) {
            // Obtém os dados do formulário
            $username = $_POST["username"];
            $profile = $_POST["profile"];
            $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

            // Prepara a instrução de inserção para usuários
            $query_insert = "INSERT INTO users (username, password, profile) VALUES (?, ?, ?)";
            $stmt_insert = $conn->prepare($query_insert);
            
            // Executa a inserção
            if ($stmt_insert->execute([$username, $password, $profile])) {
                // Inserção bem-sucedida
                echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/tabelauser.php';</script>";
            } else {
                // Falha na inserção
                throw new Exception("Erro ao inserir usuário.");
            }
        } else {
            // Se o formulário não foi submetido ou se algum campo está faltando
            throw new Exception("Todos os campos do formulário são obrigatórios.");
        }
    } catch (PDOException $e) {
        // Exibe a mensagem de erro específica do PDO
        echo "<script>alert('Erro ao realizar operação: " . $e->getMessage() . "'); window.location.href = '../../views/tabelauser.php';</script>";
    } catch (Exception $e) {
        // Exibe a mensagem de erro geral
        echo "<script>alert('Oops, Erro ao realizar operação: " . $e->getMessage() . "'); window.location.href = '../../views/tabelauser.php';</script>";
    }
} else {
    // Exibe uma mensagem se o arquivo de conexão não for encontrado
    echo "<span class='text-danger'>O arquivo connection.php não foi encontrado!</span>";
}
?>
