<?php
// initialize the session
session_start();

// Verifica se o arquivo de conexão existe e se foi incluído com sucesso
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit; // Termina a execução do script se o arquivo de conexão não for encontrado
}

try {
    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se os campos do formulário foram enviados e não estão vazios
    if(isset($_POST['iddisciplina'], $_POST['idclasse']) && !empty($_POST['iddisciplina']) && !empty($_POST['idclasse'])) {
        // Captura os dados do formulário
        $iddisciplina = $_POST['iddisciplina'];
        $idclasse = $_POST['idclasse'];
       

        // Query de inserção usando prepared statement
        $sql = "INSERT INTO displclasse (iddisciplina, idclasse) VALUES (?,?)";
        $stmt = $conn->prepare($sql);

        // Executa a inserção
        $stmt->execute([$iddisciplina, $idclasse]);

        // Exibe um alerta após a inserção
        echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/atribuirDisCla';</script>";
    } else {
        // Exibe um alerta se os campos do formulário não foram enviados ou estão vazios
        echo "<script>alert('Oops, campos obrigatórios não preenchidos!'); window.location.href = '../../views/atribuirDisCla';</script>";
    }
} catch (PDOException $e) {
    // Exibe um alerta se ocorrer um erro durante a inserção
    echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/atribuirDisCla';</script>";
}
?>
