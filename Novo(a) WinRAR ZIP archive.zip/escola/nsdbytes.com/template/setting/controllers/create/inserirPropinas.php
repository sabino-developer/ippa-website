<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

// Função para dividir o total pago pelo número de meses e inserir na tabela de propinas
function inserirPropinas($conn, $qtd, $total, $mes, $valorUnita, $metodoPag, $datapagemento, $idmatri, $idano)
{
    try {
        // Calcula o valor de cada parcela
        $valorParcela = $total / $qtd;

        // Verifica se já existem registros para o mês fornecido
        $queryCheckMonth = "SELECT COUNT(*) as count FROM propina WHERE mes = ?";
        $stmtCheckMonth = $conn->prepare($queryCheckMonth);
        $stmtCheckMonth->execute([$mes]);
        $resultCheckMonth = $stmtCheckMonth->fetch(PDO::FETCH_ASSOC);

        // Verifica se não há registros para o mês fornecido
        if ($resultCheckMonth['count'] == 0) {
            // Insere os registros para o número de vezes fornecido
            for ($i = 0; $i < $qtd; $i++) {
                $queryInsert = "INSERT INTO propinas (idmatri, idano, mes, qtd, valorpago, total, valorUnita, metodoPag, datapagemento, troco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmtInsert = $conn->prepare($queryInsert);
                $stmtInsert->execute([$idmatri, $idano, $mes, $qtd, $valorParcela, $total, $valorUnita, $metodoPag, $datapagemento, ($valorParcela - $valorUnita)]);
            }

            // Exibe mensagem de sucesso após inserção de todas as propinas
            echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/Pagtopropina';</script>";
        }
    } catch (PDOException $e) {
        // Exibe um alerta em caso de erro
        echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/Pagtopropina';</script>";
    }
}

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Obtém os valores do formulário
    $valorUnita = $_POST["valorUnita"];
    $qtd = $_POST["qtd"];
    $total = $_POST["total"];
    $mes = $_POST["mes"];
    $metodoPag = $_POST["metodoPag"];
    $datapagemento = $_POST["datapagemento"]; // Correção do nome do campo
    $idmatri = $_POST["idmatri"];
    $idano = $_POST["idano"]; // Correção do nome do campo

    // Verifica se a conexão com o banco de dados está disponível
    if ($conn) {
        // Chama a função para inserir as propinas na tabela
        inserirPropinas($conn, $qtd, $total, $mes, $valorUnita, $metodoPag, $datapagemento, $idmatri, $idano);
    } else {
        // Exibe um alerta se a conexão não estiver disponível
        echo "<script>alert('Oops, Erro ao conectar ao banco de dados!'); window.location.href = '../../views/Pagtopropina';</script>";
    }
}
?>
