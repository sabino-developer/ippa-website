<?php

// Inicializa a sessão
session_start();

// Verifica se o arquivo connection.php existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {
    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        // Obtém os dados do formulário (supondo que eles foram enviados via POST)
        $idano = $_POST['idano'];
        $nome = $_POST['nome'];
        $genero = $_POST['genero'];
        $dataNasc = $_POST['dataNasc'];
        $documento = $_POST['documento'];
        $telefone = $_POST['telefone'];
        $email = $_POST['email'];
        $idClasse = $_POST['idClasse'];
        $idCurso = $_POST['idCurso'];
        $nomePai = $_POST['nomePai'];
        $nomeMae = $_POST['nomeMae'];
        $nomeResp = $_POST['nomeResp'];
        $telResp = $_POST['telResp'];
        $emailResp = $_POST['emailResp'];
        $metodoPag = $_POST['metodoPag'];
        $taxaInscr = $_POST['taxaInscr'];
        $valorPago = $_POST['valorPago'];
        $codigo = $_POST['codigo'];

        // Verifica se as variáveis necessárias estão definidas
        if (isset($taxaInscr) && isset($valorPago)) {

            // Converte os valores para números para garantir que sejam comparáveis ​​adequadamente
            $taxaInscr = floatval($taxaInscr);
            $valorPago = floatval($valorPago);

            // Verifica se o valor pago é menor ou igual à taxa de inscrição
            if ($valorPago >= $taxaInscr) {

                // Prepara a instrução de inserção
                $stmt = $conn->prepare("INSERT INTO inscricao (idano, nome, genero, dataNasc, documento, telefone, email, idClasse, idCurso, nomePai, nomeMae, nomeResp, telResp, emailResp, metodoPag, taxaInscr, valorPago, codigo) VALUES (:idano, :nome, :genero, :dataNasc, :documento, :telefone, :email, :idClasse, :idCurso, :nomePai, :nomeMae, :nomeResp, :telResp, :emailResp, :metodoPag, :taxaInscr, :valorPago, :codigo)");

                // Vincula os parâmetros
                $stmt->bindParam(':idano', $idano);
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':genero', $genero);
                $stmt->bindParam(':dataNasc', $dataNasc);
                $stmt->bindParam(':documento', $documento);
                $stmt->bindParam(':telefone', $telefone);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':idClasse', $idClasse);
                $stmt->bindParam(':idCurso', $idCurso);
                $stmt->bindParam(':nomePai', $nomePai);
                $stmt->bindParam(':nomeMae', $nomeMae);
                $stmt->bindParam(':nomeResp', $nomeResp);
                $stmt->bindParam(':telResp', $telResp);
                $stmt->bindParam(':emailResp', $emailResp);
                $stmt->bindParam(':metodoPag', $metodoPag);
                $stmt->bindParam(':taxaInscr', $taxaInscr);
                $stmt->bindParam(':valorPago', $valorPago);
                $stmt->bindParam(':codigo', $codigo);

                // Executa a instrução de inserção
                $stmt->execute();

                // Exibe um alerta após a inserção
                echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/inscricao';</script>";
            } else {
                // Se o valor pago for inferior à taxa de inscrição, exibe um alerta e redireciona para a página de inscrição
                echo "<script>alert('Oops, O valor pago é inferior!'); window.location.href = '../../views/inscricao';</script>";
            }
        } else {
            // Se a taxa de inscrição ou o valor pago não estiverem definidos, exibe um alerta e redireciona para a página de inscrição
            echo "<script>alert('Oops, A taxa de inscrição ou o valor pago não estão definidos!'); window.location.href = '../../views/inscricao';</script>";
        }
    }
} catch (PDOException $e) {
    // Exibe um alerta em caso de erro e redireciona para a página de inscrição
    echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/inscricao';</script>";
    echo $e->getMessage();
}

?>
