<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

try {

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $idano = $_POST["idano"];
      $idclasse = $_POST["idclasse"];
      $valorpro = $_POST["valorpro"];
      

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO valorpropina (idano,idclasse, valorpro) VALUES (:idano,:idclasse, :valorpro)");

      // Vincula os parâmetros
      $stmt->bindParam(':idano', $idano);
      $stmt->bindParam(':idclasse', $idclasse);
      $stmt->bindParam(':valorpro', $valorpro);
      

      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/valorpropina';</script>";
      
    }
  } catch(PDOException $e) {
    
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/valorpropina';</script>";
      
  }
?>
