<?php
  // Configuração do banco de dados
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "sgeDB";

  try {
    // Conexão com o banco de dados usando PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $ndisciplina = $_POST["ndisciplina"];

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO disciplina (ndisciplina)
                              VALUES (:ndisciplina)");

      // Vincula os parâmetros
      $stmt->bindParam(':ndisciplina', $ndisciplina);
      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/Disciplina';</script>";

      //header("location: ../../views/Disciplina");
    }
  } catch(PDOException $e) {
      //echo "Erro ao inserir o registro: " . $e->getMessage();
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/Disciplina';</script>" . $e->getMessage();
  }

  // Fecha a conexão com o banco de dados
  $conn = null;
?>
