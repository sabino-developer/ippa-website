<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

try {

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $idDep = $_POST["id"];
      $idFuncao = $_POST["idFuncao"];
      $nome = $_POST["nome"];
      $dataNasc = $_POST["dataNasc"];
      $genero = $_POST["genero"];
      $documento = $_POST["documento"];
      $endereco = $_POST["endereco"];
      $provincia = $_POST["provincia"];
      $telefone = $_POST["telefone"];
      $email = $_POST["email"];
      $avatar = $_POST["avatar"];
      $codigo = $_POST["codigo"];

      
      $formatteddataNasc = date("Y-m-d", strtotime($dataNasc));

      // Verifica se um arquivo de imagem foi enviado
      if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] === 0) {
        // Define o caminho de destino para o upload do arquivo
        $targetDir = "../uploads/";
        $fileName = $_FILES["avatar"]["name"];
        $targetFile = $targetDir . $fileName;

        // Move o arquivo temporário para o diretório de destino
        move_uploaded_file($_FILES["avatar"]["tmp_name"], $targetFile);
      } else {
        // Define um valor padrão se nenhum arquivo de imagem for enviado
        $fileName = "";
      }

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO funcionarios (idDep, idFuncao, nome, dataNasc, genero, documento, endereco, provincia, telefone, email, foto, codigo)
                              VALUES (:idDep, :idFuncao, :nome, :dataNasc, :genero, :documento, :endereco, :provincia, :telefone, :email, :avatar, :codigo)");

      // Vincula os parâmetros
      $stmt->bindParam(':idDep', $idDep);
      $stmt->bindParam(':idFuncao', $idFuncao);
      $stmt->bindParam(':nome', $nome);
      $stmt->bindParam(':dataNasc', $formatteddataNasc);
      $stmt->bindParam(':genero', $genero);
      $stmt->bindParam(':documento', $documento);
      $stmt->bindParam(':endereco', $endereco);
      $stmt->bindParam(':provincia', $provincia);
      $stmt->bindParam(':telefone', $telefone);
      $stmt->bindParam(':email', $email);
      $stmt->bindParam(':avatar', $fileName);
      $stmt->bindParam(':codigo', $codigo);

      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/funcionarios';</script>";
    }
  } catch(PDOException $e) {
    
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/funcionarios';</script>" . $e->getMessage();
  }
?>
