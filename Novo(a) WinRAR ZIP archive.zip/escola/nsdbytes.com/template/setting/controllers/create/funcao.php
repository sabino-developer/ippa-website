<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

try {

    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Captura os dados do formulário
    $idano = $_POST['idano'];
    $nome = $_POST['nome'];
    $idDep = $_POST['idDep'];

    // Query de inserção usando prepared statement
    $sql = "INSERT INTO funcao (idano,nome, idDep) VALUES (?,?, ?)";
    $stmt = $conn->prepare($sql);

    // Executa a inserção
    $stmt->execute([$idano, $nome, $idDep]);

  // Exibe um alerta após a inserção
  echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/funcao';</script>";

} catch (PDOException $e) {
        
            // Exibe um alerta após a inserção
        echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/funcao';</script>";
}
?>
