<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

    try {

        // Configura o PDO para lançar exceções em caso de erros
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Verifica se o formulário foi submetido
        if ($_SERVER["REQUEST_METHOD"] === "POST") {

            // Obtém os dados do formulário
            $idano = $_POST['idano'];
            $nome = $_POST['nome'];
            

          // Prepara a instrução de inserção
          $stmt = $conn->prepare("INSERT INTO departamentos (idano,nome) VALUES (:idano, :nome)");

          // Vincula os parâmetros
          $stmt->bindParam(':idano', $idano);
          $stmt->bindParam(':nome', $nome);


          // Executa a instrução de inserção
          $stmt->execute();

          // Exibe um alerta após a inserção
          echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/departamentos';</script>";
        }
    } catch(PDOException $e) {
        
            // Exibe um alerta após a inserção
        echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/departamentos';</script>";
          
    }
?>
