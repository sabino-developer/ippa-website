<?php

// initialize the session
session_start();

if (file_exists('../config/connection.php')) {
  require_once "../config/connection.php";
} else {
  echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {

  // Configura o PDO para lançar exceções em caso de erros
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Captura os dados do formulário
  
   $idano = $_POST['idano'];
   $tipo = $_POST['tipo'];
 

  // Query de ano lectivo usando prepared statement
$sql = "INSERT INTO trimestre (tipo, idano) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

// Executa a ddisciplina
$stmt->execute([$tipo, $idano]); // Passa ambos os valores em um único execute
  // Exibe um alerta após a ser adicionado uma disciplina
  echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/addtrimestre';</script>";
} catch (PDOException $e) {

  //echo "Erro na inserção: " . $e->getMessage();

  //  Exibe um alerta após aprentar o erro na insercao da  disciplina
  
  //echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/addtrimestre';</script>";
  echo "Erro na inserção: " . $e->getMessage();
}
