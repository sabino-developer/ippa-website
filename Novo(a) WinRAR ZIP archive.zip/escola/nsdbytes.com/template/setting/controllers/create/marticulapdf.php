<?php  
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit(); // Encerra o script se o arquivo não for encontrado
}

// Gera o PDF com os dados da última matrícula inserida
require_once('../tcpdf/tcpdf.php');

try {
    // Consulta para obter os dados inseridos
    $stmt = $conn->prepare("SELECT * FROM matricula ORDER BY id DESC LIMIT 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Cria um novo documento PDF
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Define o cabeçalho e o rodapé
    $pdf->SetHeaderData('', '', 'Gerando PDF com TCPDF', '');

    // Define o nome do documento
    $pdf->SetTitle('Dados de Matrícula');

    // Define o tipo de fonte e o tamanho
    $pdf->SetFont('helvetica', '', 12);

    // Adiciona uma nova página
    $pdf->AddPage();

    // Adiciona os dados ao PDF
    $html = '<h1>Dados de Matrícula</h1>';
    $html .= '<p>ID Ano: ' . $result['idano'] . '</p>';
    $html .= '<p>ID Inscrição: ' . $result['idInscr'] . '</p>';
    // Adicione os outros campos aqui...

    $pdf->writeHTML($html, true, false, true, false, '');

    // Saída do PDF (destino: navegador, nome do arquivo para salvar, modo de saída)
    $pdf->Output('matricula.pdf', 'D');

    // Redireciona após a geração do PDF
    header("Location: ../../views/estudante");
    exit(); // Encerra o script após redirecionar
} catch(PDOException $e) {
    // Exibe um alerta em caso de erro
    echo "<script>alert('Oops, Erro ao gerar PDF!');</script>";
    echo $e->getMessage(); // Exibe a mensagem de erro do PDO
}
?>
