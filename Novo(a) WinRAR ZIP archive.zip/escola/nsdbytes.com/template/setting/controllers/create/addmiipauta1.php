<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo connection.php existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    // Exibe uma mensagem de erro se o arquivo de conexão não for encontrado
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit(); // Encerra o script
}

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Verifica se todos os campos necessários foram enviados
    $campos = ['idano', 'iddisciplina', 'idfuncionario', 'idclasse', 'idtrimetre'];
    $campos_vazios = array_filter($campos, function($campo) {
        return empty($_POST[$campo]);
    });

    if (count($campos_vazios) === 0) {
        try {
            // Prepara a instrução de inserção
            $stmt = $conn->prepare("INSERT INTO addmiipauta (idano, iddisciplina, idfuncionario, idclasse, idtrimetre) VALUES (:idano, :iddisciplina, :idfuncionario, :idclasse, :idtrimetre)");

            // Vincula os parâmetros
            $stmt->bindParam(':idano', $_POST['idano']);
            $stmt->bindParam(':iddisciplina', $_POST['iddisciplina']);
            $stmt->bindParam(':idfuncionario', $_POST['idfuncionario']);
            $stmt->bindParam(':idclasse', $_POST['idclasse']);
            $stmt->bindParam(':idtrimetre', $_POST['idtrimetre']);

            // Executa a instrução de inserção
            $stmt->execute();

            // Exibe uma mensagem de sucesso
            echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/addmiipauta';</script>";
        } catch (PDOException $e) {
            // Exibe uma mensagem de erro em caso de falha na inserção
            echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/addmiipauta';</script>";
            echo "Erro na inserção: " . $e->getMessage();
        }
    } else {
        // Exibe uma mensagem de erro se algum campo estiver vazio
        echo "<script>alert('Todos os campos são obrigatórios!'); window.location.href = '../../views/addmiipauta';</script>";
    }
} else {
    // Redireciona para a página de inscrição se o formulário não foi submetido
    header("Location: ../../views/inscricao");
    exit();
}
?>
