<?php  
session_start();

// Verifica se o arquivo connection.php existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection.php não foi encontrado!</span>";
    exit; // Encerra a execução do script se o arquivo não for encontrado
}

try {
    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Captura os dados do formulário
    $idano = $_POST['idano'];
    $idmatri = $_POST['idmatri'];
    $mes = $_POST['mes'];

    // Verifica se o mês já está pago para o idmatri fornecido
    $sql_verificacao = "SELECT * FROM propinas WHERE idmatri = :idmatri AND mes = :mes";
    $stmt_verificacao = $conn->prepare($sql_verificacao);
    $stmt_verificacao->bindParam(':idmatri', $idmatri, PDO::PARAM_INT);
    $stmt_verificacao->bindParam(':mes', $mes, PDO::PARAM_STR);
    $stmt_verificacao->execute();

    if ($stmt_verificacao->rowCount() > 0) {
        // Exibe uma mensagem informando que o mês já está pago
        echo "<script>alert('Este mês já está pago para este  Estudante!'); window.location.href = '../../views/Pagtopropina';</script>";
        exit; // Encerra a execução do script
    }

    // Se o mês não estiver pago, continua com a inserção na tabela propinas

    // Captura os demais dados do formulário
    $valorUnita = $_POST['valorUnita'];
    $qtd = $_POST['qtd'];
    $valorpago = $_POST['valorpago'];
    $troco = $_POST['troco'];
    $total = $_POST['total'];
    $datapagemento = $_POST['datapagemento'];
    $metodoPag = $_POST['metodoPag'];

    // Query de inserção usando prepared statement
    $sql_insercao = "INSERT INTO propinas (idano, idmatri, valorUnita, qtd, valorpago, mes, total, troco, datapagemento, metodoPag) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_insercao = $conn->prepare($sql_insercao);

    // Executa a inserção
    $stmt_insercao->execute([$idano, $idmatri, $valorUnita, $qtd, $valorpago, $mes, $total, $troco, $datapagemento, $metodoPag]);

    // Exibe um alerta após a inserção
    echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/propina';</script>";
} catch (PDOException $e) {
    // Exibe um alerta em caso de erro
    echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/Pagtopropina';</script>";
}
