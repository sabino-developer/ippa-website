<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

  try {
    // Conexão com o banco de dados usando PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {  
      // Obtém os dados do formulário
        $idano = $_POST["idano"];
      $nturma = $_POST["nturma"];
      $sala = $_POST["sala"];
      $turno = $_POST["turno"];
      
      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO sala (idano,nturma,sala,turno)
                              VALUES (:idano, :nturma, :sala, :turno)");

      // Vincula os parâmetros

      $stmt->bindParam(':idano', $idano);
      $stmt->bindParam(':nturma', $nturma);
      $stmt->bindParam(':sala', $sala);
      $stmt->bindParam(':turno', $turno);


      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/turmaSala';</script>";

      //header("location: ../../views/turmaSala");
    }
  } catch(PDOException $e) {
      //echo "Erro ao inserir o registro: " . $e->getMessage();
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/turmaSala';</script>" . $e->getMessage();
  }

  // Fecha a conexão com o banco de dados
  $conn = null;
?>
