<?php

// Inicializa a sessão
session_start();

// Verifica se o arquivo connection.php existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {
    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        // Obtém os dados do formulário (supondo que eles foram enviados via POST)
        $idano = $_POST['idano'];
        $iddisciplina = $_POST['iddisciplina'];
        $idfuncionario = $_POST['idfuncionario']; 
        $idclasse = $_POST['idclasse'];
        $idtrimetre = $_POST['idtrimetre'];

        // Prepara a instrução de inserção
        $stmt = $conn->prepare("INSERT INTO addmiipauta (idano, iddisciplina, idfuncionario, idclasse, idtrimetre) 
                            VALUES (:idano, :iddisciplina, :idfuncionario, :idclasse, :idtrimetre)");

        // Vincula os parâmetros
        $stmt->bindParam(':idano', $idano);
        $stmt->bindParam(':iddisciplina', $iddisciplina);
        $stmt->bindParam(':idfuncionario', $idfuncionario);
        $stmt->bindParam(':idclasse', $idclasse);
        $stmt->bindParam(':idtrimetre', $idtrimetre);

        // Executa a instrução de inserção
        $stmt->execute();

        // Exibe um alerta após a inserção
        //  echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/inscricao';</script>";
        echo "Inserção realizada com sucesso!";
    } else {
        // Nenhum formulário foi submetido
    }
} catch (PDOException $e) {
    // Exibe um alerta em caso de erro e redireciona para a página de inscrição
    echo "Erro na inserção: " . $e->getMessage();
}

?>
