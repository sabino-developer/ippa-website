<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
    } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    }

try {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Obtém os dados do formulário
        $idFunc = $_POST["idFunc"];
        $username = $_POST["username"];

        // Prepara a instrução de inserção
        $stmt = $conn->prepare("INSERT INTO professores (idFunc) VALUES (:idFunc)");
        $stmt->bindParam(':idFunc', $idFunc);
        $stmt->execute();

        // Consulta na tabela funcionarios após a inserção bem-sucedida
        $selectStmt = $conn->prepare("SELECT *, codigo AS 'password' FROM funcionarios WHERE id = :idFunc");
        $selectStmt->bindParam(':idFunc', $idFunc);
        $selectStmt->execute();

        // Obter os resultados da consulta
        $funcionario = $selectStmt->fetch(PDO::FETCH_ASSOC);

        // Se o funcionário for encontrado
        if ($funcionario) {
            // Aqui você deve usar funções de hash para armazenar senhas de maneira segura
            $passwordHash = password_hash($funcionario['password'], PASSWORD_DEFAULT);

            $insertUserStmt = $conn->prepare("INSERT INTO users (idFuncionario, username, password) VALUES (:id, :username, :password)");
            $insertUserStmt->bindParam(':id', $funcionario['id']);
            $insertUserStmt->bindParam(':username', $username);
            $insertUserStmt->bindParam(':password', $passwordHash);
            $insertUserStmt->execute();

            // Atualiza o perfil do funcionário para 'prof' de Professor
            $updatePerfilStmt = $conn->prepare("UPDATE funcionarios SET perfil = 'prof' WHERE id = :idFunc");
            $updatePerfilStmt->bindParam(':idFunc', $idFunc);
            $updatePerfilStmt->execute();

            echo "Usuário inserido na tabela users com sucesso.<br>";
        } else {
            echo "Nenhum funcionário encontrado com o ID fornecido.";
        }

        // Exibe um alerta após a inserção
        echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/professores';</script>";
    }
} catch(PDOException $e) {
    // Trate os erros adequadamente, de preferência logando-os em um arquivo de log
    $errorMessage = "Erro ao realizar operação: " . $e->getMessage();
    echo "<script>alert('Oops! $errorMessage'); window.location.href = '../../views/professores';</script>";
}
?>