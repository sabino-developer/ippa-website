<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
}

try {
    // Função para gerar um número aleatório de 7 dígitos
    function generateRandomCode()
    {
        return rand(1000000, 9999999);
    }

    // Gera um novo código até encontrar um que não exista na tabela
    $codeExists = true;
    $generatedCode = 0;

    while ($codeExists) {
        $generatedCode = generateRandomCode();

        $queryCheckCode = "SELECT COUNT(*) as count FROM funcionarios WHERE codigo = ?";
        $stmtCheckCode = $conn->prepare($queryCheckCode);
        $stmtCheckCode->execute([$generatedCode]);
        $resultCheckCode = $stmtCheckCode->fetch(PDO::FETCH_ASSOC);

        $codeExists = ($resultCheckCode['count'] > 0);
    }

    // Obtém os dados do formulário
    $idano = $_POST["idano"];
    $idDep = $_POST["id"];
    $idFuncao = $_POST["idFuncao"];
    $nome = $_POST["nome"];
    $dataNasc = $_POST["dataNasc"];
    $genero = $_POST["genero"];
    $documento = $_POST["documento"];
    $endereco = $_POST["endereco"];
    $provincia = $_POST["provincia"];
    $telefone = $_POST["telefone"];
    $email = $_POST["email"];
    $avatar = ""; // Inicializa a variável avatar

    // Verifica se um arquivo de imagem foi enviado
    if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] === 0) {
        // Define o caminho de destino para o upload do arquivo
        $targetDir = "../uploads/";
        $fileName = $_FILES["avatar"]["name"];
        $targetFile = $targetDir . $fileName;

        // Move o arquivo temporário para o diretório de destino
        if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $targetFile)) {
            $avatar = $fileName; // Define o nome do arquivo como avatar
        } else {
            throw new Exception("Falha ao mover o arquivo para o diretório de destino.");
        }
    }

    // Prepara a instrução de inserção para funcionarios
    $query = "INSERT INTO funcionarios (idano, idDep, idFuncao, nome, dataNasc, genero, documento, endereco, provincia, telefone, email, avatar, codigo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->execute([$idano, $idDep, $idFuncao, $nome, $dataNasc, $genero, $documento, $endereco, $provincia, $telefone, $email, $avatar, $generatedCode]);

    // Obtém o último ID inserido
    $lastInsertId = $conn->lastInsertId();

    // Define o nome de usuário e senha
    $username = $_POST["username"];
    $password = password_hash($_POST["codigo"], PASSWORD_DEFAULT);
    $profile = $_POST["profile"];

    // Prepara a instrução de inserção para usuários
    $query2 = "INSERT INTO users (idFuncionario, username, password, profile) VALUES (?, ?, ?, ?)";
    $stmt2 = $conn->prepare($query2);
    $stmt2->execute([$lastInsertId, $username, $password, $profile]);

    // Exibe um alerta após a inserção
        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href = '../../views/funcionarios';</script>";
    }catch (Exception $e) {
    // Exibe uma mensagem de erro caso ocorra uma exceção
    echo "<script>alert('Oops! Erro ao cadastrar.'); window.location.href = '../../views/funcionarios';</script>";
}
?>