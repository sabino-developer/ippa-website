<?php

    // initialize the session
    session_start();

    if (file_exists('../config/connection.php')) {
        require_once "../config/connection.php";
     } else {
        echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
     }

try {

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Obtém os dados do formulário
      $idano = $_POST["idano"];
      $idCurso = $_POST["idCurso"];
      $comparticipacao = $_POST["comparticipacao"];
      $valorcomp = $_POST["valorcomp"];
      

      // Prepara a instrução de inserção
      $stmt = $conn->prepare("INSERT INTO valorcomparticipacao (idano,idCurso,comparticipacao, valorcomp) VALUES (:idano,:idCurso,:comparticipacao, :valorcomp)");

      // Vincula os parâmetros
      $stmt->bindParam(':idano', $idano);
      $stmt->bindParam(':idCurso', $idCurso);
      $stmt->bindParam(':comparticipacao', $comparticipacao); 
      $stmt->bindParam(':valorcomp', $valorcomp);
      

      // Executa a instrução de inserção
      $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/vcomparticipacao';</script>";
      
    }
  } catch(PDOException $e) {
    
      // Exibe um alerta após a inserção
      echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/vcomparticipacao';</script>";
      
  }
?>
