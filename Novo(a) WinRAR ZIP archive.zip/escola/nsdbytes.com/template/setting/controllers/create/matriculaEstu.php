<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit(); // Encerra o script se o arquivo não for encontrado
}

try {
    // Configura o PDO para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Obtém os dados do formulário
        $idano = $_POST['idano'];
        $idInscr = $_POST['idInscr'];
        $idCurso = $_POST['idCurso'];
        $idturma = $_POST['idturma'];
        $idClasse = $_POST['idClasse'];
        $metoPag = $_POST['metoPag'];
        $troco = $_POST['troco'];
        $codigo = $_POST['codigo'];
        $nomeEs = $_POST['nomeEs'];
        $classe = $_POST['classe'];
        $sala = $_POST['sala'];
        $nturma = $_POST['nturma'];
        $turno = $_POST['turno'];
        $taxaInscr = $_POST['taxaInscr'];
        $valorPago = $_POST['valorPago'];

        // Prepara a instrução de inserção
        $stmt = $conn->prepare("INSERT INTO matricula (idano, idInscr, idCurso,idturma, idClasse, metoPag, troco,codigo,nomeEs,classe,sala,nturma,turno,taxaInscr,valorPago) VALUES (:idano, :idInscr, :idCurso, :idturma, :idClasse, :metoPag, :troco, :codigo, :nomeEs, :classe, :sala, :nturma, :turno, :taxaInscr, :valorPago)");

        // Vincula os parâmetros
        $stmt->bindParam(':idano', $idano);
        $stmt->bindParam(':idInscr', $idInscr);
        $stmt->bindParam(':idCurso', $idCurso);
        $stmt->bindParam(':idturma', $idturma);
        $stmt->bindParam(':idClasse', $idClasse);
        $stmt->bindParam(':metoPag', $metoPag);
        $stmt->bindParam(':troco', $troco);
        $stmt->bindParam(':codigo', $codigo);
        $stmt->bindParam(':nomeEs', $nomeEs);
        $stmt->bindParam(':classe', $classe);
        $stmt->bindParam(':sala', $sala);
        $stmt->bindParam(':nturma', $nturma);
        $stmt->bindParam(':turno', $turno);
        $stmt->bindParam(':taxaInscr', $taxaInscr);
        $stmt->bindParam(':valorPago', $valorPago);

        // Executa a instrução de inserção
        $stmt->execute();

        // Exibe um alerta após a inserção
        echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/estudante';</script>";
        exit(); // Encerra o script após redirecionar
    }
} catch(PDOException $e) {
    // Exibe um alerta em caso de erro
    echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/matriculaEstu';</script>";
    echo $e->getMessage(); // Exibe a mensagem de erro do PDO
    exit(); // Encerra o script após exibir a mensagem de erro
}

