<?php

// Inicializa a sessão idano
session_start();

// Verifica se o arquivo connection.php existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo connection não foi encontrado!</span>";
    exit; // Encerra o script se o arquivo não for encontrado
}

// Verifica se o método de requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Conecta-se ao banco de dados (substitua 'localhost', 'nome_usuario', 'senha_usuario' e 'nome_banco_dados' pelos valores corretos)
        $conexao = new PDO("mysql:host=localhost;dbname=cbungadb", "root", "");

        // Define o modo de erro do PDO para exceção
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepara uma instrução de inserção SQL
        $sql = "INSERT INTO pagamentodeclara (idmatri, codigo, nomeEs, Curso, metodoPag, tipodeclaraco, datapagemento, valordeclaracao, valorpago, troco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Prepara a declaração
        $stmt = $conexao->prepare($sql);

        // Define os parâmetros e executa a declaração
        $stmt->execute([
            $_POST['idmatri'] ?? '',
            $_POST['codigo'] ?? '',
            $_POST['nomeEs'] ?? '',
            $_POST['Curso'] ?? '', // Aqui deve ser substituído pelo campo correto que corresponde à chave estrangeira
            $_POST['metodoPag'] ?? '',
            $_POST['tipodeclaraco'] ?? '',
            $_POST['datapagemento'] ?? '',
            $_POST['valordeclaracao'] ?? '', // Corrigido o nome do campo
            $_POST['valorpago'] ?? '',
            $_POST['troco'] ?? ''
        ]);

        echo "Registro inserido com sucesso.";
    } catch (PDOException $e) {
        echo "ERRO: " . $e->getMessage();
    }
} else {
    echo "ERRO: Método de requisição inválido.";
}

?>
