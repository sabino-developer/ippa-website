<?php
// Inclui o arquivo de conexão com o banco de dados
require_once "../config/connection.php";

// Verifica se o formulário foi enviado via método POST de forma segura
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se todos os campos necessários foram recebidos de forma segura
    if (isset($_POST['idano'], $_POST['idclasse'], $_POST['idFuncionario'])) {
        // Verifica se a conexão com o banco de dados está disponível
        if ($conn) {
            try {
                // Prepara a instrução SQL de inserção com parâmetros nomeados
                $sql = "INSERT INTO disciplinasprofpri (idano, idclasse, idFuncionario) VALUES (:idano, :idclasse, :idFuncionario)";
                $stmt = $conn->prepare($sql);

                // Bind dos parâmetros para evitar injeção de SQL
                $stmt->bindParam(':idano', $_POST['idano']);
                $stmt->bindParam(':idclasse', $_POST['idclasse']);
                $stmt->bindParam(':idFuncionario', $_POST['idFuncionario']);

                // Executa a inserção com os valores seguros
                $stmt->execute();

                // Redireciona de volta para a página do formulário com um parâmetro de sucesso
                echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/atridisciplinapri';</script>";
            } catch (PDOException $e) {
                // Exibe um alerta se ocorrer um erro durante a inserção
                echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/atridisciplinapri';</script>";
                // Poderia também logar o erro para uma análise futura
            }
        } else {
            // Exibe um alerta se a conexão com o banco de dados não estiver disponível
            echo "<script>alert('Oops, Erro ao conectar ao banco de dados!'); window.location.href = '../../views/atridisciplinapri';</script>";
        }
    } else {
        // Exibe um alerta se os campos do formulário não foram enviados ou estão vazios
        echo "<script>alert('Oops, campos obrigatórios não preenchidos!'); window.location.href = '../../views/atridisciplinapri';</script>";
    }
}
?>
