<?php
require_once '../../config/connection.php';

header('Content-Type: application/json');

try {
    // Verifica se todos os parâmetros necessários foram recebidos
    if (!isset($_POST['curso_id'], $_POST['turno'], $_POST['acao'])) {
        throw new Exception('Parâmetros insuficientes');
    }

    $cursoId = (int)$_POST['curso_id'];
    $turno = trim($_POST['turno']);
    $acao = $_POST['acao'];

    // Valida os dados de entrada
    if ($cursoId <= 0 || empty($turno) || $acao !== 'salas_disponiveis') {
        throw new Exception('Dados inválidos');
    }

    // Consulta para salas disponíveis no turno selecionado que não estão ocupadas para o curso
    $query = "SELECT s.id, s.sala, s.nturma, s.capacidade
              FROM sala s
              LEFT JOIN classe c ON s.id = c.idsala AND c.idcurso = :curso_id
              WHERE s.turno = :turno AND (c.id IS NULL OR c.idcurso = :curso_id)
              ORDER BY s.sala";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(':curso_id', $cursoId, PDO::PARAM_INT);
    $stmt->bindParam(':turno', $turno, PDO::PARAM_STR);
    $stmt->execute();

    $salas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($salas)) {
        throw new Exception('Nenhuma sala disponível para o turno selecionado');
    }

    // Retorna os dados em formato JSON
    echo json_encode([
        'status' => 'success',
        'data' => $salas
    ]);

} catch (Exception $e) {
    // Retorna mensagem de erro em formato JSON
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}