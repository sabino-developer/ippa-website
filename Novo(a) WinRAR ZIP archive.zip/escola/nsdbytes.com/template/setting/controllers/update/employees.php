<?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recebe os dados do formulário
    $employeeId = $_POST["id"];
    $fullname = $_POST["fullname"];
    $idFuncao = $_POST["idFuncao"];
    $document = $_POST["document"];
    $residence = $_POST["residence"];
    $neighborhood = $_POST["neighborhood"];
    $province = $_POST["province"];
    $birth = $_POST["birth"];
    $gender = $_POST["gender"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $status = $_POST["status"];
    $avatar = $_FILES["avatar"];

    

    // Diretório onde os arquivos serão armazenados
    $uploadDir = "../uploads";

    // Caminho completo do arquivo de avatar
    $avatarPath = $uploadDir . "/" . basename($avatar["avatar"]);

    // Move o arquivo de avatar para o diretório de destino
    if (move_uploaded_file($avatar["tmp_name"], $avatarPath)) {
        echo "Avatar enviado com sucesso.";

        // Exemplo de conexão com o banco de dados
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sgeDB";

        // Crie a conexão
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verifique se a conexão foi estabelecida com sucesso
        if ($conn->connect_error) {
            die("Erro na conexão com o banco de dados: " . $conn->connect_error);
        }

        // Construa a consulta de atualização
        $sql = "UPDATE employees SET idFuncao='$idFuncao', fullname='$fullname', document='$document', residence='$residence', neighborhood='$neighborhood', province='$province', birth='$birth', gender='$gender', email='$email', phone='$phone', avatar='$avatarPath', status='$status' WHERE id = $employeeId";

        // Execute a consulta
        if ($conn->query($sql) === TRUE) {
            echo "Registro atualizado com sucesso!";
        } else {
            echo "Erro ao atualizar o registro: " . $conn->error;
        }

        // Feche a conexão com o banco de dados
        $conn->close();
    } else {
        echo "Erro ao enviar o avatar.";
    }
}
?>
