<?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recebe os dados do formulário
    $id = $_POST["id"];
    $ndisciplina = $_POST["ndisciplina"];
    $status = $_POST["status"];

        // Exemplo de conexão com o banco de dados
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sgeDB";

        // Crie a conexão
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verifique se a conexão foi estabelecida com sucesso
        if ($conn->connect_error) {
            die("Erro na conexão com o banco de dados: " . $conn->connect_error);
        }

        // Construa a consulta de atualização
        $sql = "UPDATE disciplina SET ndisciplina='$ndisciplina', status='$status' WHERE id = $id";

        // Execute a consulta
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Alterado com sucesso!'); window.location.href = '../../views/Disciplina';</script>";
        } else {
            echo "<script>alert('Erro ao Alterar o registro:!'); window.location.href = '../../views/Disciplina';</script>". $conn->error;   
        }

        // Feche a conexão com o banco de dados
        $conn->close();
    } else {
        echo "Erro ao enviar o avatar.";
    }

?>
