<?php
  session_start();
  require_once "../config/connection.php";

  $id = $_POST['id'];
  $username = $_POST['username'];
  $profile = $_POST['profile'];
  $status = $_POST['status'];

  $stmt = $conn->prepare("UPDATE users SET username = :username, profile = :profile, status = :status WHERE id = :id");
  $stmt->bindParam(':id', $id, PDO::PARAM_INT);
  $stmt->bindParam(':username', $username, PDO::PARAM_STR);
  $stmt->bindParam(':profile', $profile, PDO::PARAM_STR);
  $stmt->bindParam(':status', $status, PDO::PARAM_STR);
  $stmt->execute();

      // Exibe um alerta após a inserção
      echo "<script>alert('Alterado com sucesso!'); window.location.href = '../../views/users';</script>";
  exit();
?>