<?php
// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    // Inclui o arquivo de conexão
    require_once "../config/connection.php";
} else {
    // Exibe uma mensagem de erro se o arquivo de conexão não for encontrado
    echo "<span class='text-danger'>O arquivo de conexão não foi encontrado!</span>";
    exit; // Encerra o script
}

// Verifica se o método da requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se os dados foram enviados via POST
    if (isset($_POST["anoInicio"]) && isset($_POST["anoTermino"])) {
        // Obtém os valores enviados via POST
        $anoInicio = $_POST["anoInicio"];
        $anoTermino = $_POST["anoTermino"];

        // Validação adicional dos dados (se necessário)
        // ...

        try {
            // Inicia uma transação
            $conn->beginTransaction();

            // Prepara a consulta SQL para atualizar os dados na tabela "ano"
            $sql = "UPDATE ano SET anoInicio = :anoInicio, anoTermino = :anoTermino WHERE estado = 'Ativo'";
            $stmt = $conn->prepare($sql);

            // Associa os valores aos parâmetros da consulta preparada
            $stmt->bindParam(':anoInicio', $anoInicio);
            $stmt->bindParam(':anoTermino', $anoTermino);

            // Executa a consulta
            $stmt->execute();

            // Confirma a transação
            $conn->commit();

            // Exibe um alerta de sucesso e redireciona após a operação bem-sucedida
            echo "<script>alert('Operação realizada com sucesso!'); window.location.href = '../../views/anolectivo';</script>";
            exit;
        } catch (PDOException $e) {
            // Se ocorrer um erro de PDO, exibe um alerta de erro e reverte a transação
            $conn->rollBack();
            echo "<script>alert('Oops, Erro ao realizar operação!'); window.location.href = '../../views/anolectivo';</script>";
            exit;
        }

        // Fecha a conexão com o banco de dados
        $conn = null;
    } else {
        // Se os dados não foram recebidos via POST, exibe uma mensagem de erro
        echo "Dados não recebidos.";
    }
} else {
    // Se o método da requisição não for POST, redireciona para alguma página de erro
    header("location: erro.php");
    exit;
}
?>
