<?php
// Este script deve ser chamado via AJAX para retornar as turmas e os turnos associados a uma classe

// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo de conexão não foi encontrado!</span>";
    exit; // Encerra o script caso o arquivo de conexão não seja encontrado
}



// Verifica se o parâmetro id foi passado na URL
if (isset($_GET['id'])) {
    $classeId = $_GET['id'];

    // Consulta SQL para buscar as turmas associadas à classe selecionada
    $stmtTurmas = $conn->prepare("SELECT * FROM turmas WHERE id = :id");
    $stmtTurmas->bindParam(':id', $classeId);
    $stmtTurmas->execute();

    // Array para armazenar as turmas
    $turmas = array();

    // Itera sobre os resultados e adiciona ao array de turmas
    while ($row = $stmtTurmas->fetch(PDO::FETCH_ASSOC)) {
        $turmas[] = array(
            'id' => $row['id'],
            'nome' => $row['nome']
        );
    }

    // Consulta SQL para buscar os turnos associados à classe selecionada
    $stmtTurnos = $conn->prepare("SELECT * FROM turnos WHERE id = :id");
    $stmtTurnos->bindParam(':id', $classeId);
    $stmtTurnos->execute();

    // Array para armazenar os turnos
    $turnos = array();

    // Itera sobre os resultados e adiciona ao array de turnos
    while ($row = $stmtTurnos->fetch(PDO::FETCH_ASSOC)) {
        $turnos[] = array(
            'id' => $row['id'],
            'nome' => $row['nome']
        );
    }

    // Retorna as turmas e os turnos como JSON
    echo json_encode(array('turmas' => $turmas, 'turnos' => $turnos));
} else {
    // Se não houver parâmetro id, retorna um JSON vazio
    echo json_encode(array());
}
?>
