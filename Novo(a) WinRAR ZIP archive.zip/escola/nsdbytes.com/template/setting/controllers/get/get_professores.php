<?php
// Este script deve ser chamado via AJAX para retornar os funcionários associados a uma disciplina

// Inicializa a sessão
session_start();

// Verifica se o arquivo de conexão existe e o inclui
if (file_exists('../config/connection.php')) {
    require_once "../config/connection.php";
} else {
    echo "<span class='text-danger'>O arquivo de conexão não foi encontrado!</span>";
    exit; // Encerra o script caso o arquivo de conexão não seja encontrado
}

// Verifica se o parâmetro 'id' foi passado na URL
if (isset($_GET['id'])) {
    // Obtém o ID da disciplina a partir do parâmetro 'id'
    $disciplinaId = $_GET['id'];

    try {
        // Consulta SQL para buscar os funcionários que lecionam a disciplina selecionada
        $query = "SELECT funcao.nome, funcionarios.id FROM funcionarios INNER JOIN funcao ON funcionarios.idFuncao = funcao.id WHERE id = :id AND funcao.nome = 'professor'";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $disciplinaId);
        $stmt->execute();

        // Array para armazenar os resultados
        $funcionarios = array();

        // Itera sobre os resultados e adiciona ao array de funcionários
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $funcionarios[] = array(
                'id' => $row['id'],
                'nome' => $row['nome']
            );
        }

        // Retorna os funcionários como JSON
        echo json_encode($funcionarios);
    } catch (PDOException $e) {
        // Em caso de erro, exibe uma mensagem amigável
        echo "Erro na consulta: " . $e->getMessage();
    }
} else {
    // Se não houver parâmetro 'id', retorna um JSON vazio
    echo json_encode(array());
}
?>
