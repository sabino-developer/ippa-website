<?php
    // Configuração do banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sgeDB";

        try {
            // Conexão com o banco de dados usando PDO
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if (isset($_GET["id"])) {
            $idsala = $_GET["id"];

          // Prepara a instrução de inserção
          $stmt = $conn->prepare("DELETE FROM sala WHERE id = $idsala");

          // Vincula os parâmetros
          $stmt->bindParam(':idsala', $idsala);

          // Executa a instrução de inserção
          $stmt->execute();

          // Exibe um alerta após a inserção
          echo "<script>alert('Sala Eliminado com sucesso!'); window.location.href = '../../views/sala';</script>";

          //header("location: ../../views/sala");
        }} catch(PDOException $e) {
            //echo "Erro ao inserir o registro: " . $e->getMessage();
            // Exibe um alerta após a inserção
            echo "<script>alert('Oops! Erro ao eliminar Sala.'); window.location.href = '../../views/sala';</script>" . $e->getMessage();
        }

        // Fecha a conexão com o banco de dados
        $conn = null;
?>
