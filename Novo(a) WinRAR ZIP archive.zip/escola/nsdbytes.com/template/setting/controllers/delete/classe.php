<?php
    // Configuração do banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sgeDB";

        try {
            // Conexão com o banco de dados usando PDO
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if (isset($_GET["id"])) {
            $idclasse = $_GET["id"];

          // Prepara a instrução de inserção
          $stmt = $conn->prepare("DELETE FROM classe WHERE id = $idclasse");

          // Vincula os parâmetros
          $stmt->bindParam(':idclasse', $idclasse);

          // Executa a instrução de inserção
          $stmt->execute();

          // Exibe um alerta após a inserção
          echo "<script>alert('classe Eliminado com sucesso!'); window.location.href = '../../views/classe';</script>";

          //header("location: ../../views/classe");
        }} catch(PDOException $e) {
            //echo "Erro ao inserir o registro: " . $e->getMessage();
            // Exibe um alerta após a inserção
            echo "<script>alert('Oops! Erro ao eliminar classe.'); window.location.href = '../../views/classe';</script>" . $e->getMessage();
        }

        // Fecha a conexão com o banco de dados
        $conn = null;
?>
