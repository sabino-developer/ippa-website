<?php
    // Configuração do banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sgeDB";

        try {
            // Conexão com o banco de dados usando PDO
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if (isset($_GET["id"])) {
            $usersId = $_GET["id"];

          // Prepara a instrução de inserção
          $stmt = $conn->prepare("DELETE FROM users WHERE id = $usersId");

          // Vincula os parâmetros
          $stmt->bindParam(':usersId', $usersId);

          // Executa a instrução de inserção
          $stmt->execute();

          // Exibe um alerta após a inserção
          echo "<script>alert('Usuario elimindado  com sucesso!'); window.location.href = '../../views/users';</script>";

          //header("location: ../../views/employees");
        }} catch(PDOException $e) {
            //echo "Erro ao inserir o registro: " . $e->getMessage();
            // Exibe um alerta após a inserção
            echo "<script>alert('Oops! Erro ao eliminar funcionário.'); window.location.href = '../../views/employees';</script>" . $e->getMessage();
        }

        // Fecha a conexão com o banco de dados
        $conn = null;
?>
