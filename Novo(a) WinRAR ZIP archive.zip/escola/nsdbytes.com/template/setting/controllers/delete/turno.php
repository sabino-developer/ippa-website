<?php
    // Configuração do banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sgeDB";

        try {
            // Conexão com o banco de dados usando PDO
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if (isset($_GET["id"])) {
            $idturno = $_GET["id"];

          // Prepara a instrução de inserção
          $stmt = $conn->prepare("DELETE FROM turno WHERE id = $idturno");

          // Vincula os parâmetros
          $stmt->bindParam(':idturno', $idturno);

          // Executa a instrução de inserção
          $stmt->execute();

          // Exibe um alerta após a inserção
          echo "<script>alert('Turno Eliminado com sucesso!'); window.location.href = '../../views/turno';</script>";

          //header("location: ../../views/turno");
        }} catch(PDOException $e) {
            //echo "Erro ao inserir o registro: " . $e->getMessage();
            // Exibe um alerta após a inserção
            echo "<script>alert('Oops! Erro ao eliminar turno.'); window.location.href = '../../views/turno';</script>" . $e->getMessage();
        }

        // Fecha a conexão com o banco de dados
        $conn = null;
?>
