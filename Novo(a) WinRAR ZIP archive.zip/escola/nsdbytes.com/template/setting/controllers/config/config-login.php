<?php
session_start();
$pagename = "login";

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: dashboardscretaria.php");
    exit;
}

require_once "../controllers/config/connection.php";

$username = $password = "";
$username_err = $password_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST") {
    if(empty(trim($_POST["username"]))) {
        $username_err = '<p class="text-danger">Por favor, insira o nome de usuário.</p>';
    } else {
        $username = trim($_POST["username"]);
    }
    
    if(empty(trim($_POST["password"]))) {
        $password_err = '<p class="text-danger">Por favor, insira sua senha.</p>';
    }else {
        $password = trim($_POST["password"]);
    }
    
    if(empty($username_err) && empty($password_err)) {
        $sql = "SELECT id, username, password, profile FROM users WHERE username = :username AND status = 'on'";
        
        if($stmt = $conn->prepare($sql)) {
            $stmt->bindValue(":username", $username, PDO::PARAM_STR);
            
            if($stmt->execute()) {
                if($stmt->rowCount() == 1) {                    
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $id = $row['id'];
                    $hashed_password = $row['password'];
                    $profile = $row['profile'];
                    
                    if(password_verify($password, $hashed_password)) {
                        session_start();
                        $_SESSION["loggedin"] = true;
                        $_SESSION["id"] = $id;
                        $_SESSION["username"] = $username;
                        $_SESSION["profile"] = $profile;

                        switch($profile) {
                            case "Diretor Geral":
                                header("location: dashboard.php");
                                break;
                            case "secretaria":
                                header("location: dashboardscretaria.php");
                                break;
                            case "Professor":
                                header("location: dashboardprofesor.php");
                                break;
                            case "Estudante":
                                header("location: dashboardestudante.php");
                                break;
                            default:
                                header("location: login.php");
                        }
                    } else {
                        $password_err = '<p class="text-danger">Senha inválida.</p>';
                    }
                } else {
                    $username_err = '<p class="text-danger">Usuário inválido.</p>';
                }
            } else {
                $error_msg = '<p class="text-danger">Ops! Algo deu errado. Por favor, tente novamente mais tarde.</p>';
            }
        }
        
        unset($stmt);
    }
    
    unset($conn);
}
?>
