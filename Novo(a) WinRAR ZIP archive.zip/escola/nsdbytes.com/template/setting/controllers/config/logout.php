<?php
	session_start();

	// Remove todas as variáveis de sessão
	session_unset();

	// Destrói a sessão
	session_destroy();

	// Redireciona para a página de login
	//$sql ="UPDATE acesso SET logout = NOW() WHERE users='$id' ORDER BY acesso.id DESC LIMIT 1";
    //  $stmt_insert = $conn->prepare($sql);

        // destroy the session.
        session_destroy();
        // redirect to login page
	header('Location: ../../views/login');
	exit;
?>