-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 20-Abr-2025 às 13:42
-- Versão do servidor: 8.0.31
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdescola`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ano`
--

DROP TABLE IF EXISTS `ano`;
CREATE TABLE IF NOT EXISTS `ano` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anoInicio` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `anoTermino` varchar(200) NOT NULL,
  `estado` enum('Ativo','Inativo') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Ativo',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `ano`
--

INSERT INTO `ano` (`id`, `anoInicio`, `anoTermino`, `estado`, `data`) VALUES
(1, '2024', '2025', 'Ativo', '2025-03-25 20:48:57');

-- --------------------------------------------------------

--
-- Estrutura da tabela `app`
--

DROP TABLE IF EXISTS `app`;
CREATE TABLE IF NOT EXISTS `app` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `endereco` varchar(200) NOT NULL,
  `telefone` int NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `app`
--

INSERT INTO `app` (`id`, `nome`, `endereco`, `telefone`, `email`) VALUES
(1, 'ANHERC-IPPA', 'Cacuaco', 923778131, 'Anherc@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `classe`
--

DROP TABLE IF EXISTS `classe`;
CREATE TABLE IF NOT EXISTS `classe` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idcurso` int NOT NULL,
  `idsala` int NOT NULL,
  `nclasse` varchar(200) NOT NULL,
  `nvagas` int NOT NULL,
  `nestudante` int NOT NULL,
  `estadoclasse` enum('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  `idano` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idano` (`idano`),
  KEY `idcurso` (`idcurso`),
  KEY `idsala` (`idsala`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `classe`
--

INSERT INTO `classe` (`id`, `idcurso`, `idsala`, `nclasse`, `nvagas`, `nestudante`, `estadoclasse`, `idano`) VALUES
(7, 1, 1, '10 classe', 45, 0, 'Ativo', 1);

--
-- Acionadores `classe`
--
DROP TRIGGER IF EXISTS `AtualizacaoEstSala`;
DELIMITER $$
CREATE TRIGGER `AtualizacaoEstSala` AFTER INSERT ON `classe` FOR EACH ROW UPDATE sala set estado ='Inativo'
WHERE sala.id=new.idsala
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `confirmacao`
--

DROP TABLE IF EXISTS `confirmacao`;
CREATE TABLE IF NOT EXISTS `confirmacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `idmatri` int NOT NULL,
  `estado` enum('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

DROP TABLE IF EXISTS `curso`;
CREATE TABLE IF NOT EXISTS `curso` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `nome` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `idFunc` int NOT NULL,
  `vagas` int NOT NULL,
  `status` enum('on','off') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'on',
  `estado` enum('Ativo','Inativo') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Ativo',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idano` (`idano`),
  KEY `idFunc` (`idFunc`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`id`, `idano`, `nome`, `idFunc`, `vagas`, `status`, `estado`, `data`) VALUES
(1, 1, 'Informatica', 1, 800, 'on', 'Ativo', '2025-03-25 22:07:18'),
(2, 1, 'Contablidade', 1, 500, 'on', 'Ativo', '2025-03-25 22:59:44'),
(3, 1, 'Gestão de recursos humanos ', 1, 200, 'on', 'Ativo', '2025-03-28 10:35:34'),
(4, 1, 'GSI', 1, 30, 'on', 'Ativo', '2025-03-28 14:00:31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

DROP TABLE IF EXISTS `disciplina`;
CREATE TABLE IF NOT EXISTS `disciplina` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ndisciplina` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `estado` enum('on','off') NOT NULL DEFAULT 'on',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `disciplina`
--

INSERT INTO `disciplina` (`id`, `ndisciplina`, `estado`, `data`) VALUES
(1, 'Língua Portuguesa ', 'on', '2025-03-26 00:35:38'),
(2, 'Linguagem de Programação ', 'on', '2025-03-26 00:39:10'),
(3, 'Ed.Fisica', 'on', '2025-04-20 13:04:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcao`
--

DROP TABLE IF EXISTS `funcao`;
CREATE TABLE IF NOT EXISTS `funcao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `status` enum('on','off') NOT NULL DEFAULT 'on',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `funcao`
--

INSERT INTO `funcao` (`id`, `nome`, `status`, `data`) VALUES
(1, 'Professor', 'on', '2025-03-25 22:57:27');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
CREATE TABLE IF NOT EXISTS `funcionarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idFuncao` int NOT NULL,
  `nome` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `genero` enum('Maculino','Femenino') NOT NULL DEFAULT 'Maculino',
  `estado` enum('usuario','Inativo') NOT NULL DEFAULT 'usuario',
  PRIMARY KEY (`id`),
  KEY `idFuncao` (`idFuncao`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`id`, `idFuncao`, `nome`, `genero`, `estado`) VALUES
(1, 1, 'Dionisio.Travasso', 'Maculino', 'usuario');

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscricao`
--

DROP TABLE IF EXISTS `inscricao`;
CREATE TABLE IF NOT EXISTS `inscricao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `codigo` int NOT NULL,
  `nome` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `genero` enum('Masculino','Feminino') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Masculino',
  `dataNasc` date NOT NULL,
  `documento` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `telefone` int DEFAULT NULL,
  `email` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `idClasse` int DEFAULT NULL,
  `idCurso` int DEFAULT NULL,
  `nomePai` varchar(100) DEFAULT NULL,
  `nomeMae` varchar(100) DEFAULT NULL,
  `nomeResp` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telResp` int DEFAULT NULL,
  `emailResp` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `metodoPag` enum('Dinheiro','Transferência') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Dinheiro',
  `taxaInscr` int NOT NULL,
  `valorPago` int NOT NULL,
  `troco As (valorPago -taxaInscr)` decimal(10,0) NOT NULL,
  `status` enum('on','off') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'on',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`codigo`),
  KEY `idClasse` (`idClasse`),
  KEY `idCurso` (`idCurso`),
  KEY `idano` (`idano`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `inscricao`
--

INSERT INTO `inscricao` (`id`, `idano`, `codigo`, `nome`, `genero`, `dataNasc`, `documento`, `telefone`, `email`, `idClasse`, `idCurso`, `nomePai`, `nomeMae`, `nomeResp`, `telResp`, `emailResp`, `metodoPag`, `taxaInscr`, `valorPago`, `troco As (valorPago -taxaInscr)`, `status`, `created`) VALUES
(2, 1, 3456787, 'QQQQ', 'Masculino', '2000-04-30', 'SFGSA', 11233, 'MANSN12@GMAIL.COM', 7, 1, 'WEQW', 'QEE', 'QEE', 2332, 'MANSN12@GMAIL.COM', 'Dinheiro', 2000, 2000, '0', 'on', '2025-04-19 09:02:07'),
(3, 1, 1834998, 'Formosa Travasso ', 'Feminino', '0000-00-00', '004350LA312', 1234567, 'andre.jose@gmail.com', 7, 1, 'Frazão Travassos', 'Celda Bunga ', 'Helder Travassos', 344455, 'heldertravassos@gmail.com', 'Transferência', 2000, 3000, '0', 'on', '2025-04-20 09:08:43'),
(4, 1, 6865441, 'Martinho Da Vila ', 'Masculino', '0000-00-00', '004350LA312', 935929565, 'inosgamers@gmail.com', 7, 1, 'Agusto Neto ', 'Amelia da Silva', 'Pedro', 935929565, 'heldertravassos@gmail.com', 'Transferência', 2000, 5000, '0', 'on', '2025-04-20 09:42:08'),
(5, 1, 3661791, 'Margarida Cololo', 'Feminino', '0000-00-00', '064350LA34', 1234567, 'nkkk@gmao.com', 7, 1, 'Mario Pedro', 'Margarida Matunta ', 'Pedro', 0, 'dio@gmail.com', 'Dinheiro', 2000, 10000, '0', 'on', '2025-04-20 09:46:27'),
(6, 1, 3227912, 'Marcelina Monteiro ', 'Feminino', '0000-00-00', '45gfdswe2', 1234567, 'inosgamers@gmail.com', 7, 1, 'Mario Pedro', 'Luísa Matamba', 'Pedro', 2332, 'dio@gmail.com', 'Dinheiro', 2000, 2000, '0', 'on', '2025-04-20 09:50:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `matricula`
--

DROP TABLE IF EXISTS `matricula`;
CREATE TABLE IF NOT EXISTS `matricula` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idInscr` int NOT NULL,
  `idClasse` int NOT NULL,
  `idCurso` int NOT NULL,
  `idano` int NOT NULL,
  `idturma` int NOT NULL,
  `dataMatr` date NOT NULL,
  `status` enum('on','off') NOT NULL DEFAULT 'on',
  `metoPag` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dataPag` date NOT NULL,
  `idpaga` int DEFAULT NULL,
  `codigo` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `estado` set('Estudante','Inativo') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'Estudante',
  `troco` decimal(10,0) DEFAULT '0',
  `nomeEs` varchar(100) DEFAULT NULL,
  `curso` varchar(100) DEFAULT NULL,
  `classe` varchar(100) DEFAULT NULL,
  `sala` varchar(100) DEFAULT NULL,
  `nturma` varchar(100) DEFAULT NULL,
  `turno` varchar(100) DEFAULT NULL,
  `taxaInscr` varchar(100) NOT NULL,
  `valorPago` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idInscr` (`idInscr`),
  KEY `idClasse` (`idClasse`),
  KEY `idCurso` (`idCurso`),
  KEY `idano` (`idano`),
  KEY `idpaga` (`idpaga`),
  KEY `idturma` (`idturma`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `minipauta`
--

DROP TABLE IF EXISTS `minipauta`;
CREATE TABLE IF NOT EXISTS `minipauta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idprofessor` int NOT NULL,
  `idclasse` int NOT NULL,
  `idtrimestre` int NOT NULL,
  `iddisciplina` int NOT NULL,
  `mac` float NOT NULL,
  `pp` float NOT NULL,
  `pt` float NOT NULL,
  `media` float NOT NULL,
  `estadoEst` enum('on','off') NOT NULL DEFAULT 'on',
  `estadoPauta` enum('on','off') NOT NULL DEFAULT 'on',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idclasse` (`idclasse`),
  KEY `idprofessor` (`idprofessor`),
  KEY `iddisciplina` (`iddisciplina`),
  KEY `idtrimestre` (`idtrimestre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

DROP TABLE IF EXISTS `pagamento`;
CREATE TABLE IF NOT EXISTS `pagamento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `taxaInscr` decimal(10,0) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` set('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  PRIMARY KEY (`id`),
  KEY `idano` (`idano`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor`
--

DROP TABLE IF EXISTS `professor`;
CREATE TABLE IF NOT EXISTS `professor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `bi` varchar(200) NOT NULL,
  `genero` varchar(100) NOT NULL,
  `datanasc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `grau` varchar(100) NOT NULL,
  `datainscr` date NOT NULL,
  `estada` enum('Ativo','Inativo') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Ativo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bi` (`bi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sala`
--

DROP TABLE IF EXISTS `sala`;
CREATE TABLE IF NOT EXISTS `sala` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `nturma` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sala` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `estado` set('Ativo','Inativo') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Ativo',
  `turno` varchar(200) NOT NULL,
  `datacriacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idano` (`idano`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `sala`
--

INSERT INTO `sala` (`id`, `idano`, `nturma`, `sala`, `estado`, `turno`, `datacriacao`) VALUES
(1, 1, 'M01', 'Sala 1', 'Inativo', 'Manhã', '2025-03-25 21:46:37'),
(2, 1, 'M02', 'Sala 2', 'Ativo', 'Manhã', '2025-03-25 21:52:27'),
(3, 1, 'T01', 'Sala 1', 'Ativo', 'Tarde', '2025-03-25 21:53:45'),
(4, 1, 'T02', 'Sala 2', 'Ativo', 'Tarde', '2025-04-20 09:00:04');

-- --------------------------------------------------------

--
-- Estrutura da tabela `trimestre`
--

DROP TABLE IF EXISTS `trimestre`;
CREATE TABLE IF NOT EXISTS `trimestre` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` varchar(200) NOT NULL,
  `tipo` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `estado` enum('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `trimestre`
--

INSERT INTO `trimestre` (`id`, `idano`, `tipo`, `estado`, `data`) VALUES
(1, '1', 'I º Trimestre', 'Ativo', '2025-03-26 00:45:37');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idFuncionario` int NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `profile` enum('Administrador','Diretor Geral','Diretor Pedagogico','Secretaria','Professor','Estudante','Encaregado') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'Administrador',
  `status` enum('on','off') NOT NULL DEFAULT 'on',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `idFuncionario`, `username`, `password`, `profile`, `status`, `data`) VALUES
(1, 1, 'Israel.Pedro', '$2y$10$3ydd3Iy7mokSafiRXMZLQe22YralElOVqX1kd71Ec5Gp5VAj8jviu', 'Diretor Geral', 'on', '2025-03-25 19:59:23'),
(2, 2, 'Leonel.Pedro', '$2y$10$3ydd3Iy7mokSafiRXMZLQe22YralElOVqX1kd71Ec5Gp5VAj8jviu', 'Professor', 'on', '2025-04-17 16:50:48'),
(3, 3, 'Isaral.willem', '$2y$10$3ydd3Iy7mokSafiRXMZLQe22YralElOVqX1kd71Ec5Gp5VAj8jviu', 'Secretaria', 'on', '2025-04-17 16:50:48');

-- --------------------------------------------------------

--
-- Estrutura da tabela `vinsmat`
--

DROP TABLE IF EXISTS `vinsmat`;
CREATE TABLE IF NOT EXISTS `vinsmat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idano` int NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `taxaInscr` decimal(10,0) NOT NULL,
  `estado` set('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Extraindo dados da tabela `vinsmat`
--

INSERT INTO `vinsmat` (`id`, `idano`, `tipo`, `taxaInscr`, `estado`, `data`) VALUES
(1, 1, 'Matricula', '2000', 'Ativo', '2024-03-08 07:46:23'),
(2, 1, 'Confirmação', '3000', 'Ativo', '2024-03-08 07:46:54');

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `classe`
--
ALTER TABLE `classe`
  ADD CONSTRAINT `classe_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `classe_ibfk_2` FOREIGN KEY (`idcurso`) REFERENCES `curso` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `classe_ibfk_3` FOREIGN KEY (`idsala`) REFERENCES `sala` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `curso_ibfk_2` FOREIGN KEY (`idFunc`) REFERENCES `funcionarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `funcionarios_ibfk_1` FOREIGN KEY (`idFuncao`) REFERENCES `funcionarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `inscricao`
--
ALTER TABLE `inscricao`
  ADD CONSTRAINT `inscricao_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `inscricao_ibfk_2` FOREIGN KEY (`idCurso`) REFERENCES `curso` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `inscricao_ibfk_3` FOREIGN KEY (`idClasse`) REFERENCES `classe` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `matricula`
--
ALTER TABLE `matricula`
  ADD CONSTRAINT `matricula_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `matricula_ibfk_2` FOREIGN KEY (`idClasse`) REFERENCES `classe` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `matricula_ibfk_3` FOREIGN KEY (`idCurso`) REFERENCES `curso` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `minipauta`
--
ALTER TABLE `minipauta`
  ADD CONSTRAINT `minipauta_ibfk_1` FOREIGN KEY (`idclasse`) REFERENCES `classe` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `minipauta_ibfk_2` FOREIGN KEY (`idprofessor`) REFERENCES `professor` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `minipauta_ibfk_3` FOREIGN KEY (`iddisciplina`) REFERENCES `disciplina` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `minipauta_ibfk_4` FOREIGN KEY (`idtrimestre`) REFERENCES `trimestre` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `pagamento_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `sala`
--
ALTER TABLE `sala`
  ADD CONSTRAINT `sala_ibfk_1` FOREIGN KEY (`idano`) REFERENCES `ano` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
