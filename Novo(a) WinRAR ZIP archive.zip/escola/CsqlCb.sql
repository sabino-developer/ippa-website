Sql da matricula 
SELECT ano.id, inscricao.codigo, inscricao.nome, cursos.nome, classe.nome, turma.sala, turma.nturma, 
classe.turno, inscricao.valorPago, inscricao.taxaInscr, inscricao.metodoPag, 
(valorPago-taxaInscr) AS troco FROM inscricao
INNER JOIN ano ON inscricao.idano=ano.id
INNER JOIN cursos ON inscricao.idCurso=cursos.id
INNER JOIN classe ON inscricao.idClasse=classe.id
INNER JOIN turma ON classe.idturma=turma.id

Sql que tras os dados da matriculas efetuada 
SELECT matricula.id AS Id, inscricao.codigo AS Codigo , inscricao.nome AS Nome , cursos.nome AS Nivel, classe.nome AS Classe , turma.sala AS Sala , turma.nturma AS Turma , classe.turno AS Turno FROM 
matricula INNER JOIN inscricao ON
matricula.idInscr=inscricao.id INNER JOIN classe ON inscricao.idClasse=classe.id
INNER JOIN cursos ON inscricao.idCurso=cursos.id INNER JOIN turma ON
matricula.idturma=turma.id 
 
 Sql que tras dados do estudate que vai paga propina 
SELECT matricula.id, inscricao.codigo,inscricao.nome,classe.nome AS Classe, turma.nturma AS Turma, 
turma.sala AS Sala , classe.turno AS Periodo, cursos.nome AS Curso  
FROM inscricao INNER JOIN classe ON inscricao.idclasse=classe.id INNER JOIN matricula 
on inscricao.id=matricula.idInscr
INNER JOIN turma on  turma.id=classe.idturma
INNER JOIN cursos ON matricula.idCurso=cursos.id;


    $query = "SELECT SELECT matricula.id AS idmatri, inscricao.codigo,inscricao.nome,classe.nome AS Classe, turma.nturma AS Turma, 
        turma.sala AS Sala , classe.turno AS Periodo, cursos.nome AS Curso  
        FROM inscricao INNER JOIN classe ON inscricao.idclasse=classe.id INNER JOIN matricula 
        on inscricao.id=matricula.idInscr
        INNER JOIN turma on  turma.id=classe.idturma
        INNER JOIN cursos ON matricula.idCurso=cursos.id WHERE matricula.id ='$idmatri'";
        $stmt = $conn->query($query);
        $dados = $stmt->fetch(PDO::FETCH_ASSOC);
        $idmatri = $dados['idmatri'];
        $codigo = $dados['codigo'];
        $nome = $dados['nome'];
        $Classe = $dados['Classe'];
        $Turma = $dados['Turma'];
        $Sala = $dados['Sala'];
        $Periodo = $dados['Periodo'];
        $Curso = $dados['Curso'];

sql que tras o professor ativo

SELECT funcionarios.nome, funcao.nome FROM `funcionarios`
INNER JOIN funcao ON funcionarios.idFuncao=funcao.id
WHERE funcao.nome='professor' AND funcionarios.status = 'on'

    Sql que conta 
  // Consulta SQL para realizar a contagem
    $query = "SELECT COUNT(id) AS Total  FROM  funcionarios";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $Total = $dados['Total'];

    $query = "SELECT COUNT(funcionarios.id) AS TotalP  FROM  funcionarios 
    INNER JOIN funcao on funcionarios.idFuncao=funcao.id 
    WHERE funcao.nome='professor'";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $TotalP = $dados['TotalP'];

    $query = "SELECT COUNT(id) AS Totalus  FROM  users";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $Totalus = $dados['Totalus'];

    $query = "SELECT COUNT(id) AS totalfuncao  FROM  funcao";
    $stmt = $conn->query($query);
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalfuncao = $dados['totalfuncao'];


    ESQUELE QUE TRAS O PROFESSOR E AS SUAS TURMAS 
    SELECT funcionarios.nome as nomef ,disciplinas.ndisciplina, classe.nome as nclasse,turma.sala,turma.nturma FROM disciplinasprof 
INNER JOIN funcionarios ON disciplinasprof.idFuncionario=funcionarios.id
INNER JOIN classe ON disciplinasprof.idclasse=classe.id
INNER JOIN disciplinas ON disciplinasprof.iddisciplina=disciplinas.id
INNER JOIN turma ON classe.idturma=turma.id 
INNER JOIN funcao ON funcionarios.idFuncao=funcao.id 
WHERE funcao.nome='professor' AND funcao.status='on' ORDER BY disciplinasprof.id DESC


sql que tras as disciplinas de um determinado professor 
SELECT users.id AS iduser,funcionarios.nome AS nomef,disciplinas.ndisciplina,cursos.nome as nivel,
classe.nome as nclasse,turma.sala,turma.nturma,classe.turno FROM disciplinasprof
INNER JOIN funcionarios ON disciplinasprof.idFuncionario=funcionarios.id
INNER JOIN disciplinas ON disciplinasprof.iddisciplina=disciplinas.id
INNER JOIN classe on disciplinasprof.idclasse=classe.id
INNER JOIN turma ON classe.idturma=turma.id
INNER JOIN cursos ON classe.idCurso=cursos.id
INNER JOIN users ON  funcionarios.id=users.idFuncionario
INNER JOIN funcao ON funcionarios.idFuncao=funcao.id
WHERE users.id='15' AND users.status='on' AND funcao.nome='professor'

Sql que tras os dados da tabela do professor apos de ser insserido na bd

SELECT trimestre.tipo,disciplinas.ndisciplina, funcionarios.nome,classe.nome,turma.sala,turma.nturma
FROM addmiipauta 
INNER JOIN trimestre ON addmiipauta.idtrimetre=trimestre.id
INNER JOIN disciplinas ON addmiipauta.iddisciplina=disciplinas.id
INNER JOIN funcionarios ON addmiipauta.idfuncionario=funcionarios.id
INNER JOIN classe ON addmiipauta.idclasse=classe.id
INNER JOIN turma ON addmiipauta.idsala=turma.id
INNER JOIN funcao ON funcionarios.idFuncao=funcao.id
WHERE funcao.nome='professor'

sql que tras as classes es turmas 
SELECT classe.nome as nclasse, turma.nturma, turma.sala, classe.turno,cursos.nome as nivel  FROM classe
INNER JOIN cursos on cursos.id=classe.idCurso
INNER JOIN turma ON turma.id=classe.idturma ORDER by classe.id DESC

sql que tras os nomes os meses 
SELECT inscricao.nome ,propinas.mes FROM propinas
INNER JOIN matricula on propinas.idmatri=matricula.id
INNER JOIN inscricao on inscricao.id=matricula.idInscr